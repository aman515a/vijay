import React, { createContext, useContext, useState } from "react";
import { Snackbar, Alert, AlertTitle } from "@mui/material";

const NotificationContext = createContext({});

export const useNotificationContext = () => {
    return useContext(NotificationContext);
};

export const NotificationProvider = (props) => {
    const [notificationState, setNotificationState] = useState({
        isOpen: false,
        heading: "Error",
        message: "Something Went Wrong",
        variant: "error",
        size: "medium",


    });
    const hideNotification = () => {
        setNotificationState({
            ...notificationState,
            isOpen: false,

        });
    };
    const showNotification = (heading, message, variant, size) => {
        setNotificationState({
            ...notificationState,
            isOpen: true,
            heading: heading ?? "Error",
            message: message ?? "Something Went Wrong",
            size: size ?? "medium",
            variant: variant ?? "error",


        });
    };

    return (
        <NotificationContext.Provider
            value={{ showNotification, hideNotification }}

        >
            {props.children}
            <Snackbar
                open={notificationState.isOpen}
                onClose={hideNotification}
                autoHideDuration={5000}
                anchorOrigin={{ horizontal: "center", vertical: "top" }}
            >
                <Alert
                    onClose={hideNotification}
                    severity={notificationState.variant ?? "error"}
                    sx={{ width: "100%", fontSize: "16px", fontWeight: "900" }}
                >
                    <AlertTitle sx={{ width: "100%", fontSize: "20px", fontWeight: "600" }}> {notificationState?.heading ?? " Error"}</AlertTitle>
                    {notificationState?.message ?? "Something went wrong"}
                </Alert>
            </Snackbar>
        </NotificationContext.Provider>
    );
};