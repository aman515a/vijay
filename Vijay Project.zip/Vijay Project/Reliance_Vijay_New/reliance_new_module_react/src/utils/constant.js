class Constant {
  static BASE_URL = "https://rnm-api.mobileprogramming.net";
}

export default Constant;