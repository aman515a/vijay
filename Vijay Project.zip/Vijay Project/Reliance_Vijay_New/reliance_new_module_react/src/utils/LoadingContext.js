import { Backdrop, Box, CircularProgress } from "@mui/material";
import React, { createContext, useContext, useState } from "react";

const LoadingContext = createContext({ loading: false, setLoading: null });

export function LoadingProvider({ children }) {
    const [loading, setLoading] = useState(false);
    const value = { loading, setLoading };
    return (
        <LoadingContext.Provider value={value}>
            {children}
            <Backdrop
                sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1600 }}
                open={loading}
            >
                {" "}
                <Box
                    sx={{
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                    }}
                >
                    <CircularProgress color="inherit" />

                    <div>Loading ...</div>
                </Box>
            </Backdrop>
        </LoadingContext.Provider>
    );
}

export function useLoading() {
    const context = useContext(LoadingContext);
    if (!context) {
        throw new Error("useLoading must be used within LoadingProvider");
    }
    return context;
}