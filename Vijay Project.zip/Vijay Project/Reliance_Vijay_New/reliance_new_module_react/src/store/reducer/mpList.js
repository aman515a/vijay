import { FETCH_MPLIST_FAILURE, FETCH_MPLIST_REQUEST, FETCH_MPLIST_SUCCESS, UPDATE_MPLIST_SUCCESS } from "../action/types";

const initialState = {
    data: [],
    error: ''
};

export const MpListReducer = (state = initialState, action) => {
    switch (action.type) {
        case FETCH_MPLIST_REQUEST:
            return {
                ...state,
            }
        case FETCH_MPLIST_SUCCESS:
            return {
                data: action.payload
            }
        case UPDATE_MPLIST_SUCCESS:
            return {
                
                data: state.data.concat(action.payload)
            }
        case FETCH_MPLIST_FAILURE:
            return {
                data: [],
                error: action.payload
            }
        default:
            return state;
    }
}