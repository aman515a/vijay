
import { CREATE_INITIATIVE_REPORT_FAILURE,CREATE_INITIATIVE_REPORT_REQUEST,CREATE_INITIATIVE_REPORT_SUCCESS}  from "../action/types";

const initialState = {
    data: [],
    error: ''
};

export const createInitiative = (state = initialState, action) => {
    switch (action.type) {
        case CREATE_INITIATIVE_REPORT_REQUEST:
            return {
                state,
            }
        case CREATE_INITIATIVE_REPORT_SUCCESS:
            return {
                data: action.payload
            }
        case CREATE_INITIATIVE_REPORT_FAILURE:
            return {
                data: [],
                error: action.payload
            }
        default:
            return state;
    }
}