
import { ALL_INITIATIVES_FAILURE, ALL_INITIATIVES_REQUEST, ALL_INITIATIVES_SUCCESS}  from "../action/types";

const initialState = {
    data: [],
    error: ''
};

export const allInitiatives = (state = initialState, action) => {
    switch (action.type) {
        case ALL_INITIATIVES_REQUEST:
            return {
                state,
            }
        case ALL_INITIATIVES_SUCCESS:
            return {
                data: action.payload
            }
        case ALL_INITIATIVES_FAILURE:
            return {
                data: [],
                error: action.payload
            }
        default:
            return state;
    }
}