
import {CREATE_EVENT_FAILURE,CREATE_EVENT_REQUEST,CREATE_EVENT_SUCCESS} from "../action/types";

const initialState = {
    data: [],
    error: ''
};

export const createEventInitiative = (state = initialState, action) => {
    switch (action.type) {
        case CREATE_EVENT_REQUEST:
            return {
                ...state,
            }
        case CREATE_EVENT_SUCCESS:
            return {
                data: state.data.concat(action.payload)
            }
        case CREATE_EVENT_FAILURE:
            return {
                data: [],
                error: action.payload
            }
        default:
            return state;
    }
}