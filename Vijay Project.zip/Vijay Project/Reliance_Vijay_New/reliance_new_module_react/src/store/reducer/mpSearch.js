import { SEARCH_MP_FAILURE, SEARCH_MP_REQUEST, SEARCH_MP_SUCCESS } from "../action/types";

const initialState = {
    data: [],
    error: ''
};

export const MpSearchReducer = (state = initialState, action) => {
    
    switch (action.type) {
        case SEARCH_MP_REQUEST:
            return {
                ...state, 
            }
        case SEARCH_MP_SUCCESS: 
            return {
                data: action.payload
            }
        case SEARCH_MP_FAILURE:
            return { 
                data: [],
                error: action.payload
            }
        default:
            return state;
    }
}