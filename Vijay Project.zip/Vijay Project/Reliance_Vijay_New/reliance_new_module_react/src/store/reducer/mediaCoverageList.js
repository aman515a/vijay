import {
    FETCH_MEDIA_COVERAGE_LIST_REQUEST, FETCH_MEDIA_COVERAGE_LIST_SUCCESS, FETCH_MEDIA_COVERAGE_LIST_FAILURE,
    FETCH_MEDIA_COVERAGE_TYPES_LIST_REQUEST, FETCH_MEDIA_COVERAGE_TYPES_LIST_SUCCESS, FETCH_MEDIA_COVERAGE_TYPES_LIST_FAILURE
} from "../action/types";

const initialState = {
    data: [],
    error: ''
};
const typesInitialState = {
    data: [],
    error: ''
};

export const MediaCoverageListReducer = (state = initialState, action) => {
    switch (action.type) {
        case FETCH_MEDIA_COVERAGE_LIST_REQUEST:
            return {
                ...state,
            }
        case FETCH_MEDIA_COVERAGE_LIST_SUCCESS:
            return {
                data: action.payload
            }
        case FETCH_MEDIA_COVERAGE_LIST_FAILURE:
            return {
                data: [],
                error: action.payload
            }
        default:
            return state;
    }
}

export const MediaCoverageTypesListReducer = (state = typesInitialState, action) => {
    switch (action.type) {
        case FETCH_MEDIA_COVERAGE_TYPES_LIST_REQUEST:
            return {
                ...state,
            }
        case FETCH_MEDIA_COVERAGE_TYPES_LIST_SUCCESS:
            return {
                data: action.payload
            }
        case FETCH_MEDIA_COVERAGE_TYPES_LIST_FAILURE:
            return {
                data: [],
                error: action.payload
            }
        default:
            return state;
    }
}