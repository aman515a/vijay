import { combineReducers } from "redux";
import { HighlightsReducer } from "./reducer/globalHighlight";
import { MpListReducer } from "./reducer/mpList";
import { EventsListReducer } from "./reducer/eventsList";
import { MediaCoverageListReducer, MediaCoverageTypesListReducer } from "./reducer/mediaCoverageList";
import { DevelopmentProjectListReducer, DevelopmentStatusListReducer } from "./reducer/developmentProjectList";
import { createEventReducer } from "./reducer/createNewEvent";
import { MpSearchReducer } from "./reducer/mpSearch";
import { getMpProfileReducer } from "./reducer/individualMP";
import {getAllEvents} from "./reducer/getEvents"
import { getAssignMpReducer } from "./reducer/assignMplist";
import { createOpedsReducer } from "./reducer/createNewOpeds";
import { createDevelopmentProjectReducer } from "./reducer/createDevelopmentProject";
import { getInitiativeListReducer } from "./reducer/initiativeList";

const rootReducer = combineReducers({
  mpList: MpListReducer,
  highlights: HighlightsReducer,
  eventsList: EventsListReducer,
  mediaCoverageList: MediaCoverageListReducer,
  developmentProjectsList: DevelopmentProjectListReducer,
  mpSearchList: MpSearchReducer,
  mpProfileData: getMpProfileReducer,
  getAllEvents:getAllEvents,
  mediaCoverageTypesList: MediaCoverageTypesListReducer,
  developmentCompletionStatusList: DevelopmentStatusListReducer,
  createEventData: createEventReducer,
  mpSearchList: MpSearchReducer,
  assignMpList: getAssignMpReducer,
  createOpedsData: createOpedsReducer,
  createDevelopmentProjectData: createDevelopmentProjectReducer,
  initiativeList:getInitiativeListReducer
});

export default rootReducer;
