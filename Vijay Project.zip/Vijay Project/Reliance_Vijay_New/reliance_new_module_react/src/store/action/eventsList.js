import axios from "axios"
import Constant from "../../utils/constant"
// import { mpList } from "../../Constants/mpList"
import { FETCH_EVENTS_LIST_REQUEST, FETCH_EVENTS_LIST_SUCCESS, FETCH_EVENTS_LIST_FAILURE } from "./types"

export const fetchEventsListRequest = () => {
    return {
        type: FETCH_EVENTS_LIST_REQUEST
    }
}
export const fetchEventsListSuccess = carMakes => {
    return {
        type: FETCH_EVENTS_LIST_SUCCESS,
        payload: carMakes
    }
}
export const fetchEventsListFailure = error => {
    return {
        type: FETCH_EVENTS_LIST_FAILURE,
        payload: error
    }
}


export const getEventsList = (mpId) => async (dispatch) => {
    dispatch(fetchEventsListRequest)
    await axios.get(Constant.BASE_URL + `/api/event/getall/${mpId ? mpId : 0}`)
        .then(response => {
            const result = response.data
            // const result = mpList
            dispatch(fetchEventsListSuccess(result))
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchEventsListFailure(errorMsg))
        })
}


