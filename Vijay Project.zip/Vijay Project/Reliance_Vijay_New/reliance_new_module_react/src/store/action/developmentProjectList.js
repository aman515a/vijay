import axios from "axios"
import Constant from "../../utils/constant"
// import { mpList } from "../../Constants/mpList"
import {
    FETCH_DEVELOPMENT_PROJECTS_LIST_REQUEST, FETCH_DEVELOPMENT_PROJECTS_LIST_SUCCESS, FETCH_DEVELOPMENT_PROJECTS_LIST_FAILURE,
    FETCH_DEVELOPMENT_STATUS_LIST_REQUEST, FETCH_DEVELOPMENT_STATUS_LIST_SUCCESS, FETCH_DEVELOPMENT_STATUS_LIST_FAILURE
} from "./types"

export const fetchDevelopmentProjectsListRequest = () => {
    return {
        type: FETCH_DEVELOPMENT_PROJECTS_LIST_REQUEST
    }
}
export const fetchDevelopmentProjectsListSuccess = data => {
    return {
        type: FETCH_DEVELOPMENT_PROJECTS_LIST_SUCCESS,
        payload: data
    }
}
export const fetchDevelopmentProjectsListFailure = error => {
    return {
        type: FETCH_DEVELOPMENT_PROJECTS_LIST_FAILURE,
        payload: error
    }
}

export const fetchDevelopmentCompletionStatusListRequest = () => {
    return {
        type: FETCH_DEVELOPMENT_STATUS_LIST_REQUEST
    }
}
export const fetchDevelopmentCompletionStatusListSuccess = carMakes => {
    return {
        type: FETCH_DEVELOPMENT_STATUS_LIST_SUCCESS,
        payload: carMakes
    }
}
export const fetchDevelopmentCompletionStatusListFailure = error => {
    return {
        type: FETCH_DEVELOPMENT_STATUS_LIST_FAILURE,
        payload: error
    }
}

export const getDevelopmentProjectsList = (mpId) => async (dispatch) => {
    dispatch(fetchDevelopmentProjectsListRequest)
    await axios.get(Constant.BASE_URL + `/api/development/getalldevelopment/${mpId ? mpId : 0}`)
        .then(response => {
            console.log('res', response);
            const result = response.data
            // const result = mpList
            dispatch(fetchDevelopmentProjectsListSuccess(result))
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchDevelopmentProjectsListFailure(errorMsg))
        })
}

export const getDevelopmentCompletionStatusList = () => async (dispatch) => {
    dispatch(fetchDevelopmentCompletionStatusListRequest)
    await axios.get(Constant.BASE_URL + '/api/getdevelopmentstatus')
        .then(response => {
            console.log('res', response);
            const result = response.data
            // const result = mpList
            dispatch(fetchDevelopmentCompletionStatusListSuccess(result))
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchDevelopmentCompletionStatusListFailure(errorMsg))
        })
}


