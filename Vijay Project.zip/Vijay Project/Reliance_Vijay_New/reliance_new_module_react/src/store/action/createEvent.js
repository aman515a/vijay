import axios from "axios"
import Constant from "../../utils/constant"
import { CREATE_EVENT_FAILURE,CREATE_EVENT_REQUEST,CREATE_EVENT_SUCCESS} from "./types"

export const createEventInitiativeRequest = () => {
    return {
        type: CREATE_EVENT_REQUEST
    }
}
export const createEventInitiativeSuccess = value => {
    return {
        type: CREATE_EVENT_SUCCESS,
        payload: value
    }
}
export const createEventInitiativeFailure = error => {
    return {
        type: CREATE_EVENT_FAILURE,
        payload: error
    }
}

export const createEventInitiative = (query) => async (dispatch) => {
    dispatch(createEventInitiativeRequest)
    let formData = new FormData()
    formData.append("eventTitle", query.eventTitle)
    formData.append("location", query.location)
    formData.append("status", query.status)
    formData.append("startDate", query.startDate)
    formData.append("endDate", query.endDate)
    formData.append("startTime", query.startTime)
    formData.append("endTime", query.endTime)
    formData.append("desc", query.desc)
    formData.append("media", query.formImg)
    formData.append("mpmodelId", query.id)
    await axios.post(Constant.BASE_URL + `/api/event/create/0`,formData)
    .then(response => {
        const result = response.data
        console.log("responsseee--->",response.data)
        // const result = mpList
        dispatch(createEventInitiativeSuccess(result))
    })
    .catch(error => {
        const errorMsg = error.message
        dispatch(createEventInitiativeFailure(errorMsg))
    })
}
