import axios from "axios";
import Constant from "../../utils/constant";
import {
    POST_CREATE_OPEDS_FAILURE,
    POST_CREATE_OPEDS_REQUEST,
    POST_CREATE_OPEDS_SUCCESS,
} from "./types";

export const postCreateOpedsRequest = () => {
    return {
        type: POST_CREATE_OPEDS_REQUEST,
    };
};
export const postCreateOpedsSuccess = (value) => {
    return {
        type: POST_CREATE_OPEDS_SUCCESS,
        payload: value,
    };
};
export const postCreateOpedsFailure = (error) => {
    return {
        type: POST_CREATE_OPEDS_FAILURE,
        payload: error,
    };
};

export const postCreateOpeds = (id, payload, config) => async (dispatch) => {
    dispatch(postCreateOpedsRequest);
    console.log("pot api called")

    return axios
        .post(Constant.BASE_URL + `/api/opeds/create/${id}`, payload, config)
        .then((response) => {
            const result = response.data;
            dispatch(postCreateOpedsSuccess(result));
            return response;
        })
        .catch((error) => {
            const errorMsg = error.message;
            dispatch(postCreateOpedsFailure(errorMsg));
        });
};