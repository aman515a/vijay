import axios from "axios"
import Constant from "../../utils/constant"
// import { mpList } from "../../Constants/mpList"
import {
    FETCH_MEDIA_COVERAGE_LIST_REQUEST, FETCH_MEDIA_COVERAGE_LIST_SUCCESS, FETCH_MEDIA_COVERAGE_LIST_FAILURE,
    FETCH_MEDIA_COVERAGE_TYPES_LIST_REQUEST, FETCH_MEDIA_COVERAGE_TYPES_LIST_SUCCESS, FETCH_MEDIA_COVERAGE_TYPES_LIST_FAILURE
} from "./types"

export const fetchMediaCoverageListRequest = () => {
    return {
        type: FETCH_MEDIA_COVERAGE_LIST_REQUEST
    }
}
export const fetchMediaCoverageListSuccess = (data) => {
    return {
        type: FETCH_MEDIA_COVERAGE_LIST_SUCCESS,
        payload: data
    }
}
export const fetchMediaCoverageListFailure = error => {
    return {
        type: FETCH_MEDIA_COVERAGE_LIST_FAILURE,
        payload: error
    }
}

export const fetchMediaCoverageTypesListRequest = () => {
    return {
        type: FETCH_MEDIA_COVERAGE_TYPES_LIST_REQUEST
    }
}
export const fetchMediaCoverageTypesListSuccess = (data) => {
    return {
        type: FETCH_MEDIA_COVERAGE_TYPES_LIST_SUCCESS,
        payload: data
    }
}
export const fetchMediaCoverageTypesListFailure = error => {
    return {
        type: FETCH_MEDIA_COVERAGE_TYPES_LIST_FAILURE,
        payload: error
    }
}


export const getMediaCoverageList = (mpId) => async (dispatch) => {
    dispatch(fetchMediaCoverageListRequest)
    await axios.get(Constant.BASE_URL + `/api/opeds/getallopeds/${mpId ? mpId : 0}`)
        .then(response => {
            const result = response.data
            // const result = mpList
            dispatch(fetchMediaCoverageListSuccess(result))
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchMediaCoverageListFailure(errorMsg))
        })
}

export const getMediaCoverageTypesList = () => async (dispatch) => {
    dispatch(fetchMediaCoverageTypesListRequest)
    await axios.get(Constant.BASE_URL + '/api/opeds/types')
        .then(response => {
            console.log('res', response);
            const result = response.data
            // const result = mpList
            dispatch(fetchMediaCoverageTypesListSuccess(result))
        })
        .catch(error => {
            const errorMsg = error.message
            dispatch(fetchMediaCoverageTypesListFailure(errorMsg))
        })
}


