import axios from "axios"
import Constant from "../../utils/constant"
import { ALL_INITIATIVES_FAILURE, ALL_INITIATIVES_REQUEST, ALL_INITIATIVES_SUCCESS} from "./types"

export const allInitiativeRequest = () => {
    return {
        type: ALL_INITIATIVES_REQUEST
    }
}
export const allInitiativeSuccess = value => {
    return {
        type: ALL_INITIATIVES_SUCCESS,
        payload: value
    }
}
export const allInitiativeFailure = error => {
    return {
        type: ALL_INITIATIVES_FAILURE,
        payload: error
    }
}

export const allInitiative = (query) => async (dispatch) => {
    dispatch(allInitiativeRequest)
    await axios.get(Constant.BASE_URL + `/api/search/?searchText=${query}`)
    .then(response => {
        const result = response.data
        console.log(response.data,"mp list res 30")
        // const result = mpList
        dispatch(allInitiativeSuccess(result))
    })
    .catch(error => {
        const errorMsg = error.message
        dispatch(allInitiativeFailure(errorMsg))
    })
}


