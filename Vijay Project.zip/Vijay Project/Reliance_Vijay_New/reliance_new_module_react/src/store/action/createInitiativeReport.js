import axios from "axios"
import Constant from "../../utils/constant"
import { CREATE_INITIATIVE_REPORT_FAILURE,CREATE_INITIATIVE_REPORT_SUCCESS,CREATE_INITIATIVE_REPORT_REQUEST} from "./types"

export const createInitiativeReportRequest = () => {
    return {
        type: CREATE_INITIATIVE_REPORT_REQUEST
    }
}
export const createInitiativeReportSuccess = value => {
    return {
        type: CREATE_INITIATIVE_REPORT_SUCCESS,
        payload: value
    }
}
export const createInitiativeReportFailure = error => {
    return {
        type: CREATE_INITIATIVE_REPORT_FAILURE,
        payload: error
    }
}

export const createInitiativeReport = (query) => async (dispatch) => {
    dispatch(createInitiativeReportRequest)
    let formData = new FormData()
    formData.append("eventTitle", query.eventTitle)
    formData.append("location", query.location)
    formData.append("status", query.status)
    formData.append("startDate", query.startDate)
    formData.append("endDate", query.endDate)
    formData.append("startTime", query.startTime)
    formData.append("endTime", query.endTime)
    formData.append("desc", query.desc)
    formData.append("media", query.formImg)
    formData.append("mpmodelId", query.id)
    await axios.post(Constant.BASE_URL + `/api/event/create/0`,formData)
    .then(response => {
        const result = response.data
        console.log("responsseee--->",response.data)
        // const result = mpList
        dispatch(createInitiativeReportSuccess(result))
    })
    .catch(error => {
        const errorMsg = error.message
        dispatch(createInitiativeReportFailure(errorMsg))
    })
}
