import axios from "axios"
import Constant from "../../utils/constant"
import { INITIATIVE_LIST_FAILURE,INITIATIVE_LIST_SUCCESS,INITIATIVE_LIST_REQUEST} from "./types"

export const getMp = () => {
    return {
        type: INITIATIVE_LIST_REQUEST
    }
}
export const getInitiativeListSuccess = value => {
    return {
        type: INITIATIVE_LIST_SUCCESS,
        payload: value
    }
}
export const getInitiativeListFailure = error => {
    return {
        type: INITIATIVE_LIST_FAILURE,
        payload: error
    }
}

const getInitiativeList = (query) => async (dispatch) => {
    dispatch(getMp)
    await axios.get(Constant.BASE_URL + `/api/initiative/getall/0`)
    .then(response => {
        const result = response.data?.initiative
        console.log(response.data?.initiative,"mp list res 30")
        // const result = mpList
        dispatch(getInitiativeListSuccess(result))
    })
    .catch(error => {
        const errorMsg = error.message
        dispatch(getInitiativeListFailure(errorMsg))
    })
}


export default getInitiativeList;

