import axios from "axios"
import Constant from "../../utils/constant"
import { SEARCH_MP_REQUEST, SEARCH_MP_SUCCESS, SEARCH_MP_FAILURE} from "./types"

export const searchMpListRequest = () => {
    return {
        type: SEARCH_MP_REQUEST,
        payload: []
    }
}
export const searchMpListSuccess = value => {
    return {
        type: SEARCH_MP_SUCCESS,
        payload: value
    }
}
export const searchMpListFailure = error => {
    return {
        type: SEARCH_MP_FAILURE,
        payload: error
    }
}

export const searchMpList = (query) => async (dispatch) => {
    dispatch(searchMpListRequest)
    console.log("searchInput2")
    await axios.get(Constant.BASE_URL + `/api/search/?searchText=${query}`)
    .then(response => {
        const result = response.data
        console.log(response.data,"search data")
        // const result = mpList
        dispatch(searchMpListSuccess(result))
    })
    .catch(error => {
        const errorMsg = error.message
        dispatch(searchMpListFailure(errorMsg))
    })
}


