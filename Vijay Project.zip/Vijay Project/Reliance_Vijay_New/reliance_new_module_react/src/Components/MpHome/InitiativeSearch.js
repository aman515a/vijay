import { InputAdornment, TextField } from '@mui/material';
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';
// import { mpList } from '../../Constants/mpList';
import searchIcon from "../../asserts/images/Search.svg";
import { MpIntiavtivesData } from "../YourIntiative/YourInitiativeData";

function InitiativeSearch() {
    const [searchInput, setSearchInput] = useState([])
    const [filteredList, setFilteredList]= useState([])
    const [anchorEl, setAnchorEl] = React.useState(null);
    const navigate = useNavigate();
    const handleClose = () => {
      setAnchorEl(null);
    };
    const open = Boolean(anchorEl);

    const handleSearch = (event) => {
        setAnchorEl(searchInput[1]);
        if (searchInput[0])
        setFilteredList(
            MpIntiavtivesData.filter((value) =>  value.name.toUpperCase().includes(searchInput[0].toUpperCase()) || 
          value.constituency.toUpperCase().includes(searchInput[0].toUpperCase()))
          )
        
      else {
        setFilteredList([]);
      }
    }
    
    useEffect(()=>{
        handleSearch()
    },[searchInput])
  return (
    <div>  <TextField
    className='search-filter-icon'
    sx={{
      "& fieldset": { border: 'none' },
    }}
  onChange={(e) => {
      setSearchInput([e.target.value,e.currentTarget])
    }}
    placeholder="Search MP / Constituency"
  InputProps={{
    endAdornment: (
      <InputAdornment position="start">
       {/* search icon  */}<img className="searchIcon" width={20} height={21} src={searchIcon}/>
      </InputAdornment>
    ),
  }}
>
      </TextField></div>
  )
}

export default InitiativeSearch