import * as React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import { MpColumnFilter, MpColumnHeaders,} from "./MpTableData";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import { useDispatch, useSelector } from "react-redux";
import { getMpList } from "../../store/action/mpList";
import { Hidden } from "@mui/material";
import './MpTables.css'

export default function StickyHeadTable({ cardClick ,flag,count}) {
  const dispatch=useDispatch();
  const [page, setPage] = React.useState(count);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);
  let keys=['id','icon', 'user_name', 'imageSrc', 'position', 'constituency_name', 'sevaScore', 'initiatives', 'eventOrganized', 'citizen', 'memberAdded', 'followers', 'twitterPerformance', 'opEds', 'mediaCoverage', 'donation', 'dateIssued']
  const mpList = useSelector((state)=>state?.mpList?.data)
  const scrollRef = React.useRef()
  let columnsAll = keys;
  let column = [];

  React.useEffect(()=>{
    console.log("hi lazzy load")
    dispatch(getMpList(flag,page))
  },[page])
  React.useEffect(()=>{
    scrollRef.current.scrollTop=0
    setPage(1)
    
  },[flag])
  let filteredColumns = MpColumnFilter.filter(
    (s) => s.screenNumber === cardClick
  )[0]?.columns;
  console.log(filteredColumns,"filter")
  column = columnsAll
    .filter((s) => filteredColumns?.includes(MpColumnHeaders[s]))
    .map((x) => ({ id: x, label: x=='id'?'#':MpColumnHeaders[x] }));
  console.log(column, "columng console")
  const onScroll = () => {
    if (scrollRef.current) {
      const { scrollTop, scrollHeight, clientHeight} = scrollRef.current;
      console.log(Math.ceil( scrollTop),scrollTop, Math.floor( scrollTop),clientHeight,scrollHeight,"height","TO ")
      if (Math.floor( scrollTop) + clientHeight == scrollHeight ||Math.floor( scrollTop) + clientHeight+1 == scrollHeight || Math.ceil( scrollTop) + clientHeight == scrollHeight) {
        console.log("to TO SOMETHING HERE")
        setPage(page+1)
      }
    }
  };

  return (
    
      <TableContainer    >
            
         <Table style={{ position: "sticky", top: 0,tableLayout: "fixed" }} >
     
      <TableHead  >
  
            <TableRow >
              {column.map((column) => (
                <TableCell
                  key={column.id}
                  align={column.align}
                  style={{
                    
                    textTransform: "capitalize",
                    fontWeight: "bold",
                    // textAlign: "center",
                    background:'#E3F5FF',
                    borderBottom:'2px solid #356F92',
                    fontFamily: 'HK Grotesk',fontSize: "16px",
                  
                   
                   
               
                  }}
                >
                  {column.label}
                </TableCell>
              ))}
            </TableRow>
           
          </TableHead>
          </Table>
       
         <div style={{ height: "350px", overflow: "auto" }} ref={scrollRef} onScroll={() => onScroll()}>
        <Table style={{tableLayout: "fixed"}} >
          <TableBody >
            {/* {tdData()} */}
            
                <React.Fragment >
                  {mpList.map((item,index) => (
                    <TableRow
                      hover
                      role="checkbox"
                      tabIndex={-1}
                      key={index+1}

                    >
                      {column.map((column, key) =>

                        key == 2 ? (
                          
                          <TableCell 
                         >
                            <div className="table-name-container">
                              <div >
                                <p style={{color:'#356F92',fontWeight:'bold',fontFamily: 'HK Grotesk',fontSize: "16px"}}>{item.user_name}</p>
                                <p style={{fontFamily: 'HK Grotesk',fontSize: "14px"}}>{item.party}</p>
                              </div>
                            </div>
                          </TableCell>
                        ) : (
                          <TableCell
                          key={index+1}
                            align={column.align}
                            style={{
                              // minWidth: column.minWidth,
                              color: key === 0 ? "#356F92" : "",
                              fontWeight:key === 0 ? 'bold' : "",
                              fontFamily: 'HK Grotesk',fontSize: "14px",
                             
                            }}

                          >
                          {key==0 ?
                          index+1
                           : 
                            key==1 ?
                            
                            <div>
                              {item.user_avatar?
                            <img
                                src={item.user_avatar}
                                className="img-circle leader-circle-img mr-1"
                                width="50"
                                height="50"
                                style={{objectFit:"contain"}}
                              />
                               :<div >
                                <AccountCircleIcon  
                                  sx={{ fontSize: "xx-large",width:"50px",height:"50px"}}  /></div>}
                                      </div>
                             :item[column.id]}
                          </TableCell>
                        )
                      )}
                    </TableRow>
                  ))}
                </React.Fragment>
              
          </TableBody>    
        </Table>
       </div>
      </TableContainer>
     
  );
}
