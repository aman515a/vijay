import React, { useEffect, useRef, useState } from 'react';
// import 'bootstrap/dist/css/bootstrap.min.css';
import ProfileCard from '../ReusableComponents.js/ProfileCard';
import SideMenu from '../SideMenu/SideMenu';
import TableHighlights from '../Highlights/TableHighlights';
import ThreeCards from './ThreeCards';
import {  Grid,  MenuItem,  Select,  Tabs } from '@mui/material';
import Search from './Search';
import DateFilter from '../ReusableComponents.js/DateFilter';

import StickyHeadTable from './MpTable';
import { useDispatch, useSelector } from 'react-redux';
import { getMpList } from '../../store/action/mpList';
import { mpListOld } from '../../Constants/mpListOld';
import {getMpProfile} from '../../store/action/individualMP'
const MpHome = () => {
    const [cardClick, setCardClick] = useState("sevaScore")
    const [tabactive, settabactive] = useState(1)
    const [flag,setFlag]=useState(101)
    //redux get store data
    const mpList = useSelector((state)=>state?.mpList?.data)
    const mpProfileData = useSelector((state)=>state?.mpProfileData?.data[0]);
    
    console.log("mpList",mpProfileData)
    const dispatch = useDispatch();
    
    useEffect(()=>{
      //call api to update store
      dispatch(getMpProfile(2))
      dispatch(getMpList(flag));


    },[flag])

    const containerRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);

  const handleMouseDown = (event) => {
    setIsDragging(true);
    setStartX(event.pageX - containerRef.current.offsetLeft);
    setScrollLeft(containerRef.current.scrollLeft);
  };

  const handleMouseMove = (event) => {
    if (!isDragging) return;
    event.preventDefault();
    const x = event.pageX - containerRef.current.offsetLeft;
    const distance = (x - startX) * 2;
    containerRef.current.scrollLeft = scrollLeft - distance;
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

    return (
      <>

      {/* API loading time mpList will be empty */}
      {mpListOld.length!=0 &&
      <div className="page-wrapper d-flex">
        <SideMenu active="Leader" profile={mpList[0]}/>
        <div className="main-wrapper center-width" style={{paddingLeft:"35px"}}>
          <Grid container spacing={2}>
              <Grid md={8} lg={8} xl={8}>
                <div>
                  <div className="d-flex justify-content-between align-items-center">
                    <h1 className="page-title mb-0">MP Leaderboard</h1>
                    <Search />
                   
                  </div>
                <DateFilter />
                  </div>
                  <div className="filter-btns row no-gutters pt-3">
                    <Tabs
                    // value={value}
                    // onChange={handleChange}
                    variant="scrollable"
                    scrollButtons={false}>
                    <div
                    aria-label="scrollable auto tabs example"
                    ref={containerRef}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      overflowX: "hidden"
                    }}
                    onMouseDown={handleMouseDown}
                    onMouseMove={handleMouseMove}
                    onMouseUp={handleMouseUp}
                    onMouseLeave={handleMouseUp}
                  >
                    <button
                      type="button"
                      className={
                        tabactive === 1
                          ? "btn btn-primary primary-btn mr-3 mt-1 mb-3"
                          : "btn btn-primary normal-btn mr-3 mt-1 mb-3"
                      }
                      onClick={() => {
                        settabactive(1);
                        setCardClick("sevaScore");
                        setFlag(101)
                      }}
                    >
                      MP Seva Score
                    </button>
                    <button
                      type="button"
                      className={
                        tabactive === 2
                          ? "btn btn-primary primary-btn mr-3 mt-1 mb-3"
                          : "btn btn-primary normal-btn mr-3 mt-1 mb-3"
                      }
                      onClick={() => {
                        settabactive(2);
                        setCardClick("initiatives");
                        setFlag(102)
                      }}
                    >
                      Initiatives
                    </button>
                    <button
                      type="button"
                      className={
                        tabactive === 3
                          ? "btn btn-primary primary-btn mr-3 mt-1 mb-3"
                          : "btn btn-primary normal-btn mr-3 mt-1 mb-3"
                      }
                      onClick={() => {
                        settabactive(3);
                        setCardClick("memberAdded");
                        setFlag(103)
                      }}
                    >
                      Members Added
                    </button>
                    <button
                      type="button"
                      className={
                        tabactive === 4
                          ? "btn btn-primary primary-btn mr-3 mt-1 mb-3"
                          : "btn btn-primary normal-btn mr-3 mt-1 mb-3"
                      }
                      onClick={() => {
                        settabactive(4);
                        setCardClick("followers");
                        setFlag(104)
                      }}
                    >
                      Followers
                    </button>
                    <button
                      type="button"
                      className={
                        tabactive === 5
                          ? "btn btn-primary primary-btn mr-3 mt-1 mb-3"
                          : "btn btn-primary normal-btn mr-3 mt-1 mb-3"
                      }
                      onClick={() => {
                        settabactive(5);
                        setCardClick("twitterPerformance");
                        setFlag(105)
                      }}
                    >
                      Twitter Performance
                    </button>
                    <button
                      type="button"
                      className={
                        tabactive === 6
                          ? "btn btn-primary primary-btn mr-3 mt-1 mb-3"
                          : "btn btn-primary normal-btn mr-3 mt-1 mb-3"
                      }
                      onClick={() => {
                        settabactive(6);
                        setCardClick("mediaCoverage");
                        setFlag(106)
                      }}
                    >
                      Op-Eds & Media Coverage
                    </button>
                    <button
                      type="button"
                      className={
                        tabactive === 7
                          ? "btn btn-primary primary-btn mr-3 mt-1 mb-3"
                          : "btn btn-primary normal-btn mr-3 mt-1 mb-3"
                      }
                      onClick={() => {
                        settabactive(7);
                        setCardClick("donation");
                        setFlag(107)
                      }}
                    >
                      Donations
                    </button>
                    </div></Tabs>
                  </div>
                  <ThreeCards cardClick={cardClick} />
                  <div className="mt-5 learders-list">
                    {/* <MpTables cardClick={cardClick} mpList={mpList} /> */}
                    <StickyHeadTable cardClick={cardClick} flag={flag} count={1}/>

                  </div>
      </Grid>
      <Grid item xs={12} md={4} lg={4} xl={4} sx={{backgroundColor:"#F5F6FA"}}>
      <div>
                  <div className="right-card">
                    <div className="highlights-title">
                      <h1 className='fs-30'>Highlights</h1>
                      <p className="mb-0">All India Seva Initiatives</p>
                    </div>

                    <TableHighlights mpList={mpList[0]}/>
                  </div>
                  <div>
                <ProfileCard profile={mpProfileData?mpProfileData:{}}/>
                </div>
                </div>
      </Grid>
   
    </Grid>
  
    </div>
    </div>}</>
    );
}

export default MpHome;




