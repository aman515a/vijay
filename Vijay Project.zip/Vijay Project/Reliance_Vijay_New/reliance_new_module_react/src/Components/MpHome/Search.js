import {
  Card,
  CardActionArea,
  CardContent,
  CardMedia,
  InputAdornment,
  List,
  TextField,
  Typography,
} from "@mui/material";
import { Box } from "@mui/system";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { mpListOld } from "../../Constants/mpListOld";
import searchIcon from "../../asserts/images/Search.svg";
import closeIcon from "../../asserts/images/Close.svg";
import { useDispatch, useSelector } from "react-redux";
import { searchMpList } from "../../store/action/mpSearch";

const Search = ({ user }) => {
  const [searchInput, setSearchInput] = useState([]);
  const [filteredList, setFilteredList] = useState([]);
  const [anchorEl, setAnchorEl] = React.useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const mpList = useSelector((state) => state?.mpSearchList?.data);
  const handleClose = () => {
    setSearchInput([])
    setAnchorEl(false);

  };
  
  const handleSearch = (event) => {

    setSearchInput(event.target.value)

    if(event.target.value.length >= 1){
      setAnchorEl(true)
    }else{

      setAnchorEl(false)
    }
    
    // if (mpList) {
    //   const filtered = mpList.filter((value) =>
    //     value.user_name.toUpperCase().includes(event.target.value.toUpperCase())
    //   );
    //   setFilteredList(filtered);
    // }
    // // open = true;
    // console.log(filteredList, "filterdlist");

    //   if (searchInput[0])
    //   setFilteredList(
    //     mpListOld.filter((value) =>  value.name.toUpperCase().includes(searchInput[0].toUpperCase()) ||
    //     value.constituency.toUpperCase().includes(searchInput[0].toUpperCase()))
    //     )

    // else {
    //   setFilteredList([]);
    // }
  };



  useEffect(()=>{
    dispatch(searchMpList(searchInput));
    console.log("searchInput",mpList)
      
  },[searchInput])

  return (
    <div>
      <TextField
        className="search-filter-icon"
        sx={{
          "& fieldset": { border: "none" },
        }}
        onChange={(e) => {
          handleSearch(e);
        }}
        value={searchInput}
        placeholder="Search MP / Constituency"
        InputProps={{
          endAdornment: (
            <InputAdornment position="start">
              {/* search icon  */}
              <img
                className="searchIcon"
                width={20}
                height={21}
                src={searchIcon}
              />
            </InputAdornment>
          ),
        }}
      ></TextField>
      {mpList && mpList.length !== 0 && anchorEl  && (
        <List
          sx={{
            width: "400px",
            bgcolor: "background.paper",
            position: "absolute",
            zIndex: 1000,
            marginTop: "8px",
            borderRadius: "5%",
            overflow: "auto",
            height: "450px",
            "& ul": { padding: 0 },
          }}
          subheader={<li />}
          
        >
          <Typography
            sx={{ margin: "2% 8% 2% 8%", display: "inline-flex" }}
            variant={"h5"}
          >
            Results for “{searchInput}”
          </Typography>
          <img
            src={closeIcon}
            width={20}
            height={20}
            className="m-3"
            onClick={handleClose}
            style={{ float: "right" }}
            alt="close"
          />
          {/* <ul style={{position:"absolute",zIndex:1000,background:"white",width:"500px",textAlign:"center"}}> */}
          {mpList.map((i) => (
            // <li key={i.name}>{i.name} - {i.constituency}</li>
            <Card
              sx={{ margin: "2% 8% 2% 8%" }}
              onClick={() =>
                navigate("/Mp_SevaUpdate", {
                  state: {
                    MpName: i.user_name,
                    user: user || i.designation,
                  },
                })
              }
            >
              <CardActionArea >
                <img
                  src={i.user_avatar}
                  alt={i.user_name}
                  className="card-image-search"
                />
                {i.coverimage ? (
                  <CardMedia
                    component="img"
                    height="100vh"
                    image={i.coverimage}
                    alt={i.user_name}
                  />
                ) : (
                  <Box height="6.3em" sx={{ backgroundColor: "#DFF6FF" }} />
                )}
                <CardContent sx={{ paddingLeft: "8vw" }}>
                  <Typography className="serach-card-head" component="div">
                    {i.user_name}
                  </Typography>
                  <Typography
                    className="serach-card-head-2"
                    color="text.secondary"
                  >
                    {i.designation} -{i.party},<br />
                    {i.state_name}
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>
          ))}
          {/* </ul> */}
        </List>
      )}
    </div>
  );
};

export default Search;
