import React from "react";
import third from "../../asserts/images/3rd.png";
import three from "../../asserts/images/2.jpg";
import first from "../../asserts/images/1st.png";
import one from "../../asserts/images/1.jpg";
import second from "../../asserts/images/2nd.png";
import two from "../../asserts/images/4.jpg";
import { useNavigate } from "react-router";
import { Grid } from "@mui/material";
import { useSelector } from "react-redux";

import AccountCircleIcon from "@mui/icons-material/AccountCircle";
// import { mpList } from '../../Constants/mpList';

const ThreeCards = ({ cardClick, user }) => {
  const navigate = useNavigate();
  const topImage = [first, second, third];
  const mpList = useSelector((state) => state?.mpList?.data);

  return (
    <Grid container spacing={3}>
      {mpList.slice(0, 3).map((mp, index) => (
        <Grid item xs={12} md={12} lg={4} xl={4}>
          <div
            className="card-size "
            style={{ cursor: "pointer" }}
            onClick={(e) => {
              if (!window.getSelection().toString()) {
                navigate("/Mp_SevaUpdate", {
                  state: {
                    MpName: mp.user_name,
                    user: user,
                    mpId: mp.id
                  },
                });
              }
            }}
          >
            <div className="card">
              <div className="card-body position-relative">
                <img
                  width="38.49"
                  src={topImage[index]}
                  className="position-absolute"
                  alt=""
                />
                {mp.user_avatar ? (
                  <div className="text-center pt-3">
                    <img
                      src={mp.user_avatar}
                      className="img-circle leader-circle-img mr-1"
                      width="70"
                      height="70"
                      style={{ objectFit: "contain" }}
                    />
                  </div>
                ) : (
                  <div className="text-center pt-3">
                    <AccountCircleIcon
                      sx={{
                        fontSize: "xx-large",
                        width: "70px",
                        height: "auto",
                      }}
                    />
                  </div>
                )}
                <div className="leader-content ellipsewe-name">
                  <h2 className="ellipsewe1">{mp.user_name}</h2>
                  <span className="initial">{mp.house}</span>
                  <br />
                  <span className="constituency ellipsewe1">
                    Constituency : {mp.constituency_name}
                  </span>
                </div>
                {cardClick === "sevaScore" ? (
                  <div className="score-container">
                    <h3>MP Seva Score</h3>
                    <span>{mp.sevaScore}</span>
                  </div>
                ) : null}
                {cardClick === "memberAdded" ? (
                  <div className="score-container">
                    <h3>Members Added</h3>
                    <span>{mp.memberAdded}</span>
                  </div>
                ) : null}
                {cardClick === "followers" ? (
                  <div className="score-container">
                    <h3>Followers</h3>
                    <span>{mp.followers}</span>
                  </div>
                ) : null}
                {cardClick === "twitterPerformance" ? (
                  <div className="score-container">
                    <h3>Twitter Performance</h3>
                    <span>{mp.twitterPerformance}</span>
                  </div>
                ) : null}
                {cardClick === "initiatives" ? (
                  <div className="score-container font-14">
                    <Grid
                      container
                      rowSpacing={1}
                      columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                    >
                      <Grid item xs={8}>
                        Initiatives
                      </Grid>
                      <Grid item xs={4}>
                        {mp.initiatives}
                      </Grid>
                      <Grid item xs={8}>
                        Event Organized
                      </Grid>
                      <Grid item xs={4}>
                        {mp.eventOrganized}
                      </Grid>
                      <Grid item xs={9}>
                        Citizen Interested in App
                      </Grid>
                      <Grid item xs={3}>
                        {mp.citizen}
                      </Grid>
                      {/* <Grid item xs={8}>
                        On-ground Participation
                        </Grid>
                        <Grid item xs={4}>
                        {mp.participation}
                        </Grid> */}
                    </Grid>
                  </div>
                ) : null}
                {cardClick === "mediaCoverage" ? (
                  <div className="score-container">
                    <Grid
                      container
                      rowSpacing={1}
                      columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                      paddingTop={2.5}
                    >
                      <Grid item xs={6}>
                        Op-Eds
                      </Grid>
                      <Grid item xs={6}>
                        {mp.opEds}
                      </Grid>
                      <Grid item xs={8}>
                        Media Coverage
                      </Grid>
                      <Grid item xs={4}>
                        {mp.mediaCoverage}
                      </Grid>
                    </Grid>
                  </div>
                ) : null}
                {cardClick === "donation" ? (
                  <div className="score-container">
                    <h3>Donations Raised</h3>
                    <span>{mp.donation}</span>
                  </div>
                ) : null}
              </div>
            </div>
          </div>
        </Grid>
      ))}
    </Grid>
  );
};

export default ThreeCards;
