import leaderboard from "../../asserts/images/leaderboard-icon.png";
import first from "../../asserts/images/1st.png";
import one from "../../asserts/images/1.jpg";
import second from "../../asserts/images/2nd.png"
import two from "../../asserts/images/4.jpg";
import third from "../../asserts/images/3rd.png";
import three from "../../asserts/images/2.jpg";
import cardImg from "../../asserts/images/leader-highlight.png";
export const MpColumnHeaders =
{
    id: '#',
    icon:' ',
    user_name: "MP Name",
    constituency_name: "Constituency",
    sevaScore: "MP Seva Score",
    initiatives: "Initiatives",
    eventOrganized: "Events Organized",
    citizen: "Citizens Interested",
    memberAdded: "Members Added",
    followers: "Followers",
    twitterPerformance: "Twitter Perfomance",
    opEds: "Op-Eds",
    mediaCoverage: "Media Coverage",
    donation: "Donations Raised"
}

export const MpColumnFilter = [{
    screenNumber: "sevaScore",
    columns: ['#'," ", "MP Name", "Constituency", "MP Seva Score"]
}, {
    screenNumber: "initiatives",
    columns: ['#'," ", "MP Name", "Constituency", "Initiatives", "Events Organized", "Citizens Interested"]
}, {
    screenNumber: "memberAdded",
    columns: ['#'," ", "MP Name", "Constituency", "Members Added"]
}, {
    screenNumber: "followers",
    columns: ['#'," ", "MP Name", "Constituency", "Followers"]
}, {
    screenNumber: "twitterPerformance",
    columns: ['#'," ", "MP Name", "Constituency", "Twitter Perfomance"]
}, {
    screenNumber: "mediaCoverage",
    columns: ['#'," ", "MP Name", "Constituency", "Op-Eds", "Media Coverage"]
}, {
    screenNumber: "donation",
    columns: ['#'," ", "MP Name", "Constituency", "Donations Raised"]
}]
export const MpSeva=[
    {"constituency_name"
        : 
        "",
        "designation"
        : 
        "MP",
        "house"
        : 
        "Lok Sabha MP",
        "party"
        : 
        "Bharathiya Janatha Party(BJP)",
        "sevaScore"
        : 
        898,
        "state_name"
        : 
        "",
        "user_avatar"
        : 
        "http://cdn.narendramodi.in/cmsuploads/0.18007300_1489647592_1489647577418.jpg",
        "user_name"
        : 
        "Pushkal saini1"}];


