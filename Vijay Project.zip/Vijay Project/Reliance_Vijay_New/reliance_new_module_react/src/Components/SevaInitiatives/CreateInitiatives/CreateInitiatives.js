import { FormHelperText, Grid, Paper, TableContainer, TableHead, Tooltip } from "@mui/material";
import { Box } from "@mui/system";
import React, { useState, useRef, useEffect } from "react";
import SideMenu from "../../SideMenu/SideMenu";
import { alpha, styled } from "@mui/material/styles";
import InputBase from "@mui/material/InputBase";
import InputLabel from "@mui/material/InputLabel";
import TextField from "@mui/material/TextField";
import FormControl from "@mui/material/FormControl";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import AddIcon from "@mui/icons-material/Add";
import Table from "@mui/material/Table";
import { TableBody, TableRow, Button } from "@mui/material";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import AddMoreImages from "./AddTextTemplates";
import ErrorOutlineIcon from "@mui/icons-material/ErrorOutline";
import { tooltipClasses } from "@mui/material/Tooltip";
import AssignToMP from "./AssingToMP";
import AddImageTemplates from "./AddImageTemplate/AddImageTemplates";
import UploadCoverImage from "./UploadCoverImage";
import AddVideoTemplate from "./AddVideoTemplate/AddVideoTemplate";
import searchIcon from "../../../asserts/images/Search.svg";
import one from "../../../asserts/images/1.jpg";
import two from "../../../asserts/images/4.jpg";
import { yupResolver } from '@hookform/resolvers/yup';
import { createInitiativeSchema } from "../../../utils/Validations";
import { useForm } from "react-hook-form";
import { Card } from '@mui/material';
import { useDispatch, useSelector } from "react-redux";
import { postIntiative } from "../../../store/action/createInitiative";
import getInitiativeList from "../../../store/action/initiativeList";
const CreateInitiatives = () => {
    const [targetedDate, setTargetDate] = useState(new Date());
    const [openTextTemplateDialog, setOpenTextTemplateDialog] = useState(false);
    const [openUploadImageDialog, setOpenUploadImageDialog] = useState(true);
    const [openVideoTemplateDialog, setOpenVideoTemplateDialog] = useState(false);
    const [openImageTemplateDialog, setOpenImageTemplateDialog] = useState(false);
    const [openAssingToMPDialog, setOpenAssingToMPDialog] = useState(false);
    const [intiative,setIntiative]=useState();
    const [image, setImage] = useState(null);
    const [preview, setPreview] = useState(null);
    const [imageName, setImageName] = useState();
    const {assignMpList}=useSelector((state)=>state?.assignMpList)
    const dispatch=useDispatch();
    const hiddenFileInput = useRef(null);

    const handleClick = event => {
        
        hiddenFileInput.current?.click();
        event?.stopPropagation();
    };

    const onFileUpload = (event) => {
        setImage(event.target.files[0]);
        setPreview(URL.createObjectURL(event.target.files[0]));
        setImageName(event.target.files[0].name);
        // handleCloseUploadImageDialog();
    };
    const formOptions = { resolver: yupResolver(createInitiativeSchema) };
    const { register, handleSubmit, formState: { errors } } = useForm(formOptions);

    // const updateMp = (idList) => {
    //     let output= assignMpList?.mpAssignData.filter(val=>{idList.includes(val.id)})
    //     // setPersonalDetail({...personalDetail,[key]:value})
    //     console.log(output,idList)
    //   }
    const handleOpenTextTemplateDialog = () => {
        setOpenTextTemplateDialog(true);
    };
    const handleCloseTextTemplateDialog = () => {
        setOpenTextTemplateDialog(false);
    };

    const handleOpenImageTemplateDialog = () => {
        setOpenImageTemplateDialog(true);
    };

    const handleCloseImageTemplateDialog = () => {
        setOpenImageTemplateDialog(false);
    };

    const handleOpenVideosTemplateDialog = () => {
        setOpenVideoTemplateDialog(true);
    };

    const handleCloseVideosTemplateDialog = () => {
        setOpenVideoTemplateDialog(false);
    };

    const handleCloseUploadImageDialog = () => {
        setOpenUploadImageDialog(false);
    };

    const handleOpenUploadImageDialog = () => {
        setOpenUploadImageDialog(true);
    };

    const handleOpenAssingToMPDialog = (data) => {
        setIntiative(data)
        setOpenAssingToMPDialog(true);
    }
    const handleCloseAssingToMPDialog = () => {
        setOpenAssingToMPDialog(false);
    }

    const onCreateInitiativeSubmit = (data) => {
        console.log("submit", data)
        
    }

    function createData(id, language, text, hashtags) {
        return { id, language, text, hashtags };
    }

    const rows = [
        // createData(1, 'English', "I am organizing a blood donation camp", "#DonateBlood"),
        // createData(2, 'Hindi', "This is the new text", "#DonateBlood"),
    ];

    const imagesData = [
        // {
        //     type: "Certificate",
        //     language: "English",
        //     imageSrc: one,
        // },
        // {
        //     type: "Social Media",
        //     language: "Hindi",
        //     imageSrc: two,
        // }
    ]

    const BootstrapInput = styled(InputBase)(({ theme }) => ({
        "label + &": {
            marginTop: theme.spacing(3),
        },
        "& .MuiInputBase-input": {
            borderRadius: 8,
            position: "relative",
            backgroundColor: theme.palette.mode === "light" ? "#fcfcfb" : "#2b2b2b",
            border: "1px solid #ced4da",
            fontSize: 16,
            width: 350,
            padding: "8px 10px",
            transition: theme.transitions.create([
                "border-color",
                "background-color",
                "box-shadow",
            ]),
            // Use the system font instead of the default Roboto font.
            fontFamily: [
                "-apple-system",
                "BlinkMacSystemFont",
                '"Segoe UI"',
                "Roboto",
                '"Helvetica Neue"',
                "Arial",
                "sans-serif",
                '"Apple Color Emoji"',
                '"Segoe UI Emoji"',
                '"Segoe UI Symbol"',
            ].join(","),
            "&:focus": {
                boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
                borderColor: theme.palette.primary.main,
            },
        },
    }));

    const BootstrapInput1 = styled(InputBase)(({ theme }) => ({
        "label + &": {
            marginTop: theme.spacing(3),
        },
        "& .MuiInputBase-input": {
            borderRadius: 8,
            position: "relative",
            backgroundColor: theme.palette.mode === "light" ? "#fcfcfb" : "#2b2b2b",
            border: "1px solid #ced4da",
            fontSize: 16,
            width: 170,
            padding: "8px 10px",
            transition: theme.transitions.create([
                "border-color",
                "background-color",
                "box-shadow",
            ]),
            // Use the system font instead of the default Roboto font.
            fontFamily: [
                "-apple-system",
                "BlinkMacSystemFont",
                '"Segoe UI"',
                "Roboto",
                '"Helvetica Neue"',
                "Arial",
                "sans-serif",
                '"Apple Color Emoji"',
                '"Segoe UI Emoji"',
                '"Segoe UI Symbol"',
            ].join(","),
            "&:focus": {
                boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
                borderColor: theme.palette.primary.main,
            },
        },
    }));

    const StyledTableCell = styled(TableCell)(({ theme }) => ({
        [`&.${tableCellClasses.head}`]: {
            backgroundColor: "#cfe1eb",
            color: "#2e739c",
        },
        [`&.${tableCellClasses.body}`]: {
            fontSize: 14,
        },
    }));

    const StyledTableRow = styled(TableRow)(({ theme }) => ({
        "&:nth-of-type(odd)": {
            backgroundColor: theme.palette.action.hover,
        },
        // hide last border
        "&:last-child td, &:last-child th": {
            border: 0,
        },
    }));

    const BootstrapTooltip = styled(({ className, ...props }) => (
        <Tooltip {...props} arrow classes={{ popper: className }} />
    ))(({ theme }) => ({
        [`& .${tooltipClasses.arrow}`]: {
            color: theme.palette.common.white,
        },
        [`& .${tooltipClasses.tooltip}`]: {
            color: theme.palette.common.black,
            backgroundColor: theme.palette.common.white,
        },
    }));

    useEffect(()=>{
        dispatch(getInitiativeList())
    },[])
    return (<>



        <div className="page-wrapper1 d-flex" >

            <SideMenu active="SevaInitiative" user="Admin" />
            {/* <Grid item xs={4} md={2} lg={2} xl={2}  >



            </Grid> */}

            <Grid item xs={8} md={10} lg={10} xl={10} className={"main-wrapper"} style={{ width: "100%" }}>
                <div className="d-flex justify-content-between align-items-center" style={{ padding: "30px", fontFamily: 'HK Grotesk' }}>
                    <h1 style={{fontFamily:'HK Grotesk',color:"#356F92",fontSize: "26px",fontWeight: "bold",width:"94%",margin:"0 auto"}}> Seva Initiatives</h1>
                    {/* <div className="search-filter-icon-admin d-flex-admin">
                        <div style={{ position: "relative", left: "90%" }}>

                            <img className="searchIcon" width={20} height={21} src={searchIcon} />

                        </div>
                    </div> */}


                
                </div>
                <form>
                    <Card sx={{ fontFamily: 'HK Grotesk', width:"90%",margin:"0 auto", padding: "45px" }}>
                        <Grid item xs={10} md={10} lg={10} xl={10} sx={{ fontFamily: 'HK Grotesk' }}>
                            <h1 style={{fontFamily:'HK Grotesk',color:"#356F92",fontSize: "22px",fontWeight: "bold"}}> Create Initiative</h1>
                            <FormControl variant="standard" sx={{ mt: 2 }} >
                                <InputLabel shrink htmlFor="bootstrap-input" sx={{ color: "#2e739c" }}>
                                    <b style={{ fontFamily: 'HK Grotesk' }}>Initiative Name</b>
                                </InputLabel>
                                <BootstrapInput id="bootstrap-input" {...register("initiativeName", { required: true })} />
                            </FormControl>
                            <FormHelperText sx={{ color: "#d32f2f" }}>
                                {errors && errors?.initiativeName?.message}
                            </FormHelperText>
                        </Grid>

                        <Grid item xs={10} md={10} lg={10} xl={10} >
                            <FormControl variant="standard" >
                                <InputLabel shrink htmlFor="bootstrap-input" sx={{ color: "#2e739c" }}>
                                    <b style={{ fontFamily: 'HK Grotesk' }}>Initiative Details</b>
                                </InputLabel>
                                <BootstrapInput id="bootstrap-input" multiline rows={2} {...register("initiativeDetails", { required: true })} />
                            </FormControl>
                            <FormHelperText sx={{ color: "#d32f2f" }}>
                                {errors && errors?.initiativeDetails?.message}
                            </FormHelperText>
                        </Grid>



                        <Grid item xs={10} md={10} lg={10} xl={10}>
                            <InputLabel shrink htmlFor="bootstrap-input" sx={{ color: "#2e739c", mt: 2 }}>
                                <b style={{ fontFamily: 'HK Grotesk' }}>Add Cover Image</b>
                            </InputLabel>

                            <div className="cls-input-sty">

                                {/* <InputLabel shrink htmlFor="bootstrap-input" sx={{ color: "#2e739c", mb: 6  }}>
                                                        <b>Upload Initiative Cover Image</b>
                                                    </InputLabel> */}
                                {/* <BootstrapInput id="bootstrap-input" > */}
                                <input type="file" ref={hiddenFileInput} style={{ display: 'none' }} onChange={onFileUpload} accept="image/*" />
                                <Button onClick={handleClick} style={{ fontFamily: 'HK Grotesk', background: "#e3f5ff", marginTop: "4px", marginLeft: "5px", borderRadius: "8px", height: "28px" }}> Browse</Button>
                                {imageName ? <Typography sx={{display:"contents"}} onClick={handleOpenUploadImageDialog}>{imageName}</Typography>  : null}
                                {/* </BootstrapInput> */}

                            </div>
                        </Grid>

                        <div style={{ display: "flex", alignItems: "center", fontFamily: 'HK Grotesk' }}>
                            <Grid item xs={10} md={10} lg={10} xl={10} >
                                <FormControl variant="standard" sx={{ mt: 2 }} >
                                    <InputLabel shrink htmlFor="bootstrap-input" sx={{ color: "#2e739c" }}>
                                        <b style={{ fontFamily: 'HK Grotesk' }}>Event Hashtag</b>
                                    </InputLabel>
                                    <BootstrapInput1 id="bootstrap-input" {...register("hashTags", { required: true })} />
                                    <FormHelperText sx={{ color: "#d32f2f" }}>
                                        {errors && errors?.hashTags?.message}
                                    </FormHelperText>
                                </FormControl>
                            </Grid>
                            <Grid item xs={10} md={10} lg={10} xl={10} sx={{ mt: 2, marginLeft: "5%" }}  >
                                <LocalizationProvider dateAdapter={AdapterDayjs} >
                                    
                                    <InputLabel shrink htmlFor="bootstrap-input" sx={{ color: "#2e739c" }}>
                                        <b style={{ fontFamily: 'HK Grotesk' }}>Target Date</b>
                                    </InputLabel>
                                    <DatePicker
                                    {...register("targetDate", { required: true })}
                                            
                                        value={targetedDate}
                                        className="cls-input-sty-1"
                                        sx={{ fontFamily: 'HK Grotesk', mt: 10, backgroundColor: "red" }}
                                        onChange={(newValue) => {
                                            setTargetDate(newValue);
                                        }}
                                        InputProps={{
                                            disableUnderline: true,

                                        }}

                                        renderInput={(params) =>
                                            <FormControl sx={{ fontFamily: 'HK Grotesk', backgroundColor: "#fcfcfb", }}
                                            >
                                                {/* <InputLabel shrink htmlFor="bootstrap-input" sx={{ color: "#2e739c" }}>
                                                            <b>Event</b>
                                                        </InputLabel> */}
                                                <TextField variant="standard"
                                                    sx={{
                                                        "& .MuiInputBase-input": {
                                                            width: "100px", // Set your height here.
                                                            marginTop: "10px",
                                                            marginLeft: "10px"
                                                        },

                                                    }}
                                                    {...params}
                                                // {...register("targetDate", { required: true })}
                                                />
                                                {/* <FormHelperText sx={{ color: "#d32f2f" }}>
                                                            {errors && errors?.targetDate?.message}
                                                        </FormHelperText> */}
                                            </FormControl>}
                                    />
                                    <FormHelperText sx={{ color: "#d32f2f" }}>
                                    {errors && errors?.targetDate?.message}</FormHelperText>
                                </LocalizationProvider>
                            </Grid>
                        </div>
                        <Grid item xs={10} md={10} lg={10} xl={10} >
                            <FormControl variant="standard" sx={{ mt: 2 }}>
                                <InputLabel shrink htmlFor="bootstrap-input" sx={{ color: "#2e739c" }}>
                                    <b style={{ fontFamily: 'HK Grotesk' }}>Steps</b>
                                </InputLabel>
                                <BootstrapInput id="bootstrap-input" multiline rows={3} {...register("steps", { required: true })} />
                                <FormHelperText sx={{ color: "#d32f2f" }}>
                                    {errors && errors?.steps?.message}
                                </FormHelperText>
                            </FormControl>
                        </Grid>

                        <Grid item xs={10} md={10} lg={10} xl={10} >
                        <h1 style={{fontFamily:'HK Grotesk',color:"#356F92",fontSize: "22px",fontWeight: "bold"}}> Create Social Media Kit</h1>
                            <Accordion sx={{ backgroundColor: "#cbe6f5", mb: 2, borderRadius: 3, fontFamily: 'HK Grotesk', mt: 2 }}
                                onClick={rows.length === 0 && handleOpenTextTemplateDialog}
                            >
                                <AccordionSummary
                                    expandIcon={<AddIcon color="primary" />}
                                    aria-controls="panel1a-content"
                                    id="panel1a-header"
                                >
                                    <Typography sx={{ fontFamily: 'HK Grotesk' }}>Add Text Templates
                                        <BootstrapTooltip title="Only files with the following extensions are allowed:png,gif,jpg,jpeg" placement="right">
                                            <ErrorOutlineIcon />
                                        </BootstrapTooltip>
                                    </Typography>
                                </AccordionSummary>
                                {rows.length > 0 ? <AccordionDetails>
                                    <TableContainer component={Paper}>
                                        <Table sx={{ minWidth: 810 }} aria-label="customized table">
                                            <TableHead>
                                                <StyledTableCell sx={{ fontFamily: 'HK Grotesk' }}>Language</StyledTableCell>
                                                <StyledTableCell sx={{ fontFamily: 'HK Grotesk' }} >Text</StyledTableCell>
                                                <StyledTableCell sx={{ fontFamily: 'HK Grotesk' }}>Hashtags</StyledTableCell>
                                            </TableHead>
                                            <TableBody>
                                                {rows.map((row) => (
                                                    <StyledTableRow key={row.id}>
                                                        <StyledTableCell component="th" scope="row">
                                                            {row.language}
                                                        </StyledTableCell>
                                                        <StyledTableCell title={row.text ? row.text : ""} >{(row.text &&
                                                            row.text.slice(0, 25)) ||
                                                            "-"}
                                                            {row.text &&
                                                                row.text.length > 25
                                                                ? "..."
                                                                : ""}{" "}</StyledTableCell>
                                                        <StyledTableCell >{row.hashtags}</StyledTableCell>
                                                    </StyledTableRow>
                                                ))}
                                                <Button variant="outlined" className="button-tr-2" startIcon={<AddIcon />} sx={{ mt: 1, ml: 1, mb: 1, fontFamily: 'HK Grotesk' }}
                                                    onClick={handleOpenTextTemplateDialog}
                                                >
                                                    Add More
                                                </Button>
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                </AccordionDetails> : null}
                            </Accordion>
                            <Accordion sx={{ backgroundColor: "#cbe6f5", mb: 2, fontFamily: 'HK Grotesk', mt: 2 }}
                            onClick={imagesData.length===0 && handleOpenImageTemplateDialog}>
                                <AccordionSummary
                                    expandIcon={<AddIcon color="primary" />}
                                    aria-controls="panel1a-content"
                                    id="panel1a-header"
                                >
                                    <Typography sx={{ fontFamily: 'HK Grotesk' }}>Add Images
                                        <BootstrapTooltip title="Only files with the following extensions are allowed:png,gif,jpg,jpeg" placement="right">
                                            <ErrorOutlineIcon />
                                        </BootstrapTooltip>
                                    </Typography>
                                </AccordionSummary>
                                {imagesData.length>0 && <AccordionDetails>
                                    <TableContainer component={Paper}>
                                        <Table sx={{ minWidth: 810 }} aria-label="customized table">
                                            {/* <TableHead>
                                                        <StyledTableCell>Language</StyledTableCell>
                                                    </TableHead>
                                                    <TableBody> */}
                                            {imagesData.map((item) => (
                                               
                                                <div>
                                                    <h6>{item.type} - {item.language}</h6>
                                                    <img src={item['imageSrc']} alt="" width="50" height="50" />
                                                </div>
                                            ))}
                                            <Button variant="outlined" className="button-tr-2" startIcon={<AddIcon />} sx={{ mt: 1, ml: 1, mb: 1, fontFamily: 'HK Grotesk' }}
                                                onClick={handleOpenImageTemplateDialog}
                                            >
                                                Add More
                                            </Button>
                                            {/* </TableBody> */}
                                        </Table>
                                    </TableContainer>
                                </AccordionDetails>}
                            </Accordion>
                            <Accordion sx={{ backgroundColor: "#cbe6f5", fontFamily: 'HK Grotesk', mt: 2 }}
                            onClick={imagesData.length===0 && handleOpenVideosTemplateDialog}>
                                <AccordionSummary
                                    expandIcon={<AddIcon color="primary" />}
                                    aria-controls="panel1a-content"
                                    id="panel1a-header"
                                >
                                    <Typography sx={{ fontFamily: 'HK Grotesk' }}>Add Videos
                                        <BootstrapTooltip title="Only files with the following extensions are allowed:png,gif,jpg,jpeg" placement="right">
                                            <ErrorOutlineIcon />
                                        </BootstrapTooltip></Typography>
                                </AccordionSummary>
                                {imagesData.length >0 &&<AccordionDetails>
                                    <TableContainer component={Paper}>
                                        <Table sx={{ minWidth: 810, fontFamily: 'HK Grotesk' }} aria-label="customized table">
                                            {/* <TableHead>
                                                        <StyledTableCell>Language</StyledTableCell>
                                                    </TableHead>
                                                    <TableBody> */}
                                            {imagesData.map((item) => (
                                                // <StyledTableRow key={row.id}>
                                                //     <StyledTableCell component="th" scope="row">
                                                //         {row.language}
                                                //     </StyledTableCell>
                                                //     <StyledTableCell title={row.text ? row.text : ""} >{(row.text &&
                                                //         row.text.slice(0, 25)) ||
                                                //         "-"}
                                                //         {row.text &&
                                                //             row.text.length > 25
                                                //             ? "..."
                                                //             : ""}{" "}</StyledTableCell>
                                                //     <StyledTableCell >{row.hashtags}</StyledTableCell>
                                                // </StyledTableRow>
                                                <div>
                                                    <h6>{item.type} - {item.language}</h6>
                                                    <img src={item['imageSrc']} alt="" width="50" height="50" />
                                                </div>
                                            ))}
                                            <Button variant="outlined" className="button-tr-2" startIcon={<AddIcon />} sx={{ mt: 1, ml: 1, mb: 1, fontFamily: 'HK Grotesk' }}
                                                onClick={handleOpenVideosTemplateDialog}
                                            >
                                                Add More
                                            </Button>
                                            {/* </TableBody> */}
                                        </Table>
                                    </TableContainer>
                                </AccordionDetails>}
                            </Accordion>

                        </Grid>
                        <Grid item xs={10} md={10} lg={10} xl={10}>
                            <Button variant="contained" onClick={handleSubmit( handleOpenAssingToMPDialog)} className="button-tr-2" sx={{ fontFamily: 'HK Grotesk', mt: 2 }}>Assign To MP</Button>

                            <AddMoreImages
                                openTextTemplateDialog={openTextTemplateDialog}
                                handleCloseTextTemplateDialog={handleCloseTextTemplateDialog}
                            />
                            <AssignToMP
                                handleCloseAssingToMPDialog={handleCloseAssingToMPDialog}
                                openAssingToMPDialog={openAssingToMPDialog}
                                intiativeData={intiative}
                                image={image}
                            />
                            <AddImageTemplates
                                handleCloseImageTemplateDialog={handleCloseImageTemplateDialog}
                                openImageTemplateDialog={openImageTemplateDialog}
                            />
                            <AddVideoTemplate
                                handleCloseVideosTemplateDialog={handleCloseVideosTemplateDialog}
                                openVideoTemplateDialog={openVideoTemplateDialog}
                            />
                            {imageName &&<UploadCoverImage
                                handleCloseUploadImageDialog={handleCloseUploadImageDialog}
                                openUploadImageDialog={openUploadImageDialog}
                                image={image}
                                setImage={setImage}
                                preview={preview}
                                setPreview={setPreview}
                                setImageName={setImageName}
                                handleClick={handleClick}
                            />}
                        </Grid>
                    </Card>
                </form>
                {/* <Grid item xs={10} md={10} lg={10} xl={10}>
                    <React.Fragment>
                        <Box sx={{ display: "flex", flexDirection: "row", pl: 28, mb: 2, mt: 2 }}>
                            <Button
                                variant="contained"
                                sx={{ p: 1, mr: 1, backgroundColor: "#ef7335", borderRadius: 4, fontFamily: 'HK Grotesk' }}
                                className="button-tr-2"
                                onClick={handleSubmit(onCreateInitiativeSubmit)}
                            >
                                Submit
                            </Button>
                            <Box sx={{ flex: "1 1 auto" }} />
                        </Box>
                    </React.Fragment>
                </Grid> */}
            </Grid>
        </div>
    </>
    )
}

export default CreateInitiatives;
