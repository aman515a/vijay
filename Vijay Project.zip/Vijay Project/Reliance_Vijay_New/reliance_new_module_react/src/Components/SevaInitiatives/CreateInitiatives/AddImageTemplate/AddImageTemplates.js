import React, { useState } from 'react';
import DialogTitle from '@mui/material/DialogTitle';
import Dialog from '@mui/material/Dialog';
import CloseIcon from '@mui/icons-material/Close';
import { FormControl, Grid, IconButton, InputLabel, Select, MenuItem, Button, FormHelperText } from '@mui/material';
import { Box } from '@mui/system';
import AddIcon from '@mui/icons-material/Add';
import UploadIcon from '@mui/icons-material/Upload';
import UploadImages from './UploadImageDialog';
import { Link } from 'react-router-dom';
import { useForm } from "react-hook-form";

const AddImageTemplates = ({ handleCloseImageTemplateDialog, openImageTemplateDialog }) => {
    const { register, unregister, handleSubmit, formState: { errors }, setValue, getValues } = useForm();

    const [dialogState, setDialogState] = useState({
        open: false,
        for: undefined
    });
    const [inputState, setInputState] = useState([{
        id: Date.now(),
        inputType: true,
        bannerSize: false,
        language: true,
        upload: true,
        remove: false
    }]);


    const languages = [
        { id: 1, value: "English" },
        { id: 2, value: "Hindi" },
        { id: 3, value: "Punjabi" }
    ]

    const imagesTypes = [
        { id: 1, value: "Indoor Banner" },
        { id: 2, value: "Outdoor Banner" },
    ]

    const removeInput = (id) => {
        const tempData = [...inputState]
        const newData = tempData.filter(input => input.id !== id)
        const index = inputState.findIndex(data => data.id === id)
        unregister(index.toString())
        setInputState(newData);
    }

    const addInput = () => {
        const newInput = {
            id: Date.now(),
            inputType: true,
            bannerSize: false,
            language: true,
            upload: true,
            remove: true
        }
        setInputState(prevState => [...prevState, newInput])
    }

    const showBannerField = (e, input) => {
        const tempData = [...inputState]
        const index = tempData.findIndex(data => data.id === input.id)
        if (e.target.value === 2) {
            tempData[index].bannerSize = true
        } else {
            tempData[index].bannerSize = false
        }
        setInputState(tempData)
    }

    const handleOpenUploadDialog = (id) => setDialogState({ open: true, for: id })
    const handleCloseUploadDialog = () => setDialogState({ open: false, for: undefined })

    const onSubmit = (data) => {
        console.log("data", data)
    }
    // console.log("er", errors[0])

    return (
        <Dialog onClose={handleCloseImageTemplateDialog} open={openImageTemplateDialog} >
            <DialogTitle sx={{ fontFamily:'HK Grotesk',color: "#2e739c",fontWeight:"700",textAlign:"center",fontSize:"26px" }}>Add Images Templates</DialogTitle>
            <IconButton
                aria-label="close"
                onClick={handleCloseImageTemplateDialog}
                sx={{
                    position: 'absolute',
                    right: 8,
                    top: 8,
                    color: (theme) => theme.palette.grey[500],
                    border: "1px solid #9e9e9e",
                    borderRadius: "50%"
                }}
            >
                <CloseIcon />
            </IconButton>
            <Box sx={{ m: 3 }}>
                <form >
                    {inputState.map((input, i) => {
                        return (
                            <div className='box' key={input.id}>
                                <Grid container>
                                <Grid item xs={6} md={6} lg={6} xl={6}>
                                {input.inputType && <Grid container spacing={2} sx={{ mt: 1 }}>
                                    <Grid item xs={12} md={12} lg={12} xl={12} sx={{width:"280px"}} >
                                        <FormControl size="small" fullWidth>
                                            <InputLabel id="demo-select-small" >Types of Images</InputLabel>
                                            <Select
                                                labelId="demo-select-small"
                                                id="demo-select-small"
                                                label="Type of Images"
                                                // required
                                                {...register(`${i}.imageType`, { required: "Required" })}
                                                onChange={e => showBannerField(e, input)}
                                            >
                                                {imagesTypes &&
                                                    imagesTypes.map((s) => {
                                                        return (
                                                            <MenuItem
                                                                native="true"
                                                                key={s.id}
                                                                sx={{ width: "100%" }}
                                                                value={s.id}
                                                                size="small"
                                                            >
                                                                {s.value}
                                                            </MenuItem>
                                                        );
                                                    })}
                                            </Select>
                                            <FormHelperText sx={{ color: "#d32f2f" }}>
                                                {errors && errors[i] && errors[i].imageType?.message}
                                            </FormHelperText>
                                        </FormControl>
                                    </Grid>
                                </Grid>}
                                {input.bannerSize
                                    && <Grid container spacing={2} sx={{ mt: 1 }}>
                                        <Grid item xs={12} md={12} lg={12} xl={12} >
                                            <FormControl size="small" fullWidth>
                                                <InputLabel
                                                >Banner Size</InputLabel>
                                                <Select
                                                    labelId="demo-select-small"
                                                    label="Banner Size"
                                                    required
                                                    {...register(`${i}.bannerSize`, { required: "Required" })}
                                                >
                                                    {languages &&
                                                        languages.map((s) => {
                                                            return (
                                                                <MenuItem
                                                                    native="true"
                                                                    key={s.id}
                                                                    sx={{ width: "100%" }}
                                                                    value={s.id}
                                                                    size="small"
                                                                >
                                                                    {s.value}
                                                                </MenuItem>
                                                            );
                                                        })}
                                                </Select>
                                                <FormHelperText sx={{ color: "#d32f2f" }}>
                                                    {errors && errors[i] && errors[i].bannerSize?.message}
                                                </FormHelperText>
                                            </FormControl>
                                        </Grid>
                                    </Grid>}
                                {input.language && <Grid container spacing={2} sx={{ mt: 1 }}>
                                    <Grid item xs={12} md={12} lg={12} xl={12}>
                                        <FormControl size="small" fullWidth>
                                            <InputLabel id="demo-select-small">Language</InputLabel>
                                            <Select
                                                labelId="demo-select-small"
                                                id="demo-select-small"
                                                label="Langauge"
                                                required
                                                {...register(`${i}.language`, { required: "Required" })}
                                            >
                                                {languages &&
                                                    languages.map((s) => {
                                                        return (
                                                            <MenuItem
                                                                native
                                                                key={s.id}
                                                                sx={{ width: "100%" }}
                                                                value={s.id}
                                                                size="small"
                                                            >
                                                                {s.value}
                                                            </MenuItem>
                                                        );
                                                    })}
                                            </Select>
                                            <FormHelperText sx={{ color: "#d32f2f" }}>
                                                {errors && errors[i] && errors[i].language?.message}
                                            </FormHelperText>
                                        </FormControl>
                                    </Grid>
                                </Grid>}
                                {input.remove && <Grid item xs={3} sx={{ mt: 1 }}>
                                    <Button
                                        variant="outlined"
                                        sx={{ borderRadius: 4 }}
                                        className="button-primary-alt-contained"
                                        onClick={() => removeInput(input.id)}
                                    >
                                        Remove
                                    </Button>
                                    {/* } */}
                                </Grid>}
                                </Grid>
                                <Grid item xs={6} md={6} lg={6} xl={6} sx={{marginTop:"20px"}}>
                                {input.upload && <Grid item  sx={{ pr: 1, pl: 1, margin: "0 auto", border:"dotted 3px #1976d2", padding:"40px",width:"50%"}}>
                                    <Box
                                        sx={{
                                            display: 'flex',
                                            '& > :not(style)': {
                                                margin: "0 auto",
                                                width: 30,
                                                height: 30,
                                                
                                            },
                                        }}
                                    >
                                        <IconButton  color="primary" aria-label="Upload" onClick={() => handleOpenUploadDialog(`${i}.images`)} sx={{  }}>
                                            <UploadIcon  />
                                        </IconButton><br />
                                        {
                                            getValues(`${i}.images`) && (
                                                <div>
                                                    <img src={getValues(`${i}.images`)[0].url} alt="" style={{ width: 210, height: 144,position:"relative",top: "45%",left: "0",transform: "translate(-50%, -50%)" }} />
                                                    {
                                                        getValues(`${i}.images`).length > 1 && <Link onClick={() => handleOpenUploadDialog(`${i}.images`)}>{getValues(`${i}.images`).length - 1} More {getValues(`${i}.images`).length > 2 ? "images" : "image"} </Link>
                                                    }
                                                </div>
                                            )
                                        }
                                    </Box>
                                </Grid>}
                                </Grid>
                                </Grid>
                            </div>
                        )
                    })}
                  
                </form>
                <div className="btn-box">
                    <React.Fragment>
                        <Box sx={{ display: "flex", flexDirection: "row", mb: 2, mt: 2 }}>
                            <Button
                                variant="outlined"
                                className="button-tr-citizen-admin"
                                startIcon={<AddIcon sx={{mt:"5px"}} />}
                                onClick={addInput}
                            >
                                Add More
                            </Button>
                            <Box sx={{ flex: "1 1 auto" }} />
                        </Box>
                    </React.Fragment>
                </div>
                  
            </Box >
            <Box sx={{ display: "flex", flexDirection: "row", mb: 2, mt: 2 }}>
                        <Button
                            variant="contained"
                            sx={{ p: 1, mr: 1, backgroundColor: "#ef7335", borderRadius: 4 ,position:"relative",left:"40%"}}
                            className="button-tr-2"
                            type='submit'
                        >
                            Save
                        </Button>
                        <Box sx={{ flex: "1 1 auto" }} />
                    </Box>
            <UploadImages
                handleCloseUploadDialog={handleCloseUploadDialog}
                state={dialogState}
                setValue={setValue}
                getValue={getValues}
            />
        </Dialog >
    );
}

export default AddImageTemplates;