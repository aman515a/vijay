import React, { useEffect, useState } from 'react';
import DialogTitle from '@mui/material/DialogTitle';
import Dialog from '@mui/material/Dialog';
import CloseIcon from '@mui/icons-material/Close';
import { IconButton, Grid, Box, Button } from '@mui/material';

const UploadImages = ({ handleCloseUploadDialog, state, setValue, getValue }) => {
    const [images, setImages] = useState([]);

    const handleVideoChange = (e) => {
        const uploadedFiles = e.target.files;
        let newImages = [];
        for (let i = 0; i < uploadedFiles.length; i++) {
            const reader = new FileReader();
            reader.readAsDataURL(uploadedFiles[i]);
            reader.onload = () => {
                newImages.push({ url: reader.result });
                if (i === uploadedFiles.length - 1) {
                    setImages(prevState => [...prevState, ...newImages])
                }
            };
        }
    };

    const handleDelete = (index) => {
        const tempImages = [...images]
        tempImages.splice(index, 1)
        setImages(tempImages)
    }

    const closeDialog = () => {
        setImages([])
        handleCloseUploadDialog()
    }

    useEffect(() => {
        images && images.length !== 0 && setValue(`${state.for}`, images)
    }, [getValue, images, setValue, state])

    useEffect(() => {
        getValue(`${state.for}`) && setImages(getValue(`${state.for}`))
    }, [getValue, state])

    return (
     
        <Dialog onClose={closeDialog} open={state.open} sx={{height:"50Vh"}}>
            <DialogTitle sx={{ fontFamily:'HK Grotesk',color: "#2e739c",fontWeight:"700",textAlign:"center",fontSize:"26px" }}>Add Image Templates</DialogTitle>
            <IconButton
                aria-label="close"
                onClick={closeDialog}
                sx={{
                    position: 'absolute',
                    right: 8,
                    top: 8,
                    color: (theme) => theme.palette.grey[500],
                    border: "1px solid #9e9e9e",
                    borderRadius: "50%"
                }}
            >
                <CloseIcon />
            </IconButton>
            <Grid item xs={6} >
<div style={{height:"50vh"}}>
                <Box
                    sx={{
                        display: 'flex',
                        '& > :not(style)': {
                            m: 1,
                            width: 30,
                            height: 30,
                        },
                    }}
                >
                    <div>
                        {images && images.map((image, index) => (
                            <div key={Date.now() + index}>
                                <img key={index} src={image.url} alt="" style={{ width: 250, height: 150 }} />
                                <Button onClick={() => handleDelete(index)}>delete</Button>
                            </div>
                        ))}
                    </div>
                  

                    {/* <Button onClick={handleClick} variant="contained" sx={{ p: 1, mr: 1, backgroundColor: "#ef7335" }}
                        className="button-primary-alt-contained">Upload Videos</Button> */}
                    {/* Add More Videos */}
                    {/* </Paper> */}
                </Box>
                <Button variant="contained" className='button-tr-2 b-center-upload' style={Styles.button}>
                        <input type="file" multiple onChange={handleVideoChange} accept="image/*" style={Styles.input} />
                        Upload Images</Button>
                </div>
             
            </Grid>
        </Dialog >
     
    )
}

const Styles = {
    button: {
        position: 'relative',
        overflow: 'hidden',
        width: 'fit-content'
    },
    input: {
        position: 'absolute',
        opacity: '0',
        cursor: 'pointer'
    }
}

export default UploadImages;