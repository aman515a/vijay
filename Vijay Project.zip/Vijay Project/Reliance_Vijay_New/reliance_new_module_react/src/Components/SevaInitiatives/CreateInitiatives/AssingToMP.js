import React, { useState, useEffect } from "react";
import DialogTitle from "@mui/material/DialogTitle";
import Dialog from "@mui/material/Dialog";
import CloseIcon from "@mui/icons-material/Close";
import {
  FormControl,
  IconButton,
  InputLabel,
  Select,
  Grid,
  MenuItem,
  Button,
  Checkbox,
  ListItemText,
  OutlinedInput,
  DialogContent,
} from "@mui/material";
import { Box } from "@mui/system";
import { useNavigate } from "react-router-dom";
import one from "../../../asserts/images/1.jpg";
import two from "../../../asserts/images/4.jpg";
import three from "../../../asserts/images/2.jpg";
import { useDispatch, useSelector } from "react-redux";
import { getAssignMpList } from "../../../store/action/assignMpList";
import { postIntiative } from "../../../store/action/createInitiative";

const AssignToMP = ({ handleCloseAssingToMPDialog, openAssingToMPDialog,intiativeData }) => {
  const {assignMpList}=useSelector((state)=>state?.assignMpList)
  const [personName, setPersonName] = React.useState([]);
  const [personId, setPersonId] = React.useState([]);
  const [selectAll, setSelectAll] = React.useState(false);
  const [intiativeDetail,setIntiativeDetail]=useState(intiativeData)
  const [confirm, setConfirm] = useState(false);
  const [rows,setRows]=useState();
  const [state,setState]=useState("")
  const navigate = useNavigate();
  const dispatch=useDispatch();
  console.log(personId,"assignmp")
  const stateList = [
    { id: 1, value: "Delhi" },
    { id: 2, value: "Punjab" },
  ]; 
  useEffect(()=>{
    console.log(state)
    // dispatch()
    dispatch(getAssignMpList(state));
    setPersonId([])
    setPersonName([])
    console.log(rows,rows?.length,"row coming")
  },[state])

  useEffect(()=>{
    setRows(assignMpList?.mpAssignData)
  },[assignMpList])

  
  const ITEM_HEIGHT = 48;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
      },
    },
  };


  const handleChange = (event) => {

    // const {
      console.log("handle hanges",event.target.value)
    //   target: { value },
    // } = event;
    setState(event.target.value);
    // if (value?.indexOf("select-all") > -1) {
    //   setSelectAll(!selectAll);
    //   setPersonName(selectAll ? [] : [...rows]);
    // } else {
    //   setPersonName(typeof value === "string" ? value.split(",") : value);
    //   setSelectAll(rows.every((r) => value.includes(r)));
    // }
  };

  return (
    <>
      <Dialog onClose={handleCloseAssingToMPDialog} open={openAssingToMPDialog}>
        <DialogTitle
          sx={{
            fontFamily: "HK Grotesk",
            color: "#2e739c",
            fontWeight: "700",
            textAlign: "center",
            fontSize: "26px",
          }}
        >
          Assign To MP
        </DialogTitle>
        <IconButton
          aria-label="close"
          onClick={handleCloseAssingToMPDialog}
          sx={{
            position: "absolute",
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
            border: "1px solid #9e9e9e",
            borderRadius: "50%",
          }}
        >
          <CloseIcon />
        </IconButton>

        <div style={{ margin: "0 auto" }}>
          <Grid container>
            <FormControl sx={{ m: 1, width: 400 }} size="small" fullWidth>
              <InputLabel id="demo-select-small">Select State</InputLabel>
              <Select
                labelId="demo-select-small"
                id="demo-select-small"
                // value={age}
                label="Select State"
                onChange={handleChange}
              >
                {stateList &&
                  stateList.map((s) => {
                    return (
                      <MenuItem
                        native
                        key={s.id}
                        sx={{ width: "100%" }}
                        value={s.value}
                        size="small"
                      >
                        {s.value}
                      </MenuItem>
                    );
                  })}
              </Select>
            </FormControl>
          </Grid>

          <Grid container>
            <FormControl sx={{ m: 1, width: 400 }} size="small" fullWidth>
              <InputLabel id="demo-select-small">Select MP</InputLabel>
              {/* <Button onClick={handleSelectAll}>Select All</Button> */}
              <Select
                labelId="demo-multiple-checkbox-label"
                id="demo-multiple-checkbox"
                multiple
                value={personName}
                // onChange={handleChange}
                input={<OutlinedInput label="Select MP" />}
                renderValue={(selected) => selected.join(", ")}
                MenuProps={MenuProps}
              >
                <MenuItem key={"select-all"} value={"select-all"}>
                  <Checkbox checked={selectAll} />
                  <ListItemText primary={"Select All"} />
                </MenuItem>
                {rows?.map((row) => (
                  <MenuItem key={row.id} value={row.user_name}>
                    <Checkbox
                      checked={personId.indexOf(row.id) > -1}
                      onClick={() => {
                        const newSelection = [...personName];
                        const newSelectionId=[...personId];
                        if (personId.indexOf(row.id) > -1) {
                          console.log("in if",personName,row.id)
                          newSelection.splice(personName.indexOf(row.user_name), 1);
                          newSelectionId.splice(personId.indexOf(row.id), 1);
                        } else {
                          newSelectionId.push(row.id);
                          newSelection.push(row.user_name);
                        }
                        setPersonName(newSelection);
                        setPersonId(newSelectionId)
                        console.log(personName,newSelection,newSelection.length,rows.length)
                        setSelectAll(
                          newSelectionId.length === rows.length &&
                            newSelectionId.length !== 0
                        );
                      }}
                    />
                    <ListItemText primary={row.user_name} />
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
        </div>
        <React.Fragment>
          <Box
            sx={{ display: "flex", flexDirection: "row", pl: 10, mb: 2, mt: 2 }}
          >
            <Button
              variant="contained"
              sx={{
                p: 1,
                mr: 1,
                backgroundColor: "#ef7335",
                borderRadius: 4,
                position: "relative",
                left: "27%",
              }}
              className="button-primary-alt-contained"
              onClick={() => {
                console.log(intiativeDetail,"ini")
                setIntiativeDetail({...intiativeData, mplist:[rows.filter(obj => personId.includes(obj.id))]});
                setConfirm(true)}}
              // onClick={handleSubmit(onAddDevelopmentProject)}
            >
              ASSIGN & CREATE INITIATIVE
            </Button>
            <Box sx={{ flex: "1 1 auto" }} />
          </Box>
        </React.Fragment>
      </Dialog>
      <Dialog open={confirm} onClose={() => setConfirm(false)}>
        <IconButton
          aria-label="close"
          onClick={() => setConfirm(false)}
          sx={{
            position: "absolute",
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
            border: "1px solid #9e9e9e",
            borderRadius: "50%",
          }}
        >
          <CloseIcon />
        </IconButton>
        <DialogContent>
          Multiple Mps have created events for this initiative. Are you sure you
          want to update this initiative.
        </DialogContent>
        <Button onClick={() => {
          // setIntiativeDetail({...intiativeDetail, mpList: });
          dispatch(postIntiative(intiativeDetail))
          setConfirm(false);handleCloseAssingToMPDialog()}}> Confirm</Button>
      </Dialog>
    </>
  );
};

export default AssignToMP;
