import React, { useEffect, useState } from 'react';
import DialogTitle from '@mui/material/DialogTitle';
import Dialog from '@mui/material/Dialog';
import CloseIcon from '@mui/icons-material/Close';
import { IconButton, Grid, Box, Button } from '@mui/material';

const UploadVideos = ({ handleCloseUploadDialog, state, setValue, getValue }) => {
    const [videos, setVideos] = useState([]);

    const handleVideoChange = (e) => {
        const uploadedFiles = e.target.files;
        let newVideos = [];
        for (let i = 0; i < uploadedFiles.length; i++) {
            const reader = new FileReader();
            reader.readAsDataURL(uploadedFiles[i]);
            reader.onload = () => {
                newVideos.push({ url: reader.result });
                if (i === uploadedFiles.length - 1) {
                    setVideos(prevState => [...prevState, ...newVideos])
                }
            };
        }
    };

    const handleDelete = (index) => {
        const tempImages = [...videos]
        tempImages.splice(index, 1)
        setVideos(tempImages)
    }

    const closeDialog = () => {
        setVideos([])
        handleCloseUploadDialog()
    }

    useEffect(() => {
        videos && videos.length !== 0 && setValue(`${state.for}`, videos)
    }, [getValue, videos, setValue, state])

    useEffect(() => {
        getValue(`${state.for}`) && setVideos(getValue(`${state.for}`))
    }, [getValue, state])

    return (
        <Dialog onClose={closeDialog} open={state.open} >
            <DialogTitle sx={{ fontFamily:'HK Grotesk',color: "#2e739c",fontWeight:"700",textAlign:"center",fontSize:"26px" }}>Add Video Templates</DialogTitle>
            <IconButton
                aria-label="close"
                onClick={closeDialog}
                sx={{
                    position: 'absolute',
                    right: 8,
                    top: 8,
                    color: (theme) => theme.palette.grey[500],
                }}
            >
                <CloseIcon />
            </IconButton>
            <Grid item xs={6} >
<div style={{height:"50vh"}}>
                <Box
                    sx={{
                        display: 'flex',
                        '& > :not(style)': {
                            m: 1,
                            width: 30,
                            height: 30,
                        },
                    }}
                >
                    <div>
                        {videos && videos.map((image, index) => (
                            <div key={Date.now() + index}>
                                <video key={index} src={image.url} alt="" style={{ width: 250, height: 150 }} />
                                <Button onClick={() => handleDelete(index)}>delete</Button>
                            </div>
                        ))}
                    </div>
                    

                    {/* <Button onClick={handleClick} variant="contained" sx={{ p: 1, mr: 1, backgroundColor: "#ef7335" }}
                        className="button-primary-alt-contained">Upload Videos</Button> */}
                    {/* Add More Videos */}
                    {/* </Paper> */}
                </Box>
                <Button variant="contained" className='button-tr-2 b-center-upload' style={Styles.button}>
                        <input type="file" multiple onChange={handleVideoChange} accept="video/mp4" style={Styles.input} />
                        Upload Videos</Button>
                        </div>
            </Grid>
        </Dialog >
    )
}

const Styles = {
    button: {
        position: 'relative',
        overflow: 'hidden',
        width: 'fit-content'
    },
    input: {
        position: 'absolute',
        opacity: '0',
        cursor: 'pointer'
    }
}

export default UploadVideos;