import React, { useState } from 'react';
import DialogTitle from '@mui/material/DialogTitle';
import Dialog from '@mui/material/Dialog';
import CloseIcon from '@mui/icons-material/Close';
import { FormControl, Grid, IconButton, InputLabel, Select, MenuItem, TextField, Button, FormHelperText } from '@mui/material';
import { Box } from '@mui/system';
import AddIcon from '@mui/icons-material/Add';
// import { textTemplatesSchema } from "../../../utils/Validations";
import { useForm, useFieldArray } from "react-hook-form";
import { yupResolver } from '@hookform/resolvers/yup';

const AddTextTemplates = ({ handleCloseTextTemplateDialog, openTextTemplateDialog }) => {
    // const [inputList, setInputList] = useState([{ language: null, text: "", hashtag: "" }]);

    const { register, control, handleSubmit, formState: { errors } } = useForm({
        defaultValues: {
            test: [{ language: "", text: "", hashtag: "" }]
        }
    });

    const {
        fields,
        append,
        remove,
    } = useFieldArray({
        control,
        name: "test"
    });

    const languages = [
        { id: 1, value: "English" },
        { id: 2, value: "Hindi" },
        { id: 3, value: "Punjabi" }
    ]
    // console.log("errors", errors?.test[0].text.message)
    // const handleInputChange = (e, index) => {
    //     const { name, value } = e.target;
    //     const list = [...inputList];
    //     list[index][name] = value;
    //     setInputList(list);
    // };

    // const handleRemoveClick = index => {
    //     const list = [...inputList];
    //     list.splice(index, 1);
    //     setInputList(list);
    // };

    // const handleAddClick = () => {
    //     setInputList([...inputList, { language: "", text: "", hashtag: "" }]);
    // };

    const onAddTextTemplateSubmit = (data) => {
        console.log("data", data)
        handleCloseTextTemplateDialog()
    }

    return (
        <Dialog onClose={handleCloseTextTemplateDialog} open={openTextTemplateDialog} >
            <DialogTitle sx={{ fontFamily:'HK Grotesk',color: "#2e739c",fontWeight:"700",textAlign:"center",fontSize:"26px" }}>Add Text Templates</DialogTitle>
            <IconButton
                aria-label="close"
                onClick={handleCloseTextTemplateDialog}
                sx={{
                    position: 'absolute',
                    right: 8,
                    top: 8,
                    color: (theme) => theme.palette.grey[500],
                    border: "1px solid #9e9e9e",
                    borderRadius: "50%"
                }}
            >
                <CloseIcon />
            </IconButton>
            <Box sx={{ m: 3 }}>
                <form>
                    {fields.map((item, index) => {
                        return (
                            <div className="box">
                                <Grid container spacing={2} >
                                    <Grid item xs={3} >
                                        <FormControl size="small" fullWidth>
                                            <InputLabel id="demo-select-small">Language</InputLabel>
                                            <Select
                                                labelId="demo-select-small"
                                                id="demo-select-small"
                                                // value={age}
                                                // value={x.language}
                                                // onChange={e => handleInputChange(e, i)}
                                                label="Language"
                                                {...register(`test.${index}.language`, { required: "Please select language of the text" })}
                                            // onChange={handleChange}
                                            >
                                                {languages &&
                                                    languages.map((s) => {
                                                        return (
                                                            <MenuItem
                                                                native
                                                                key={s.id}
                                                                sx={{ width: "100%" }}
                                                                value={s.id}
                                                                size="small"
                                                            >
                                                                {s.value}
                                                            </MenuItem>
                                                        );
                                                    })}
                                            </Select>
                                            <FormHelperText sx={{ color: "#d32f2f" }}>
                                                {errors && errors?.test && errors?.test[index] && errors?.test[index].language?.message}
                                            </FormHelperText>
                                        </FormControl>
                                    </Grid>
                                    <Grid item xs={3}>
                                        <FormControl>
                                            <TextField
                                                className="stepperFormInput"
                                                label="Text"
                                                // name={"text" + i}
                                                fullWidth
                                                placeholder="Enter text"
                                                size="small"
                                                multiline
                                                rows={2}
                                                required
                                                inputProps={{ maxLength: 255 }}
                                                // value={x.text}
                                                // onChange={e => handleInputChange(e, i)}
                                               
                                                {...register(`test.${index}.text`, { required: "Please enter the text" })}
                                                autoComplete="off"
                                            // error={errors?.text}
                                            // helperText={`${errors}?.test.${index}.text.message`}
                                            />
                                            <FormHelperText sx={{ color: "#d32f2f" }}>
                                                {errors && errors?.test && errors?.test[index] && errors?.test[index].text?.message}
                                            </FormHelperText>
                                        </FormControl>
                                    </Grid>
                                    <Grid item xs={3}>
                                        <FormControl>
                                            <TextField
                                                className="stepperFormInput"
                                                label="Hashtag"
                                                // name={"hashtag" + i}
                                                fullWidth
                                                // value={x.hashtag}
                                                // onChange={e => handleInputChange(e, i)}
                                                // placeholder="Enter text"
                                                inputProps={{ maxLength: 55 }}
                                                size="small"
                                                required
                                                {...register(`test.${index}.hashtag`, { required: "Please create a hashtag" })}
                                                multilinez
                                                autoComplete="off"
                                            />
                                            <FormHelperText sx={{ color: "#d32f2f" }}>
                                                {errors && errors?.test && errors?.test[index] && errors?.test[index].hashtag?.message}
                                            </FormHelperText>
                                        </FormControl>
                                    </Grid>
                                    <Grid item xs={3}>
                                        {fields.length !== index && index !== 0 && <Button
                                            variant="outlined"
                                            sx={{ borderRadius: 4 }}
                                            className="button-primary-alt-contained"
                                            // startIcon={<AddIcon />}
                                            onClick={() => remove(index)}
                                        >
                                            Remove
                                        </Button>}
                                    </Grid>
                                </Grid>
                                <div className="btn-box">
                                    <React.Fragment>
                                        <Box sx={{ display: "flex", flexDirection: "row", mb: 2, mt: 2 }}>
                                            {fields.length - 1 === index && <Button
                                                variant="outlined"
                                                // sx={{ borderRadius: 4 }}
                                                className="button-tr-citizen-admin"
                                                startIcon={<AddIcon sx={{mt:"5px"}}/>}
                                                // onClick={handleAddClick}
                                                onClick={() => {
                                                    append({ language: "", text: "", hashtag: "" });
                                                }}
                                            >
                                                Add More
                                            </Button>}
                                            <Box sx={{ flex: "1 1 auto" }} />
                                        </Box>
                                    </React.Fragment>
                                </div>
                                {/* <div style={{ marginTop: 20 }}>{JSON.stringify(inputList)}</div> */}
                            </div>
                        );
                    })}
                </form>
                <React.Fragment>
                    <Box sx={{ display: "flex", flexDirection: "row", justifyContent:"center", mb: 2, mt: 2, }}>
                        <Button
                            variant="contained"
                            
                            sx={{ p: 1, mr: 1, backgroundColor: "#ef7335", borderRadius: 4,position:"relative",left:"40%" }}
                            className="button-tr-2"
                            onClick={handleSubmit(onAddTextTemplateSubmit)}
                        >
                            Save
                        </Button>
                        <Box sx={{ flex: "1 1 auto" }} />
                    </Box>
                </React.Fragment>
            </Box >
        </Dialog >
    );
}

export default AddTextTemplates;