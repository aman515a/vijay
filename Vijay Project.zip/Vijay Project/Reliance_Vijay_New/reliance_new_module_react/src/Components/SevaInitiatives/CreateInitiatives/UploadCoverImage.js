import { Dialog, DialogTitle, IconButton, Grid, Box, Button } from "@mui/material";
import CloseIcon from '@mui/icons-material/Close';
import React, { useRef, useState } from "react";

const UploadCoverImage = ({ openUploadImageDialog, handleCloseUploadImageDialog, setImageName, setImage, preview, setPreview ,handleClick}) => {
    const hiddenFileInput = useRef(null);

    // const handleClick = event => {
    //     hiddenFileInput.current.click();
    // };

    const onFileUpload = (event) => {
        setImage(event.target.files[0]);
        setPreview(URL.createObjectURL(event.target.files[0]));
        setImageName(event.target.files[0].name);
        // handleCloseUploadImageDialog();
    };

    const onDelete = () => {
        setImage(null);
        setImageName(null);
        setPreview(null);
    }
    return (
        <Dialog onClose={handleCloseUploadImageDialog} open={openUploadImageDialog} >
            <DialogTitle sx={{ fontFamily:'HK Grotesk',color: "#2e739c",fontWeight:"700",textAlign:"center",fontSize:"26px" }}>Upload Initiative Cover Image</DialogTitle>
            <IconButton
                aria-label="close"
                onClick={handleCloseUploadImageDialog}
                sx={{
                    position: 'absolute',
                    right: 8,
                    top: 8,
                    color: (theme) => theme.palette.grey[500],
                    border: "1px solid #9e9e9e",
                    borderRadius: "50%"
                }}
            >
                <CloseIcon />
            </IconButton>
            <div style={{marginLeft:"10%"}}>
            <Grid container>
                {preview && (
                    <div>
                        <img src={preview} alt="Preview" style={{ width: 250, height: 150 }} />
                        <IconButton
                            aria-label="close"
                            onClick={onDelete}
                            sx={{
                               width:"12px",
                               height:"12px",
                                right: "32px",
                                top: "-56px",
                                color: (theme) => theme.palette.grey[500],
                                border: "1px solid #2C2C2C",
                                borderRadius: "50%",
                                color:"#fff",
                                backgroundColor:"#2C2C2C",
                                padding:"12px"
                            }}
                            
                        >
                            <CloseIcon />
                        </IconButton>
                    </div>
                )}
                {/* {fileName ? fileName : null} */}

         
            </Grid>
            <React.Fragment>
                <Box sx={{ display: "flex", flexDirection: "row", mb: 2, mt: 2 }}>
                    <input type="file" ref={hiddenFileInput} style={{ display: 'none' }} onChange={onFileUpload} accept="image/*" />
                    <Button
                        variant="contained"
                        sx={{ p: 1, mr: 1, backgroundColor: "#ef7335", borderRadius: 4 }}
                        className="button-tr-2"
                        onClick={handleClick}
                    >
                        Upload
                    </Button>
                    {/* <input type="file" ref={hiddenFileInput} style={{ display: 'none' }} onChange={onFileUpload} accept="image/*" />
                    <Button onClick={handleClick}>Add Cover Image</Button>
                    {fileName ? fileName : null} */}
                    <Box sx={{ flex: "1 1 auto" }} />
                </Box>
            </React.Fragment>
            </div>
        </Dialog >
    )
}

export default UploadCoverImage;