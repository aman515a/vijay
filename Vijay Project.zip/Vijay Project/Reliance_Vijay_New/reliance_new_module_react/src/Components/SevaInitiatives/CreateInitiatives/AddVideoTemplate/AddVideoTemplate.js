import React, { useState } from 'react';
import DialogTitle from '@mui/material/DialogTitle';
import Dialog from '@mui/material/Dialog';
import CloseIcon from '@mui/icons-material/Close';
import { FormControl, Grid, IconButton, InputLabel, Select, MenuItem, Button, FormHelperText } from '@mui/material';
import { Box } from '@mui/system';
import AddIcon from '@mui/icons-material/Add';
import UploadIcon from '@mui/icons-material/Upload';
import { Link } from 'react-router-dom';
import { useForm } from "react-hook-form";
import UploadVideos from './UploadVideoDialog';

const AddVideoTemplates = ({ handleCloseVideosTemplateDialog, openVideoTemplateDialog }) => {
    const { register, unregister, handleSubmit, formState: { errors }, setValue, getValues } = useForm();

    const [dialogState, setDialogState] = useState({
        open: false,
        for: undefined
    });
    const [inputState, setInputState] = useState([{
        id: Date.now(),
        language: true,
        upload: true,
        remove: false
    }]);


    const languages = [
        { id: 1, value: "English" },
        { id: 2, value: "Hindi" },
        { id: 3, value: "Punjabi" }
    ]

    const removeInput = (id) => {
        const tempData = [...inputState]
        const newData = tempData.filter(input => input.id !== id)
        const index = inputState.findIndex(data => data.id === id)
        unregister(index.toString())
        setInputState(newData);
    }

    const addInput = () => {
        const newInput = {
            id: Date.now(),
            language: true,
            upload: true,
            remove: true
        }
        setInputState(prevState => [...prevState, newInput])
    }

    const handleOpenUploadDialog = (id) => setDialogState({ open: true, for: id })
    const handleCloseUploadDialog = () => setDialogState({ open: false, for: undefined })

    const onSubmit = (data) => {
        console.log("data", data)
    }

    return (
        <Dialog onClose={handleCloseVideosTemplateDialog} open={openVideoTemplateDialog} >
            <DialogTitle sx={{ fontFamily:'HK Grotesk',color: "#2e739c",fontWeight:"700",textAlign:"center",fontSize:"26px" }}>Add Video Templates</DialogTitle>
            <IconButton
                aria-label="close"
                onClick={handleCloseVideosTemplateDialog}
                sx={{
                    position: 'absolute',
                    right: 8,
                    top: 8,
                    color: (theme) => theme.palette.grey[500],
                    border: "1px solid #9e9e9e",
                    borderRadius: "50%"
                }}
            >
                <CloseIcon />
            </IconButton>
            <Box sx={{ m: 3 }}>
                <form onSubmit={handleSubmit(onSubmit)}>
                    {inputState.map((input, i) => {
                        return (
                            <div className='box' key={input.id}>
                                 <Grid container>
                                <Grid item xs={6} md={6} lg={6} xl={6}>
                                {input.language && <Grid container spacing={2} sx={{ mt: 0.5 }}>
                                    <Grid item xs={12} md={12} lg={12} xl={12} sx={{width:"280px"}}>
                                        <FormControl size="small" fullWidth>
                                            <InputLabel id="demo-select-small">Language</InputLabel>
                                            <Select
                                                labelId="demo-select-small"
                                                id="demo-select-small"
                                                label="Langauge"
                                                {...register(`${i}.language`, { required: "Required" })}
                                            >
                                                {languages &&
                                                    languages.map((s) => {
                                                        return (
                                                            <MenuItem
                                                                native
                                                                key={s.id}
                                                                sx={{ width: "100%" }}
                                                                value={s.id}
                                                                size="small"
                                                            >
                                                                {s.value}
                                                            </MenuItem>
                                                        );
                                                    })}
                                            </Select>
                                            <FormHelperText sx={{ color: "#d32f2f" }}>
                                                {errors && errors[i] && errors[i].language?.message}
                                            </FormHelperText>
                                        </FormControl>
                                    </Grid>
                                </Grid>}
                                {input.remove && <Grid item xs={3} sx={{ mt: 1 }}>
                                    <Button
                                        variant="outlined"
                                        sx={{ borderRadius: 4 }}
                                        className="button-primary-alt-contained"
                                        onClick={() => removeInput(input.id)}
                                    >
                                        Remove
                                    </Button>
                                    {/* } */}
                                </Grid>}
                                </Grid>
                                <Grid item xs={6} md={6} lg={6} xl={6} sx={{marginTop:"20px"}}>
                                {input.upload && <Grid item xs={6} sx={{ pr: 1, pl: 1, margin: "0 auto", border:"dotted 3px #1976d2", padding:"40px",width:"50%"}}>
                                    <Box
                                        sx={{
                                            display: 'flex',
                                            '& > :not(style)': {
                                                margin: "0 auto",
                                                width: 30,
                                                height: 30,
                                            },
                                        }}
                                    >
                                        <IconButton color="primary" aria-label="Upload" onClick={() => handleOpenUploadDialog(`${i}.videos`)} sx={{ ml: 5, mt: 3 }}>
                                            <UploadIcon />
                                        </IconButton><br />
                                        {
                                            getValues(`${i}.videos`) && (
                                                <div>
                                                    <video src={getValues(`${i}.videos`)[0].url} alt="" style={{ width: 210, height: 144,position:"relative",top: "45%",left: "0",transform: "translate(-50%, -50%)" }} />
                                                    {
                                                        getValues(`${i}.videos`).length > 1 && <Link onClick={() => handleOpenUploadDialog(`${i}.videos`)}>{getValues(`${i}.videos`).length - 1} More {getValues(`${i}.videos`).length > 2 ? "videos" : "image"} </Link>
                                                    }
                                                </div>
                                            )
                                        }
                                    </Box>
                                </Grid>}
                                </Grid>
                                </Grid>
                            </div>
                        )
                    })}
               
                </form>
                <div className="btn-box">
                    <React.Fragment>
                        <Box sx={{ display: "flex", flexDirection: "row", mb: 2, mt: 2 }}>
                            <Button
                                variant="outlined"
                                sx={{ borderRadius: 4 }}
                                className="button-tr-citizen-admin"
                                startIcon={<AddIcon sx={{mt:"5px"}} />}
                                onClick={addInput}
                            >
                                Add More
                            </Button>
                            <Box sx={{ flex: "1 1 auto" }} />
                        </Box>
                    </React.Fragment>
                </div>
            </Box >
            <Box sx={{ display: "flex", flexDirection: "row", mb: 2, mt: 2 }}>
                        <Button
                            variant="contained"
                            sx={{ p: 1, mr: 1, backgroundColor: "#ef7335", borderRadius: 4,position:"relative",left:"40%" }}
                            className="button-tr-2"
                            type='submit'
                        >
                            Save
                        </Button>
                        <Box sx={{ flex: "1 1 auto" }} />
                    </Box>
            <UploadVideos
                handleCloseUploadDialog={handleCloseUploadDialog}
                state={dialogState}
                setValue={setValue}
                getValue={getValues}
            />
        </Dialog >
    );
}

export default AddVideoTemplates;