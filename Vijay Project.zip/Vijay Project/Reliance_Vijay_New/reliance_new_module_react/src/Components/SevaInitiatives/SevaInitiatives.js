/* eslint-disable react/jsx-no-duplicate-props */
import { Grid, Paper, Typography, Button } from "@mui/material";
import { Box } from "@mui/system";
import { useNavigate } from 'react-router';
import React, { useEffect } from "react";
import SideMenu from "../SideMenu/SideMenu";
import BorderColorIcon from '@mui/icons-material/BorderColor';
import { Link } from "react-router-dom";
import searchIcon from "../../asserts/images/Search.svg";

import editIcon from "../../asserts/images/Edit.svg";
import illimageIcon from "../../asserts/images/Illustration.svg";
import { useDispatch, useSelector } from "react-redux";
import getInitiativeList from "../../store/action/initiativeList";

const SevaInitiatives = () => {
    const navigate = useNavigate();
    const initiativeList=useSelector((state)=>state?.initiativeList?.data)
  
    const dispatch=useDispatch();
    const handleCreateNew = () => {
        navigate("/SevaInitiatives/createInitiative")
    }

    useEffect(()=>{
        dispatch(getInitiativeList())
    },[])
    return (<>
       
        <div className="page-wrapper d-flex" style={{ height: "100vh" }}>
        <SideMenu active="SevaInitiative" user="Admin"/>
        <div className="main-wrapper" style={{ width: "100%" }}>
        
            <Grid container >
            <Grid md={12} lg={12} xl={12}>
            <div className="d-flex justify-content-between align-items-center" >
                        <h1  style={{fontFamily:'HK Grotesk',color:"#356F92",fontSize: "26px",fontWeight: "bold",marginLeft:"10px"}}> Seva Initiative</h1>
                        <div className="search-filter-icon-admin d-flex-admin">
                            <div style={{position: "relative",left: "90%"}}>
                            {/* <a className="d-block mr-2" href=""> */}
                                {/* <svg
                                    className="searchIcon position-absolute"
                                    width="20"
                                    height="21"
                                    viewBox="0 0 20 21"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                >
                                    <path
                                        d="M9.58317 18.6253C4.87484 18.6253 1.0415 14.792 1.0415 10.0837C1.0415 5.37533 4.87484 1.54199 9.58317 1.54199C14.2915 1.54199 18.1248 5.37533 18.1248 10.0837C18.1248 14.792 14.2915 18.6253 9.58317 18.6253ZM9.58317 2.79199C5.55817 2.79199 2.2915 6.06699 2.2915 10.0837C2.2915 14.1003 5.55817 17.3753 9.58317 17.3753C13.6082 17.3753 16.8748 14.1003 16.8748 10.0837C16.8748 6.06699 13.6082 2.79199 9.58317 2.79199Z"
                                        fill="#5c819e"
                                    />
                                    <path
                                        d="M18.3335 19.4585C18.1752 19.4585 18.0169 19.4002 17.8919 19.2752L16.2252 17.6085C15.9835 17.3669 15.9835 16.9669 16.2252 16.7252C16.4669 16.4835 16.8669 16.4835 17.1085 16.7252L18.7752 18.3919C19.0169 18.6335 19.0169 19.0335 18.7752 19.2752C18.6502 19.4002 18.4919 19.4585 18.3335 19.4585Z"
                                        fill="#5c819e"
                                    />
                                </svg> */}
                                <img className="searchIcon" width={20} height={21} src={searchIcon}/>
                            {/* </a> */}
                            </div>
                        </div>
                    </div>
                    </Grid>

                    <div className="create-dash-new card" style={{ borderRadius:"25px",border:"1px solid #FFFFFF",padding:"15px",backgroundColor:"#e3f5ff",fontFamily:'HK Grotesk' }}>
                            <Grid container sx={{ ml: 2 }} >
                                <Typography sx={{fontFamily:'HK Grotesk',color:"#505050",fontSize: "20px",fontWeight: "bold"}}>Create Initiative</Typography>
                            </Grid>
                            <Grid container sx={{ ml: 2 }}>
                                <Grid item xs={12}>
                                    <Typography sx={{fontFamily:'HK Grotesk',color:"#505050",fontSize:"16px"}}>Would you like to  create a Seva Initiative? Add the details here</Typography>
                                </Grid>
                            </Grid>
                            <Grid container sx={{ ml: 2 }}>
                                <Button  className="button-tr1-admin" endIcon={<BorderColorIcon />}  onClick={handleCreateNew}>
                                    Create New
                                </Button>
                            </Grid>
                        </div>
                <Grid md={12} lg={12} xl={12}>
                  
         
                      
                        <Paper sx={{
                            mt: 4, width: "100%",
                            height:" 60vh",
                            borderRadius: 6,
                            overflow:"auto"
                            // position:"relative",
                            // left:"50%"
                        }}>
                            
                        {initiativeList ?<>
                        {initiativeList?.map((initiativeItem) => {
                            return(
                            <div className="create-dash-new card" style={{ marginLeft:"5px",borderRadius:"25px",border:"1px solid #FFFFFF",padding:"15px",backgroundColor:"#e3f5ff",fontFamily:'HK Grotesk' }}>
                            <Grid container sx={{ ml: 2 ,justifyContent:"space-between"}}>
                                <Typography sx={{fontSize: "20px",fontWeight: "bold"}}>{initiativeItem.initiativeName}</Typography>
                            <img style={{marginRight:"15px"}} src={editIcon}/></Grid>
                            
                        </div>)
                         })}
                        
                        
                        </>:
                            <>
                            <img className="imagecenter" src={illimageIcon} width="300"   alt=""/>
                            <div style={{display: "flex",justifyContent: "center",flexDirection:"column",alignItems:"center",marginTop:"5%"}}>
                          
                            <span style={{fontSize:"24px",color:"#356F92",fontFamily:'HK Grotesk',fontWeight: "bold"}}>No data found!</span>
                            <span style={{fontSize:"20px",color:"#2C2C2C",fontFamily:'HK Grotesk',fontWeight: "bold"}}>Click <Link to="/SevaInitiatives/createInitiative">here</Link> to create an initiative</span>
                            </div></>}
                        </Paper>
                  
                </Grid>
            </Grid >
        </div >
        </div >
        </>
    )
}

export default SevaInitiatives;