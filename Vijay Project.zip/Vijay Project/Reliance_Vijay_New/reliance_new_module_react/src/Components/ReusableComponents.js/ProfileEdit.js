import * as React from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import editIcon from "../../asserts/images/IconEdit.svg";
import camera from "../../asserts/images/Camera.svg";
import { useDispatch, useSelector } from 'react-redux';
import './index.css';
import { Card, CardActionArea, CardActions, CardContent, CardMedia, Grid, Icon, Typography } from '@mui/material';
import { updateMpProfile } from '../../store/action/individualMP';
import { getMpProfile } from '../../store/action/individualMP';

export default function ProfileEdit({setOpen,mpDetail,open}) {
  const hiddenFileInput = React.useRef(null);
  const hiddenCoverInput = React.useRef(null);
  console.log("pics at first --------", mpDetail.user_avatar)
  const [profilePic, setProfilePic] = React.useState('')
  const [coverPic, setCoverPic] = React.useState('')
  const [profilePicF, setProfilePicForm] = React.useState("")
  const [coverPicF, setCoverPicForm] = React.useState("");
  console.log("mpDetails  -- ", mpDetail)
  const dispatch = useDispatch();
  React.useEffect(()=>{
    
      setProfilePic( mpDetail.user_avatar)
      setCoverPic(mpDetail.user_avatar)
    

  },[])
  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClick = e => {
    hiddenFileInput.current.click();
};
const handleCoverClick = e =>{
  hiddenCoverInput.current.click();
}
const handleImageChange = (e,data) => {
  const uploadedFiles = e.target.files;
  console.log("upload files", data)
  let newImages = [];
  for (let i = 0; i < uploadedFiles.length; i++) {
    console.log("i",i)
      const reader = new FileReader();
      reader.readAsDataURL(uploadedFiles[i]);
      reader.onload = () => {
          newImages.push({ url: reader.result });
          if (i === uploadedFiles.length - 1) {
            if(data==="cover"){
              setCoverPic(newImages[0].url);
              setCoverPicForm(uploadedFiles)
            }
            else
            setProfilePic(newImages[0].url);
            setProfilePicForm(uploadedFiles)

              // setImages([...images, ...newImages]);
          }
      };
  }

  
};
  const handleClose = (reason) => {

    if (reason === 'update') {
      var formData= {
        "id":mpDetail.id,
        "user_name":mpDetail.user_name,
        "user_email":mpDetail.user_email,
        "user_screen_name":mpDetail.user_screen_name,
        "user_contact":"9976787877",
        "user_points":"11",
        "constituency_name":"Vinjan - 18",
        "state_name":mpDetail.state_name,
        "house":mpDetail.house,
        "user_avatar":coverPicF
        }
        
      dispatch(updateMpProfile(formData));
      setTimeout(()=> {
        dispatch(getMpProfile(mpDetail.id))
      },2000)
      
     } 
      setOpen(false);
    
  };
  console.log("coverpic", coverPic)
  return (
    <div>
      <Dialog   disableEscapeKeyDown open={open} onClose={handleClose}>
        <Grid  textAlign="center" >
        <input type="file" ref={hiddenCoverInput} style={{ display: 'none' }}  onChange={(e)=>{handleImageChange(e,"cover")} }/>
        <input type="file" ref={hiddenFileInput} style={{ display: 'none' }}  onChange={(e)=>handleImageChange(e)} />
                                                
          <Card  >
                    <CardActionArea>
                      
                    <img src={profilePic}
                                alt={mpDetail.user_name}
                                className="card-image"
                                />
                    <img src={editIcon}
                                alt={mpDetail.user_name}
                                className=" card-icon-edit-big"
                                onClick={handleClick}
                                />
                    <Button variant="contained" onClick={handleCoverClick} className="cover-edit" startIcon={<img height="inherit" src={camera} />}>
  Edit cover photo
</Button>
                {/* {mpDetail.coverimage ? */}
                                <img
                                src={coverPic}
                                alt={mpDetail.user_name}
                                height="333" 
                                />
                                {/* <Box  sx={{ backgroundColor: '#DFF6FF'}} height="333" />} */}
                <CardContent  alignItems="center" justify="center" sx={{paddingTop:"130px"}}>
                <Typography gutterBottom variant="h5" component="div" sx={{color:"#357092", fontWeight:"Bold",  fontFamily:"HK Grotesk",fontSize:"30px"}} >
                    {mpDetail.user_name}
                </Typography>
                <Typography variant="body2" color="text.secondary"sx={{color:"#11243D", fontWeight:"Bold",  fontFamily:"HK Grotesk",fontSize:"18px"}} >
                    
                {mpDetail.designation} -{mpDetail.party},<br/>
                {mpDetail.state_name}
                </Typography>
                </CardContent>
                <CardActions sx={{placeContent:"space-evenly"}} >
                <Button className="btn btn-primary primary-btn mr-4 mb-4" onClick={()=>{handleClose('update')}} >UPDATE</Button>
          <Button className="btn btn-primary normal-btn mr-4 mb-4" sx={{border:"1px blue solid"}} onClick={()=>{handleClose()}}>CANCEL</Button>
                </CardActions>
            </CardActionArea>
            </Card>
         </Grid> 
      </Dialog>
    </div>
  );
}