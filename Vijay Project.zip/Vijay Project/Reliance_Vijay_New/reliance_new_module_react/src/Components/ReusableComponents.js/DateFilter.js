import { MenuItem, Select } from '@mui/material'
import React, { useState } from 'react'
import arrowDown from "../../asserts/images/arrowDown.svg";
import './index.css';
const DateFilter = () => {
    const optionData=["Today","Yesterday","Last 7 Days", "Last 30 Days", "This Month", "All Time"]
    const [value,setValue]=useState("All Time")
   
    
    const handleChange = (e) => {
        setValue(e.target.value)
     
    }
    
  return (
    <div >
    
        <Select
        className='texdate'
          value={value} sx={{
            '& .MuiSelect-select':{
            } 
          }}
          onChange={handleChange}
          displayEmpty
          inputProps={{ 'aria-label': 'Without label' }}
          MenuProps={{
            PaperProps: {
              sx: {
                width:"320px",
                marginLeft:"85px",
                marginTop:"10px",
                // height:"322px",
                borderRadius:"14px",
                // bgcolor: 'pink',
                '& .MuiMenuItem-root': {
                  fontFamily:'HK Grotesk',
                  border: "1px solid #D3D3D3",
                  margin: "10px 20px 0",
                  borderRadius:"10px",
                  justifyContent:"center",
                  fontSize:"14px",
                  fontWeight:"bold",
                  "&$selected": {
                    backgroundColor: "#356F92",
                    color:"#000000",
                      "&:hover": {
                        backgroundColor: "#356F92"
                       }
                    },
                  '&:hover':{
                    backgroundColor:'#356F92',
                    color:"#fff",
                  },
             
                  
                },
              },
            },
          }}
        >
  
          {optionData.map((value,i)=>{
            return (
              
                <MenuItem justifyContent="center" alignItems="center" display="flex" value={value} className="dropdown-panel dropdown-option">{value}</MenuItem>
       )
          })}
          
        </Select>
        </div>
   
  )
}

export default DateFilter