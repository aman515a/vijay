import { Button, Card, CardActionArea, CardContent, CardMedia, IconButton, Typography } from '@mui/material'
import { Box } from '@mui/system';
import React, { useEffect } from 'react'
import { useNavigate } from 'react-router'
import rightArrow from '../../asserts/images/arrowRight.png'
import MemberIcon from '../../asserts/images/MemberIcon.png'
import DonationIcon from '../../asserts/images/InviteDonation.png'
import CircleBg from '../../asserts/images/CircleBg.png';
import IconEdit from '../../asserts/images/IconEdit.svg';
import ProfileEdit from './ProfileEdit';
const ProfileCard = ({profile}) => {
    // const navigate= useNavigate();
    
    const [open, setOpen] = React.useState(false);
    console.log("profile",profile)

    
    const handleEdit = () => {
      setOpen(true);
      console.log("profile edit")
      
    }
    const handleOpen =(val)=>{
      setOpen(val);
    }
    
  return (
    <Card className="right-card card">
    <div >
      <ProfileEdit mpDetail={profile} setOpen={handleOpen} open={open}/>
    <Card m={2} sx={{border: "#357092 2px solid"}} >
    <CardActionArea>
        
      <img src={IconEdit} alt="edit" className="card-icon-edit"  onClick={handleEdit}/>
    <img src={CircleBg}
                alt="bg"
                className="card-bg"
                />
    <img src={profile.user_avatar}
                alt={profile.user_name}
                className="card-icon-image"
                
                />
<CardContent  >
<Box width="50%" >
<Typography  variant="h5"  color="#357092" fontWeight="Bold" padding="0" fontFamily="HK Grotesk" fontSize="16px">
{profile?.user_name}
</Typography>
<Typography variant="body2" color="text.secondary" fontFamily="HK Grotesk" fontSize="13px" >

{profile?.designation}-{profile?.party},<br/><br/><br/>
{profile?.state_name}
</Typography>
</Box>

</CardContent>
</CardActionArea>
</Card>

{/* </div> */}

 <div className="right-card-1 ">
<div className="d-flex-gap-1 ">
                        
                            {/* <Button sx={{ textTransform: "unset", textAlign:"-webkit-left",   color: "white",    font: "inherit"}}> */}
                             
                                <div className="small-cards small-card1">
                                <p className="mb-0">
                                <img className="mr-3" src={MemberIcon} width="15"  alt=""/></p>
                            <div className="d-flex justify-content-between mt-3">
                                <p className="mb-0" >Add members to NaMo App</p>
                                <img width="24" height="21.44" className="align-bottom" src={rightArrow}/>
                            </div>
                            </div>
                            {/* </Button> */}
                            
                            {/* <Button sx={{ textTransform: "unset", textAlign:"-webkit-left",   color: "white",    font: "inherit"}}> */}
                             
                        <div className="small-cards small-card2">
                            <p className="mb-0"><img className="mr-3" src={DonationIcon} width="15" alt=""/></p>
                            <div className="d-flex justify-content-between mt-3">
                                <p className="mb-0" >Invite Donations</p>
                               <img width="24" height="21.44" className='align-text-bottom' src={rightArrow}/>
                            </div>
                        </div>
                        {/* </Button> */}
                    </div>

</div>

</div>
</Card>

  )
}

export default ProfileCard