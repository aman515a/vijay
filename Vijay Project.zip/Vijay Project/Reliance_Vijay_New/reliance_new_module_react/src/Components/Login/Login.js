import React, { useState } from 'react'
import { useNavigate } from 'react-router';
import { Button, FormControl, FormControlLabel, Grid, InputLabel, MenuItem, Paper, Select, TextField } from '@mui/material';
import mp from '../../asserts/images/MP_logo_w.png';
import backgroundImage from '../../asserts/images/par1.jpg';
import "./Login.css"
function Login({setId}) {
    const [user, setUser] = useState('');
    const [pwd, setPwd] = useState('');
    // const [role,setRole] = useState('');
    const [error, setError] = useState('');
    
const navigate=useNavigate();
    const handleSubmit=()=>{
        console.log(user,pwd,"data")
        if(user==="admin" && pwd==="admin"){
        localStorage.setItem("userId","2")
        setId("2")
        navigate("/AdminHome")
        }
        else if(user==="mp" && pwd==="mp"){
          localStorage.setItem("userId","1")
          setId("1")
          navigate("/MPHome",0)
        }
        else if(user==="leader" && pwd==="leader"){
          localStorage.setItem("userId","3")
          setId("3")
          navigate("/AdminHome")
        }
        
        else{
          setError("Kindly Check Username or Password")
        }
        // axios.post(`url`,{user,pwd,role})
        //   .then((res)=>{
        //     localStorage.setItem("user", JSON.stringify(res))
        //   }
        //   )
        //     .catch((err)=>{
        //         setError(err.message)
        //     })
    }

  return (
  //   <div className="login__"> 
    
  
  // <div style={{ padding: 30 }}>
  //     <Paper>
  //       <Grid
  //         container
  //         spacing={3}
  //         direction={'column'}
  //         justify={'center'}
  //         alignItems={'center'}
  //       >
  //          <Grid item xs={12} >
  //          <img src={mp} className="login__icon"/> Login to Your Account
  //          </Grid>
  //         <Grid item xs={12}>
  //           <TextField label="Username" onChange={(e)=>setUser(e.target.value)}></TextField>
  //         </Grid>
  //         <Grid item xs={12}>
  //           <TextField label="Password" onChange={(e)=>setPwd(e.target.value)} type={'password'}></TextField>
  //         </Grid>
  //         {/* <Grid item xs={12}>
  //         <FormControl sx={{ m: 1, minWidth: 120 }}>
  //         <InputLabel id="demo-simple-select-standard-label">Role</InputLabel>
  //       <Select
  //         labelId="demo-simple-select-standard-label"
  //         id="demo-simple-select-standard"
  //         value={role}
  //         onChange={(e)=>setRole(e.target.value)}
  //         label="Role"
  //         sx={{minWidth:"220px"}}
  //       >
  //         <MenuItem value="" selected >
  //           <em>Select</em>
  //         </MenuItem>
  //         <MenuItem value="Admin">Admin</MenuItem>
  //         <MenuItem value="MP">MP</MenuItem>
  //         <MenuItem value="Citizen">Citizen</MenuItem>
  //       </Select>
  //       </FormControl>
  //         </Grid> */}
  //         <Grid item xs={12}>
  //           <Button className="btn btn-primary primary-btn" fullWidth onClick={handleSubmit}> Login </Button>
  //         </Grid>
  //         {error &&<p className='p-error'>{error}</p>}
  //       </Grid>
  //     </Paper>
  //   </div></div>
<div style={{backgroundImage:`url(${backgroundImage})`,backgroundRepeat:"no-repeat",backgroundSize:"cover",height: "100vh"}}>
  {/*  */}
{/* <div className="container"  >
  <div className="info">
   <h1></h1>
  
  </div>
</div> */}
<div className="form">
  <div className="thumbnail"><img src={mp} alt ="thumb"/></div>
  <form className="register-form">
    <input type="text" placeholder="name"/>
    <input type="password" placeholder="password"/>
    <input type="text" placeholder="email address"/>
    <button>create</button>
    <p className="message">Already registered?<a href="#">Sign In</a></p>
  </form>
  <form className="login-form">
    <input type="text" placeholder="username" label="Username" onChange={(e)=>setUser(e.target.value)}/>
    <input type="password" placeholder="password" label="Password" onChange={(e)=>setPwd(e.target.value)}/>
    <button onClick={handleSubmit}>login</button>
    {/* <p className="message">Not registered?<a href="#">Create an account</a></p> */}
  </form>
</div>
</div>
//  </div>
  )
}

export default Login