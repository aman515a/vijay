import React, { useEffect, useState } from "react";
import leaderboard from "../../asserts/images/leaderboard-icon.png";
import profile from "../../asserts/images/Main Profile Picture@2x.png";
import { useNavigate } from "react-router-dom";
import { Button } from "@mui/material";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
const SideMenu = (props) => {
  const [active, setactive] = useState(props.active);
  const navigate = useNavigate();
  useEffect(() => {
    console.log(active);
  }, [active]);

  return (
    <div className="left-sidebar-b">
      <div className="d-flex d-flex-C">
        <div>
          {props.user === "Admin" || props.user === "Leader" ? (
            <AccountCircleIcon sx={{ fontSize: "xx-large" }} />
          ) : (
            <img
              src={profile}
              className="img-circle mr-1 profile-img"
              width="40"
            />
          )}
        </div>
        {props.user === "Admin" || props.user === "Leader" ? (
          <div className="align-self-center pr-2 sidebarLeaderName">
            Hi, Admin
            <br />
          </div>
        ) : (
          <div className="align-self-center pr-2 sidebarLeaderName d-text-align-c">
            Smt. Poonam Mahajan
            <br />
            <span>
              Lok Sabha MP,
              <br />
              Mumbai North Central
            </span>
          </div>
        )}
      </div>

      <nav>
        <ul>
          <li className="justify-content-between">
            <Button
              className={active == "Leader" && "active"}
              onClick={() => {
                setactive("Leader");
                {
                  props.user === "Admin" || props.user === "Leader"
                    ? navigate("/AdminHome")
                    : navigate("/MpHome");
                }
              }}
            >
              <span>
                <img className="mr-3" src={leaderboard} width="15" alt="" />
                Leaderboard
              </span>
            </Button>
            {/* <a href="" className="active" onClick={() => navigate('/MpHome')}><span><img className="mr-3" src={leaderboard} width="15" alt=""/>
                        Leaderboard</span></a> */}
          </li>
          {props.user === "Admin" && (
            <li className="justify-content-between">
              <Button
                className={active == "SevaInitiative" && "active"}
                onClick={() => {
                  setactive("SevaInitiative");
                  navigate("/SevaInitiatives", {
                    state: {
                      user: props.user,
                    },
                  });
                }}
              >
                <span>
                  <img className="mr-3" src={leaderboard} width="15" alt="" />
                  Seva Initiatives
                </span>
              </Button>
            </li>
          )}
          <li className="justify-content-between">
            <Button
              className={active == "Seva" && "active"}
              onClick={() => {
                setactive("Seva");
                props.user === "Admin" || props.user === "Leader"
                  ? navigate("/SevaUpdates", { state: { user: props.user } })
                  : navigate("/SevaUpdates");
              }}
            >
              <span>
                <img className="mr-3" src={leaderboard} width="15" alt="" />
                Seva Updates
              </span>
            </Button>
            {/* <a href=""><span><img className="mr-3" src={leaderboard} width="15" alt="" />
                        Save Updates</span></a> */}
          </li>
          {props.user !== "Admin" && props.user !== "Leader" && (
            <li className="justify-content-between">
              <Button
                className={active == "Initiative" && "active"}
                onClick={() => {
                  setactive("Initiative");
                  navigate("/Initiatives");
                }}
              >
                <span>
                  <img className="mr-3" src={leaderboard} width="15" alt="" />
                  Your Initiatives
                </span>
              </Button>
            </li>
          )}
          <li className="justify-content-between">
            <Button
              onClick={() => {
                localStorage.removeItem("userId");
                // navigate("/")
                window.location.reload();
              }}
            >
              <span>
                <img className="mr-3" src={leaderboard} width="15" alt="" />
                Logout
              </span>
            </Button>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default SideMenu;
