import * as React from 'react';
import PropTypes from 'prop-types';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import CssBaseline from '@mui/material/CssBaseline';
import Divider from '@mui/material/Divider';
import Drawer from '@mui/material/Drawer';
import IconButton from '@mui/material/IconButton';
import InboxIcon from '@mui/icons-material/MoveToInbox';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import MailIcon from '@mui/icons-material/Mail';
import MenuIcon from '@mui/icons-material/Menu';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import { Avatar, Button, Card, CardActions, CardContent, CardMedia, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';
// import CardComponent from '../Card/CardComponent';
import { ArrowForward, FiberManualRecord, Groups2Outlined, Leaderboard, VolunteerActivismOutlined } from '@mui/icons-material';
import CardComponent from '../Card/CardComponent';
import card1 from '../../asserts/highlights/card1.png';
import profile from '../../asserts/profile.jpg';
import { borderColor } from '@mui/system';
const drawerWidth = 340;
function createData(heading, value) {
    console.log(heading,value)
    return { heading, value };
  }
  const sampleInitiatives={
    "Initiatives Undertaken":"4,365",
    "Events Conducted":"21,495",
    "Members Added":"4.8 M",
    "Development Projects":"1800",
    "Donation Received":"1.3 B",
    "Media Coverage":"78,780",
    "Op-Eds":"65,430",
    "Book Published":"12,138"
  }
  
  const rows =
  Object.keys( sampleInitiatives).map((val)=>{
    console.log(val,sampleInitiatives[val])
    return createData(val,sampleInitiatives[val])
    }) 
  
function SideMenu(props) {
  const { window } = props;
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const highlights=['4361 Initiatives undertake in last 1 year', '21456 Events conducted by MP\'s', '1.03 crore donations recieved']
  
  return (
    
      <Drawer
        sx={{
          '& .MuiDrawer-paper': {
            right:"3vh",
            top:"3vh",
            bottom:"3vh",
            borderRadius:"3%",
            height:"fit-content",
            width: drawerWidth,
            boxSizing: 'border-box',
            color:"white",
            minWidth: "250px",
            padding: "0 20px 0 20px",
            boxShadow: "0 0 6px hsl(210 14% 90%)"
          },
        }}
        variant="permanent"
        anchor="right"
      >
         
     
        <Toolbar  style={{backgroundColor:"blue",borderRadius:"10%",margin:"10px",paddingBottom:"5px",justifyContent:"center"}}>
            <div style={{whiteSpace:"pre",marginBottom:"5px"}}>
                <h3 style={{textAlignLast:"center"}}>Highlights</h3> 
            All India Seva Initiatives
            </div>
            
        </Toolbar>
        <TableContainer component={Paper} >
      <Table sx={{ minWidth: 280 }} size="small" aria-label="a dense table">
        
        <TableBody>
          {rows.map((row) => (
            <TableRow
              key={row.heading}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row" sx={{height:"30px"}}>
                {row.heading}
              </TableCell>
              <TableCell align="right">{row.value}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    <br/>
    <Box sx={{ border: 1 }}>
          <Card sx={{display:"flex", minWidth: 275, maxHeight:160 ,border:1}}>
        <Box  sx={{ display: 'flex', flexDirection: 'column' }}>
        
      <CardContent sx={{ flex:'1 0 auto'}}>
        <Typography variant="h6" component="div">
        Smt. Poonam  Mahajan
        </Typography>
        <Typography sx={{ mb: 1.5 }} fontSize="small" color="text.secondary">
        MP-Lok Sabha
        </Typography>
        <Typography sx={{ mb: 1.5 }} fontSize="small" color="text.secondary">
          Mumbai North-Central Maharastra
          <br />
        </Typography>
      </CardContent>
      </Box>
      <Box sx={{ display: 'flex', alignItems: 'center', pl: 1, pb: 1 }}>
      <CardMedia
        component="img"
        sx={{ width: 120 }}
        image={profile}
        alt="Live from space album cover"
        
      />
        </Box>
       
    </Card>
        </Box>
        <Box
        component="span"
        m={1}
        display="flex"
        justifyContent="space-around"
        alignItems="left"
      >
        <Button variant="contained" color="primary" sx={{ height: 70,width:"30vh" }}>
          
          <div style={{flexFlow:"column",textAlign:"left"}} >
            <Groups2Outlined sx={{marginTop:"2vh"}}/>
            <Typography sx={{ mb: 1.5 }} fontSize="smaller" textTransform="none">
         Add Members to NavMo App
         </Typography>
          </div>
        
         <ArrowForward sx={{alignSelf:"end"}}/>
        </Button>
        <Button variant="contained" color="secondary" 
        sx={{ height: 70, width:"30vh", marginLeft:"5px" }}>
          <div style={{flexFlow:"column",textAlign:"left"}} >
          <VolunteerActivismOutlined sx={{marginTop:"1.1vh"}}/>
        <Typography fontSize="smaller" sx={{textTransform:"none"}} >
        
          Invite Donations
          </Typography>
          </div>
          <ArrowForward sx={{alignSelf:"end"}}/>
        </Button>
      </Box>
        </Drawer>
  );
}

SideMenu.propTypes = {
  /**
   * Injected by the documentation to work in an iframe.
   * You won't need it on your project.
   */
  window: PropTypes.func,
};

export default SideMenu;
