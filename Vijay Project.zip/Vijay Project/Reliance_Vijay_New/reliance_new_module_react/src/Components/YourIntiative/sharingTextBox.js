import React from "react";
import { useState } from "react";
import "./sharingTextBox.css";
import ShareIcon from "@mui/icons-material/Share";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import ShareModal from "../YourIntiative/ShareModal";
import shareText from "../YourIntiative/shareText";
import { toast } from "react-hot-toast";

function SharingTextBox() {
  const [openShare, setOpenShare] = useState(false);
  // console.log("llll",shareText)
  const handleClickingOpen = () => {
    setOpenShare(true);
  };

  const handleShareModalClose = (value) => {
    setOpenShare(false);
  };

  return (
    <>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3,1fr)",
          gap: "10px",
        }}
      >
        {shareText.map((item) => (
          <div
            className="sharing-text-box-container"
            style={{ padding: "10px" }}
          >
            <p>{item.text}</p>
            <div className="sharing-text-box-bottom">
              <p>{item.name}</p>
              <div className="sharing-text-box-bottom-right">
                <ShareIcon
                  onClick={handleClickingOpen}
                  style={{ color: "white", float: "right", margin: "10px" }}
                />
                <ContentCopyIcon
                  onClick={() => {
                    window.navigator.clipboard
                      .writeText(item.text)
                      .then((res) => {
                        toast.success("Copied to clipboard.");
                      })
                      .catch((err) => console.log("err"));
                  }}
                  style={{ color: "white", float: "right", margin: "10px" }}
                />
              </div>
            </div>
            <ShareModal open={openShare} handleClose={handleShareModalClose} />
          </div>
        ))}
      </div>
    </>
  );
}

export default SharingTextBox;
