import * as React from "react";
import { useState } from "react";
import PropTypes from "prop-types";
import Button from "@mui/material/Button";
import { styled } from "@mui/material/styles";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import Typography from "@mui/material/Typography";
import SharingTextBox from "./sharingTextBox";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import Grid from "@mui/material/Grid";
import { padding } from "@mui/system";
import TextField from "@mui/material/TextField";

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  "& .MuiDialogContent-root": {
    padding: theme.spacing(2),
  },
  "& .MuiDialogActions-root": {
    padding: theme.spacing(1),
  },
}));

function BootstrapDialogTitle(props) {
  const { children, onClose, ...other } = props;

  const styles = {
    input: {
      WebkitBoxShadow: "0 0 0 1000px white inset",
    },
  };
  return (
    <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
      <div>{children}</div>
    </DialogTitle>
  );
}

BootstrapDialogTitle.propTypes = {
  children: PropTypes.node,
  onClose: PropTypes.func.isRequired,
};

export default function CustomizedDialogs(props) {
  const { onClose, selectedValue, open } = props;

  const handleClose = () => {
    onClose(selectedValue);
  };

  const [Language, setLanguage] = React.useState(10);

  const handleChange = (event) => {
    setLanguage(event.target.value);
  };

  const hideAutoFillColorStyle = {
    WebkitBoxShadow: "0 0 0 1000px white inset",
  };
  return (
    <div>
      <BootstrapDialog
        onClose={handleClose}
        aria-labelledby="customized-dialog-title"
        open={open}
        sx={{
          "& .MuiDialog-container": {
            "& .MuiPaper-root": {
              width: "100%",
              minWidth: "75%", // Set your width here
            },
          },
        }}
      >
        <div>
          <Grid container spacing={2} mb={-3} pl={2} pr={2}>
            <Grid xs={8}>
              <BootstrapDialogTitle
                id="customized-dialog-title"
                onClose={handleClose}
              >
                <Typography
                  sx={{
                    fontFamily: "HK Grotesk",
                    color: "#356F92",
                    fontSize: "20px",
                    fontWeight: "bold",
                  }}
                >
                  Sharing Text
                </Typography>

                <Typography
                  sx={{
                    fontFamily: "HK Grotesk",
                    color: "#2C2C2C",
                    fontSize: "16px",
                    fontWeight: "bold",
                  }}
                  gutterBottom
                >
                  Copy or share the below text to your social accounts
                </Typography>
              </BootstrapDialogTitle>
            </Grid>
            <div style={{ position: "relative", right: "-12%" }}>
              <Grid xs={4}>
                <FormControl
                  variant="standard"
                  sx={{
                    width: "150px",
                    boxShadow: "none",
                    mt: 4,
                    backgroundColor: "#F5F6FA",
                    borderRadius: "14px",
                    "& .MuiInputBase-input": {
                      paddingLeft: "45px",
                      fontFamily: "HK Grotesk",
                      fontSize: "16px",
                      color: "#356F92",
                      backgroundColor: "#F5F6FA!important",
                      borderRadius: "14px!important",
                    },
                  }}
                  InputProps={{
                    disableUnderline: true,
                  }}
                >
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={Language}
                    label="Language"
                    onChange={handleChange}
                    disableUnderline
                    MenuProps={{
                      PaperProps: {
                        sx: {
                          width: "200px",
                          // marginLeft:"85px",
                          // marginTop:"10px",
                          // height:"322px",
                          borderRadius: "14px",
                          // bgcolor: 'pink',
                          "& .MuiMenuItem-root": {
                            fontFamily: "HK Grotesk",
                            border: "1px solid #D3D3D3",
                            margin: "10px 20px 0",
                            borderRadius: "10px",
                            justifyContent: "center",
                            fontSize: "14px",
                            fontWeight: "bold",

                            "&$selected": {
                              backgroundColor: "#356F92",
                              color: "#000000",
                              "&:hover": {
                                backgroundColor: "#356F92",
                              },
                            },
                            "&:hover": {
                              backgroundColor: "#356F92",
                              color: "#fff",
                            },
                          },

                          "& .MuiSelect-select-root:focus": {
                            backgroundColor: "#fff",
                          },
                        },
                      },
                    }}
                  >
                    <MenuItem value={10}>English</MenuItem>
                    <MenuItem value={20}>Hindi</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <span>
                <b
                  style={{
                    fontFamily: "HK Grotesk",
                    fontSize: "14px",
                    marginLeft: "8px",
                  }}
                >
                  Select your language
                </b>
              </span>
            </div>
            <IconButton
              aria-label="close"
              onClick={handleClose}
              className="cancel-icon"
              sx={{
                position: "absolute",
                right: 8,
                top: 8,
                color: (theme) => theme.palette.grey[500],
                border: "1px solid #9e9e9e",
                borderRadius: "50%",
                padding: "2px",
              }}
            >
              <CloseIcon />
            </IconButton>
          </Grid>
        </div>
        <div>
          <hr style={{ border: "2px solid #356F92", width: "95%" }}></hr>
        </div>

        <div>
          <Grid container spacing={2}>
            <DialogContent style={{ marginLeft: "16px", alignItems: "center" }}>
              <div className="itemfixed5 ">
                <div className="grid-item-1">
                  {/* style={{display:'flex',flexWrap:'wrap',gap:'20px'}} */}
                  <Grid>
                    <SharingTextBox />
                  </Grid>
                </div>
              </div>
            </DialogContent>
          </Grid>
        </div>

        <DialogActions>
          {/* <Button autoFocus onClick={handleClose}>
            Save changes
          </Button> */}
        </DialogActions>
      </BootstrapDialog>
    </div>
  );
}
