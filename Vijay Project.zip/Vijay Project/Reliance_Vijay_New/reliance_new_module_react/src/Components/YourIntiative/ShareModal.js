import React from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import CloseIcon from "@mui/icons-material/Close";
import Twitter from "../../asserts/images/Twitter.svg";
import Facebook from "../../asserts/images/Facebook.svg";
import WhatsApp from "../../asserts/images/WhatsApp.svg";

const style = {
  position: "absolute",
  top: "37%",
  left: "54%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

function ShareModal({ open, handleClose }) {
  return (
    <Modal
      open={open}
      onClose={handleClose}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box sx={style}>
        <Typography id="modal-modal-title" variant="h6" component="h2">
          <label>Share on Social Media</label>
          <CloseIcon onClick={handleClose} />
        </Typography>
        <Typography id="modal-modal-description" sx={{ mt: 2 }}>
          <div className="sort-buttons">
            <div style={{ flex: "row" }}>
              <img src={Twitter} style={{ width: "50px", height: "50px" }} />
              <img
                src={Facebook}
                style={{ width: "50px", height: "50px", margin: "10px" }}
              />
              <img
                src={WhatsApp}
                style={{ width: "50px", height: "50px", margin: "5px" }}
              />
            </div>
          </div>
        </Typography>
      </Box>
    </Modal>
  );
}

export default ShareModal;
