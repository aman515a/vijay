const sharingText =[
    {
        id: '1',
        text:'I am organising a Blood donation camp in our constituency, to support emergency services in saving lives! Please support our Blood donation drive by donating blood and by spreading the word.',
        name: '#Donate Blood',
        shareIconUrl:'src/asserts/images/Share.svg',
        copyIconUrl:'src/asserts/images/Copy.svg'
    },
    {
        id: '2',
        text:'I am organising a Blood donation camp in our constituency, to support emergency services in saving lives! Please support our Blood donation drive by donating blood and by spreading the word.',
        name: '#Donate Blood',
        shareIconUrl:'src/asserts/images/Share.svg',
        copyIconUrl:'src/asserts/images/Copy.svg'
        
    },
    {
        id: '3',
        text:'I am organising a Blood donation camp in our constituency, to support emergency services in saving lives! Please support our Blood donation drive by donating blood and by spreading the word.',
        name: '#Donate Blood',
        shareIconUrl:'src/asserts/images/Share.svg',
        copyIconUrl:'src/asserts/images/Copy.svg'
    },
    {
        id: '4',
        text:'I am organising a Blood donation camp in our constituency, to support emergency services in saving lives! Please support our Blood donation drive by donating blood and by spreading the word.',
        name: '#Donate Blood',
        shareIconUrl:'src/asserts/images/Share.svg',
        copyIconUrl:'src/asserts/images/Copy.svg'

    },
    {
        id: '5',
        text:'I am organising a Blood donation camp in our constituency, to support emergency services in saving lives! Please support our Blood donation drive by donating blood and by spreading the word.',
        name: '#Donate Blood',
        shareIconUrl:'src/asserts/images/Share.svg',
        copyIconUrl:'src/asserts/images/Copy.svg'

    }

]

export default sharingText