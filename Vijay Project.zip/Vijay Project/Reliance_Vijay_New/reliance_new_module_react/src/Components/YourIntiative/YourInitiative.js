import "./YourInitiative.css";
import { MpIntiavtivesData } from "./YourInitiativeData";
import SideMenu from "../SideMenu/SideMenu";
import React, { useEffect, useState } from "react";
import { InputAdornment, TextField } from "@mui/material";
// import 'bootstrap/dist/css/bootstrap.min.css';
import InitiativeCard from "./InitiativeCard";
import CreateInitiativeCard from "./createIntiativecard";
import SortOutlinedIcon from "@mui/icons-material/SortOutlined";
import Button from "@mui/material/Button";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import SortOut from "./sortOut";
import SearchIcon from "@mui/icons-material/Search";
import EditIcon from "@mui/icons-material/Edit";
import ShareIcon from "@mui/icons-material/Share";
import ImagesModal from "./ImagesShare/ImagesModal";
import searchIcon from "../../asserts/images/Search.svg";
import SharingText from "./sharingText";
import VideosModal from "./VideoSHare/VideosModal";
import buttonicon from "./../../asserts/images/Card1your.svg";
import buttonicon2 from "./../../asserts/images/Card2your.svg";
import { createEventInitiative } from "../../store/action/createEvent";
import { useDispatch, useSelector } from "react-redux";
import { getEvents } from "../../store/action/getEvents";

// import CreateInitiativeReportDialog from '../SavaUpdate/AllInitiativeReports/createInitiativeReportDialog';

function IntiativesDetailsCard(props) {
  const functionHandler = (data) => {
    props.passChildData(data);
    props.setDetails(true);
  };
  // let list =
  //   props.filteredList.length > 0 ? props.filteredList : MpIntiavtivesData;

  let list = props.filteredList;

  if (list.length === 0) {
    return <div style={{ color: "red" }}>No records found....</div>;
  }

  return list.map((data) => {
    return (
      <div className="onhovertes">
        <div className="onhoverte" tabindex="1">
          <div className="details-wrapper" key={data.id}>
            <p>
              <span
                className="name-alligment"
                onClick={() => functionHandler(data)}
              >
                Seva-{data.id} {data.name}
              </span>
              <button
                className={`${
                  data.status == "Ongoing" || data.status == "Completed"
                    ? "details-btn-ongoing"
                    : "details-btn-alligment"
                }`}
              >
                {data.status}
              </button>
            </p>
            <p>
              <span>{data.targetDate}</span>
              <button className="details-btn-alligments">
                #{data.hashTag}
              </button>
            </p>
          </div>
        </div>
      </div>
    );
  });
}

function IntiativesDetails({ data, setInitiatives, initiative }) {
  const [IntiativeData, setInitiativeData] = useState(MpIntiavtivesData);
  const [buttonClick, setButtonClick] = useState(false);
  const [createButtonClick, setCreateButtonClick] = useState(false);
  const [cardFormData, setCardFormData] = useState([]);
  const [update, setUpdate] = useState(false);
  const [open, setOpen] = useState(false);
  const [openImage, setOpenImage] = useState(false);
  const [openText, setOpenText] = useState(false);
  const [openVideo, setOpenVideo] = useState(false);
  const [formImg, setFormImg] = useState();
  const dispatch = useDispatch();

  const handleOpenText = (val) => {
    setOpenText(val);
  };

  const handleOpen = (val) => {
    setOpen(val);
  };

  const handleClickingOpen = () => {
    setOpenText(true);
  };

  const handleImageClickOpen = () => {
    setOpenImage(true);
  };
  const handleVideoClickOpen = () => {
    setOpenVideo(true);
  };
  const handleCloseText = (value) => {
    setOpenText(false);
  };

  const handleImageClose = (value) => {
    setOpenImage(false);
  };

  const handleVideoClose = (value) => {
    setOpenVideo(false);
  };

  const handleClickOpen = () => {
    setButtonClick(!buttonClick);
  };
  const handlecreateClickOpen = () => {
    setCreateButtonClick(!createButtonClick);
  };

  const handleUpdate = () => {
    setUpdate(true);
  };
  const handleEdit = () => {
    handleClickOpen();
    handleUpdate();
  };
  const handleCardData = (datas) => {
    console.log("handle data for event");
    let data = { ...datas, formImg };
    dispatch(createEventInitiative(data));
    // dispatch(createEventInitiative(datas))
    //   var updatedData = MpIntiavtivesData

    //  updatedData.forEach((obj)=>{
    //   if(obj.id== datas.id){
    //     obj.events.push(datas)
    //     obj.status = datas.status
    //   }
    //  })

    //  setInitiativeData({IntiativeData: updatedData})
  };
  const handleCreateInitiateData = (datas) => {
    let updatedData = MpIntiavtivesData;
    updatedData.forEach((obj) => {
      if (obj.id == datas.id) {
        obj.status = datas.status;
      }
    });

    setInitiativeData({ IntiativeData: updatedData });
  };
  const updateInitiatives = (type) => {
    if (type === 1) {
      setInitiatives({
        ...initiative,
        requested: initiative.requested - 1,
        ongoing: initiative.ongoing + 1,
        events: initiative.events + 1,
      });
    }
  };

  return (
    <div>
      <p
        style={{
          marginLeft: "30px",
          marginTop: "10px",
          fontFamily: "HK Grotesk",
          fontSize: "20px",
          fontWeight: "bold",
        }}
      >
        {data.id} {data.name}
      </p>
      <ImagesModal setOpen={handleImageClose} open={openImage} />
      <VideosModal
        setOpenVideo={handleVideoClose}
        open={openVideo}
      ></VideosModal>
      <img src={data.url} className="seva-image"></img>
      <div>
        <span
          className="initiative-heading"
          style={{
            marginLeft: "30px",
            fontFamily: "HK Grotesk",
            fontSize: "20px",
            fontWeight: "bold",
            color: "#356F92",
          }}
        >
          Initiative details
        </span>
        <icon></icon>
      </div>
      <hr width="90%"></hr>
      <div>
        <p
          className="initiative-heading"
          style={{
            marginLeft: "30px",
            marginTop: "20px",
            fontFamily: "HK Grotesk",
            fontSize: "20px",
            fontWeight: "bold",
            color: "#356F92",
          }}
        >
          Social Media Kit
        </p>
        <p
          className="resources-heading"
          style={{
            marginLeft: "30px",
            fontFamily: "HK Grotesk",
            fontSize: "16px",
            color: "#505050",
          }}
        >
          You can download the resources from here
        </p>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            paddingRight: "22px",
          }}
        >
          <button className="button-heading" onClick={handleClickingOpen}>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              margin-right="10px"
              viewBox="0 0 190.783 235.229"
            >
              <g
                id="Icon_feather-file-text"
                data-name="Icon feather-file-text"
                transform="translate(6.5 6.5)"
              >
                <path
                  id="Path_497528"
                  data-name="Path 497528"
                  d="M117.114,3H28.223A22.223,22.223,0,0,0,6,25.223V203.006a22.223,22.223,0,0,0,22.223,22.223H161.56a22.223,22.223,0,0,0,22.223-22.223V69.669Z"
                  transform="translate(-6 -3)"
                  fill="none"
                  stroke="#356f92"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="13"
                ></path>
                <path
                  id="Path_497529"
                  data-name="Path 497529"
                  d="M21,3V69.669H87.669"
                  transform="translate(90.115 -3)"
                  fill="none"
                  stroke="#356f92"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="13"
                ></path>
                <path
                  id="Path_497530"
                  data-name="Path 497530"
                  d="M100.892,19.5H12"
                  transform="translate(32.446 102.726)"
                  fill="none"
                  stroke="#356f92"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="13"
                ></path>
                <path
                  id="Path_497531"
                  data-name="Path 497531"
                  d="M100.892,25.5H12"
                  transform="translate(32.446 141.172)"
                  fill="none"
                  stroke="#356f92"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="13"
                ></path>
                <path
                  id="Path_497532"
                  data-name="Path 497532"
                  d="M34.223,13.5H12"
                  transform="translate(32.446 64.28)"
                  fill="none"
                  stroke="#356f92"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="13"
                ></path>
              </g>
            </svg>
            Text
          </button>
          <button className="button-heading" onClick={handleImageClickOpen}>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              margin-right="10px"
              viewBox="0 0 307.584 239.232"
            >
              <path
                id="Icon_awesome-images"
                data-name="Icon awesome-images"
                d="M256.32,207.306v8.544a25.632,25.632,0,0,1-25.632,25.632H25.632A25.632,25.632,0,0,1,0,215.85V79.146A25.632,25.632,0,0,1,25.632,53.514h8.544V164.586a42.768,42.768,0,0,0,42.72,42.72Zm51.264-42.72V27.882A25.632,25.632,0,0,0,281.952,2.25H76.9A25.632,25.632,0,0,0,51.264,27.882v136.7A25.632,25.632,0,0,0,76.9,190.218H281.952A25.632,25.632,0,0,0,307.584,164.586ZM136.7,53.514a25.632,25.632,0,1,1-25.632-25.632A25.632,25.632,0,0,1,136.7,53.514ZM85.44,130.41l29.645-29.645a6.409,6.409,0,0,1,9.063,0l21.1,21.1L217.613,49.5a6.409,6.409,0,0,1,9.063,0l46.732,46.733v59.808H85.44Z"
                transform="translate(0 -2.25)"
                fill="#356f92"
              />
            </svg>
            Images
          </button>
          <button className="button-heading" onClick={handleVideoClickOpen}>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              margin-right="10px"
              viewBox="0 0 339.064 226.043"
            >
              <path
                id="Icon_awesome-video"
                data-name="Icon awesome-video"
                d="M197.905,4.5H28.138A28.137,28.137,0,0,0,0,32.638V202.405a28.137,28.137,0,0,0,28.138,28.138H197.905a28.137,28.137,0,0,0,28.138-28.138V32.638A28.137,28.137,0,0,0,197.905,4.5ZM309.4,26.692l-64.516,44.5v92.654L309.4,208.292c12.479,8.594,29.668-.177,29.668-15.187V41.879C339.064,26.928,321.935,18.1,309.4,26.692Z"
                transform="translate(0 -4.5)"
                fill="#356f92"
              />
            </svg>
            videos
          </button>
        </div>
        <hr width="90%"></hr>
      </div>
      <SharingText open={openText} onClose={handleCloseText} />
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <span
          style={{
            marginLeft: "30px",
            marginTop: "20px",
            fontFamily: "HK Grotesk",
            fontSize: "20px",
            fontWeight: "bold",
            color: "#356F92",
          }}
        >
          Your Events{" "}
        </span>
        <span
          style={{
            marginLeft: "50%",
            marginTop: "20px",
            fontFamily: "HK Grotesk",
            fontSize: "20px",
            fontWeight: "bold",
            color: "#505050",
          }}
        >
          {data?.events?.length == 0
            ? "No events to Display"
            : `${data?.events?.length} events `}
        </span>
        <icon></icon>
      </div>
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "space-between",
          padding: "20px",
        }}
      >
        {data?.events?.map((item) => (
          <div
            className="event-card"
            style={{
              backgroundImage: "url(" + `${item?.url}` + ")",
              margin: "20px",
              backgroundSize: "cover",
            }}
          >
            <ShareIcon
              style={{ color: "white", float: "right", margin: "10px" }}
            />
            {/* // <EditIcon onClick={handleEdit} style={{ color: 'white', float: 'right', margin: '10px' }} /> */}

            <EditIcon
              onClick={handleClickOpen}
              style={{ color: "white", float: "right", margin: "10px" }}
            />

            <div className="event-card-title">
              <div>{item?.title}</div>
              <div>{item.location}</div>
            </div>
          </div>
        ))}
      </div>
      <hr width="90%"></hr>
      <div>
        <div className="">
          <img width="100%" alt="" />
        </div>

        <div className="twobu">
          {/* <div style={{backgroundImage: `url(${buttonicon})`}}>

<span onClick={handleClickOpen}>Create an Event for this Initiative</span>
</div> */}
          <div class="gfg">
            <img src={buttonicon} />
            <p class="first-txt" onClick={handleClickOpen}>
              Create an Event for this Initiative
            </p>
          </div>

          <div class="gfg">
            <img src={buttonicon2} />
            <p class="first-txt" onClick={handlecreateClickOpen}>
              {data.status === "Completed"
                ? "Update an Initiative Report"
                : "Create an Initiative Report"}
            </p>
          </div>
        </div>
      </div>
      {buttonClick ? (
        <InitiativeCard
          data={data}
          onClose={() => handleClickOpen()}
          handleCardData={handleCardData}
          setFormImg={setFormImg}
          update={update}
          updateInitiatives={updateInitiatives}
        />
      ) : null}
      {createButtonClick ? (
        <CreateInitiativeCard
          data={data}
          handleCardData={handleCreateInitiateData}
          onClose={() => handlecreateClickOpen()}
        />
      ) : null}
    </div>
  );
}

const YourIntiatives = () => {
  const [data, setData] = useState("");
  const [details, setDetails] = useState(false);
  const [hideSearch, setHideSearch] = useState(false);
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const [searchInput, setSearchInput] = useState([]);
  const [filteredList, setFilteredList] = useState(MpIntiavtivesData);
  const [testData, setTestData] = useSelector(
    (state) => state?.getAllEvents?.data
  );
  console.log("testdata -- ".testData);
  const dispatch = useDispatch();

  const [initiative, setInitiatives] = useState({
    requested: 4,
    ongoing: 0,
    events: 0,
  });

  const handleSearch = (event) => {
    if (searchInput[0])
      setFilteredList(
        MpIntiavtivesData.filter(
          (value) =>
            value.name.toUpperCase().includes(searchInput[0].toUpperCase()) ||
            value.id.toUpperCase().includes(searchInput[0].toUpperCase())
        )
      );
    else {
      setFilteredList(MpIntiavtivesData);
    }
  };

  useEffect(() => {
    dispatch(getEvents());
    handleSearch();
  }, [searchInput]);
  return (
    <div className="d-flex page-wrapper1">
      <SideMenu />

      <div className="intiatives-container main-wrapper center-width">
        <h1 className="header-design header-alligment">Your Initiatives</h1>
        <div className="main-container">
          <div className="container1-alligment">
            <card>
              <div className="overview-card">
                <p className="header-design">Initiatives Overview</p>
                <div className="overview-flex">
                  <span className="count-alligment">
                    <span className="count-headers">
                      Requested Initiatives{" "}
                    </span>
                    <div className="count-container count-conatiner-color1">
                      {initiative.requested}
                    </div>
                  </span>
                  <span className="count-alligment">
                    <span className="count-headers">ongoing Initiatives </span>
                    <div className="count-container count-conatiner-color2">
                      {initiative.ongoing}
                    </div>
                  </span>
                  <span className="count-alligment">
                    <span className="count-headers">events conducted </span>
                    <div className="count-container count-conatiner-color3">
                      {initiative.events}
                    </div>
                  </span>
                </div>
              </div>
            </card>
            <div class="overview-card">
              <div class="all-intiatives-header">
                <div className="design">
                  {!hideSearch && (
                    <span className="header-design">
                      All Initiatives{" "}
                      <hr
                        style={{
                          border: "2px solid #EC6E29",
                          width: "100%",
                          marginTop: "4px",
                        }}
                      ></hr>
                    </span>
                  )}

                  <div style={{ display: "flex", alignItems: "center" }}>
                    <div className="menuItemForSort">
                      <SortOutlinedIcon
                        className="sort-styling"
                        onClick={handleOpen}
                      />
                      <div className="checksort">
                        <Menu
                          // id="basic-menu"
                          // anchorEl={anchorEl}
                          open={open}
                          onClose={handleClose}
                          // MenuListProps={{
                          //   'aria-labelledby': 'basic-button',
                          // }}
                          PaperProps={{
                            sx: {
                              width: "320px",
                              marginLeft: "530px",
                              marginTop: "-218px",
                              // height:"322px",
                              borderRadius: "14px",
                              fontFamily: "HK Grotesk",

                              "& .MuiMenuItem-root": {
                                fontFamily: "HK Grotesk",
                                border: "1px solid #D3D3D3",
                                margin: "10px 20px 0",
                                borderRadius: "10px",
                                justifyContent: "center",
                                fontSize: "14px",
                                fontWeight: "bold",
                                "&$selected": {
                                  backgroundColor: "#356F92",
                                  "&:hover": {
                                    backgroundColor: "#356F92",
                                  },
                                },
                                "&:hover": {
                                  backgroundColor: "#356F92",
                                  color: "#fff",
                                },
                              },
                            },
                          }}
                        >
                          <MenuItem>Activity</MenuItem>
                          <MenuItem>requested</MenuItem>
                          <MenuItem>Ongoing</MenuItem>
                          <MenuItem>Report Pending</MenuItem>
                          <MenuItem>Completed</MenuItem>
                        </Menu>
                      </div>
                    </div>
                    {/* <SortOut open={open} handleClose={handleClose} /> */}
                    {!hideSearch ? (
                      <SearchIcon
                        className="search-styling sort-styling"
                        onClick={() => setHideSearch(!hideSearch)}
                      />
                    ) : (
                      <TextField
                        className="search-filter-icon"
                        sx={{
                          "& fieldset": { border: "none" },
                          alignItems: "flex-end",
                        }}
                        onChange={(e) => {
                          console.log("Saurabh=>", e.target.value);
                          setSearchInput([e.target.value, e.currentTarget]);
                        }}
                        placeholder="Search Seva/ Initiatives"
                        InputProps={{
                          endAdornment: (
                            <InputAdornment position="start">
                              {/* search icon  */}
                              <img
                                className="searchIcon"
                                width={16}
                                height={16}
                                src={searchIcon}
                                onClick={() => setHideSearch(!hideSearch)}
                              />
                            </InputAdornment>
                          ),
                        }}
                      ></TextField>
                    )}
                  </div>
                </div>
                <IntiativesDetailsCard
                  passChildData={setData}
                  setDetails={setDetails}
                  filteredList={filteredList}
                />
              </div>
            </div>
          </div>
          {details && (
            <card>
              <div className="container2-alligment-2">
                <IntiativesDetails
                  initiative={initiative}
                  setInitiatives={setInitiatives}
                  data={data}
                />
              </div>
            </card>
          )}
        </div>
      </div>
    </div>
  );
};

export default YourIntiatives;
