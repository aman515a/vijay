import {
  Breadcrumbs,
  Button,
  Dialog,
  Divider,
  Grid,
  Hidden,
  IconButton,
  ImageList,
  ImageListItem,
  Typography,
} from "@mui/material";
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router";
import ItemData from "./itemData";
import LanguageData from "./LanguageData";
import VideosFolder from "./VideosFolder";
import close from "../../../asserts/images/sharing/Close.svg";
import groupIcon from "../../../asserts/images/sharing/Illustration.svg";
import "../ImagesShare/Share.css";
const VideosModal = ({ open, setOpenVideo }) => {
  const [folderName, setFolderName] = useState();
  const [languageName, setLanguageName] = useState();
  const [viewVideo, setViewVideo] = useState("");

  const handleClose = () => {
    setOpenVideo(false);
  };
  const navigate = useNavigate();

  const onFolderClick = () => {
    setLanguageName("");
    setViewVideo("");
    navigate(<ItemData />);
  };

  const onVideosLink = () => {
    setFolderName("");
    setViewVideo("");
    setLanguageName("");
  };
  return (
    <Dialog
      disableEscapeKeyDown
      open={open}
      onClose={handleClose}
      sx={{ maxHeight: "700px!important" }}
    >
      <img src={close} className="cancel-icon" onClick={handleClose} />
      <div style={{ padding: "25px", overflow: "hidden" }}>
        <Typography
          sx={{
            fontFamily: "HK Grotesk",
            color: "#2e739c",
            fontWeight: "700",
            fontSize: "20px",
            mt: 1,
          }}
        >
          Videos
        </Typography>
        <Typography
          sx={{
            fontFamily: "HK Grotesk",
            color: "#2C2C2C",
            fontWeight: "700",
            fontSize: "16px",
          }}
        >
          Select and download the Videos from the below directory.
        </Typography>
        <hr style={{ border: "2px solid #356F92", width: "97%" }}></hr>
        <Breadcrumbs
          aria-label="breadcrumb"
          sx={{
            fontFamily: "HK Grotesk",
            color: "#2C2C2C",
            fontWeight: "700",
            fontSize: "16px",
            mt: 1,
          }}
        >
          <Link
            underline="hover"
            className="custom-link"
            href="/"
            onClick={onVideosLink}
          >
            Videos
          </Link>
          {folderName && (
            <Link onClick={onFolderClick} href="/">
              {folderName && folderName?.title}
            </Link>
          )}
          {languageName && <Link>{languageName && languageName?.title}</Link>}
        </Breadcrumbs>
        <div style={{ marginTop: "10px", marginLeft: "10px" }}>
          <Grid container spacing={2}>
            <Grid
              item
              xs={3}
              md={5}
              margin="12px"
              sx={{ backgroundColor: "#f5f6fa", borderRadius: "20px" }}
            >
              {!folderName ? (
                <ItemData setFolderName={setFolderName} />
              ) : folderName && languageName ? (
                <VideosFolder
                  languageData={languageName}
                  setViewVideo={setViewVideo}
                  folderName={folderName}
                />
              ) : (
                <LanguageData setLanguageName={setLanguageName} />
              )}
            </Grid>
            <Grid
              item
              xs={9}
              md={6}
              margin="15px"
              sx={{
                backgroundColor: "#fff",
                border: "1px solid #DDDDDD",
                borderRadius: "20px",
              }}
            >
              {viewVideo ? (
                // <>
                //   <img
                //     src={`${viewVideo?.img}?w=164&h=164&fit=crop&auto=format`}
                //     srcSet={`${viewVideo.img}?w=164&h=164&fit=crop&auto=format&dpr=2 2x`}
                //     alt={viewVideo.subTitle}
                //     loading="lazy"
                //   />
                //   <Button>Download</Button>
                //   <Button>Download All</Button>
                // </>
                <>
                  <iframe
                    width="380"
                    height="300"
                    src={
                      viewVideo.videoUrl ||
                      "https://www.youtube.com/embed/phIuP8XU9KQ"
                    }
                    title={
                      viewVideo.title ||
                      "Swachh Bharat Abhiyan- Swachh Bharat ka Irada Kar Liya Hum Ne"
                    }
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowfullscreen
                  ></iframe>

                  <Button>
                    {" "}
                    <a
                      href={
                        viewVideo.videoUrl ||
                        "https://www.youtube.com/embed/phIuP8XU9KQ"
                      }
                      download
                    ></a>
                    Download
                  </Button>
                  <Button>Download All</Button>
                </>
              ) : (
                <>
                  <div className="imagemodalfilemana">
                    <img src={groupIcon} />
                    <Typography
                      sx={{
                        fontFamily: "HK Grotesk",
                        color: "#2e739c",
                        fontWeight: "700",
                        fontSize: "20px",
                        mt: 1,
                      }}
                    >
                      Select an Item to download
                    </Typography>
                    <Typography
                      sx={{
                        fontFamily: "HK Grotesk",
                        color: "#2C2C2C",
                        fontWeight: "700",
                        fontSize: "16px",
                      }}
                    >
                      Nothing is selected
                    </Typography>
                  </div>
                </>
              )}
            </Grid>
          </Grid>
        </div>
      </div>
    </Dialog>
  );
};

export default VideosModal;
