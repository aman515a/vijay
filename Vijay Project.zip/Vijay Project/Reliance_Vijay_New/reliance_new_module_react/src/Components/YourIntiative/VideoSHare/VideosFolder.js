import React, { useEffect, useState } from "react";

import certi1 from "../../../asserts/images/sharing/English/Certi.png";
import certiBig1 from "../../../asserts/images/sharing/English/Certi@2x.png";
import outdoorBanner1 from "../../../asserts/images/sharing/English/Template1.png";
import outdoorBannerBig1 from "../../../asserts/images/sharing/English/Template1@2x.png";
import outdoorBanner2 from "../../../asserts/images/sharing/English/Template.png";
import outdoorBannerBig2 from "../../../asserts/images/sharing/English/Template@2x.png";
import outdoorBanner3 from "../../../asserts/images/sharing/English/36Banner.png";
import outdoorBannerBig3 from "../../../asserts/images/sharing/English/36Banner@2x.png";
import outdoorG from "../../../asserts/images/sharing/Gujarati/Template03.png";
import outdoorGBig from "../../../asserts/images/sharing/Gujarati/Template03@2x.png";
import outdoorH from "../../../asserts/images/sharing/Hindi/Template02.png";
import outdoorHBig from "../../../asserts/images/sharing/Hindi/Template02@2x.png";
import { Grid, ImageListItem, Typography, Button } from "@mui/material";
const VideosFolder = ({ languageData, setViewVideo, folderName }) => {
  const [imageData, setImageData] = useState([]);

  console.log("languageData=>", languageData);

  useEffect(() => {
    if (languageData.id === 1) {
      setImageData(englishFolder);
    } else if (languageData.id === 2) {
      setImageData(gujaratiFolder);
    } else if (languageData.id === 3) {
      setImageData(marathiFolder);
    } else {
      setImageData(hindiFolder);
    }
  }, []);

  const englishFolder = [
    {
      id: 1,
      img: certi1,
      bigImg: certiBig1,
      videoUrl: "https://www.youtube.com/embed/phIuP8XU9KQ",
      subTitle: "Certificate",
    },
    // , {
    //     id: 2,
    //     img: outdoorBanner1,
    //     bigImg: outdoorBannerBig1,
    //     subTitle: "Outdoor Banners",
    // },
    // {
    //     id: 3,
    //     img: outdoorBanner2,
    //     bigImg: outdoorBannerBig2,
    //     subTitle: "Outdoor Banners",
    // },
    // {
    //     id: 4,
    //     img: outdoorBanner3,
    //     bigImg: outdoorBannerBig3,
    //     subTitle: "Outdoor Banners",
    // },
    // {
    //     id: 5,
    //     img: outdoorBanner1,
    //     bigImg: outdoorBannerBig1,
    //     subTitle: "Social Media"
    // },
  ];

  const gujaratiFolder = [
    {
      id: 1,
      img: "",
      subTitle: "Certificate",
      videoUrl: "https://www.youtube.com/embed/phIuP8XU9KQ",
    },
    {
      id: 2,
      img: outdoorG,
      videoUrl: "https://www.youtube.com/embed/phIuP8XU9KQ",
      bigImg: outdoorGBig,
      subTitle: "Outdoor Banners",
    },
    {
      id: 3,
      img: outdoorG,
      videoUrl: "https://www.youtube.com/embed/phIuP8XU9KQ",
      bigImg: outdoorGBig,
      subTitle: "Social Media",
    },
  ];

  const marathiFolder = [
    {
      id: 1,
      img: "",
      subTitle: "Certificate",

      videoUrl: "https://www.youtube.com/embed/phIuP8XU9KQ",
    },
    {
      id: 2,
      img: outdoorH,
      bigImg: outdoorHBig,
      subTitle: "Outdoor Banners",

      videoUrl: "https://www.youtube.com/embed/phIuP8XU9KQ",
    },
    {
      id: 3,
      img: "",
      subTitle: "Social Media",

      videoUrl: "https://www.youtube.com/embed/phIuP8XU9KQ",
    },
  ];

  const hindiFolder = [
    {
      id: 1,
      img: "",
      bigImg: "",
      subTitle: "Certificate",

      videoUrl: "https://www.youtube.com/embed/phIuP8XU9KQ",
    },
    {
      id: 2,
      img: outdoorH,
      bigImg: outdoorHBig,
      subTitle: "Outdoor Banners",

      videoUrl: "https://www.youtube.com/embed/phIuP8XU9KQ",
    },
    {
      id: 3,
      img: outdoorH,
      bigImg: outdoorHBig,
      subTitle: "Social Media",

      videoUrl: "https://www.youtube.com/embed/phIuP8XU9KQ",
    },
  ];

  return (
    <>
      {folderName.id === 2 && (
        <Grid container sx={{ mb: 1 }}>
          <Grid item xs={4}>
            <Button variant="outlined">1.1</Button>
          </Grid>
          <Grid item xs={4}>
            <Button variant="outlined">16.9</Button>
          </Grid>
          <Grid item xs={4}>
            <Button variant="outlined">3.6</Button>
          </Grid>
        </Grid>
      )}
      {imageData &&
        imageData?.map((item) => (
          <ImageListItem key={item.id}>
            <img
              src={`${item.img}?w=164&h=164&fit=crop&auto=format`}
              srcSet={`${item.img}?w=164&h=164&fit=crop&auto=format&dpr=2 2x`}
              alt={item.subTitle}
              loading="lazy"
              onClick={() => setViewVideo(item)}
            />
            <Typography variant="subtitle1">{item.title}</Typography>
          </ImageListItem>
        ))}
    </>
  );
};

export default VideosFolder;
