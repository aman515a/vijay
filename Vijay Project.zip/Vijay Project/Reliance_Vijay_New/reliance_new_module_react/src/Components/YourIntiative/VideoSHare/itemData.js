// import folder from '../../../asserts/images/sharing/Folder.png';
// import certi1 from '../../../asserts/images/sharing/English/Certi.png';
// import certiBig1 from '../../../asserts/images/sharing/English/Certi@2x.png';
// import outdoorBanner1 from '../../../asserts/images/sharing/English/Template1.png';
// import outdoorBannerBig1 from '../../../asserts/images/sharing/English/Template1@2x.png';
// import outdoorBanner2 from '../../../asserts/images/sharing/English/Template.png';
// import outdoorBannerBig2 from '../../../asserts/images/sharing/English/Template@2x.png';
// import outdoorBanner3 from '../../../asserts/images/sharing/English/36Banner.png';
// import outdoorBannerBig3 from '../../../asserts/images/sharing/English/36Banner@2x.png';
// import outdoorG from '../../../asserts/images/sharing/Gujarati/Template03.png';
// import outdoorGBig from '../../../asserts/images/sharing/Gujarati/Template03@2x.png';
// import outdoorH from '../../../asserts/images/sharing/Hindi/Template02.png';
// import outdoorHBig from '../../../asserts/images/sharing/Hindi/Template02@2x.png';
// export const itemDataImages=[
//     {
//         id:1,
//         title:"Videos",
//         img:folder
//     }
// ]

// export const langFolder=[
//     {
//         id:4,
//         title:"English",
//         img:folder
//     },
//     {
//         id:5,
//         title:"Gujarati",
//         img:folder
//     },
//     {
//         id:6,
//         title:"Marathi",
//         img:folder
//     },
//     {
//         id:7,
//         title:"Hindi",
//         img:folder
//     }
// ]

// export const englishFolder=[
//     {
//         id:101,
//         img:"https://www.google.com/url?sa=i&url=https%3A%2F%2Fin.pinterest.com%2Fpin%2F599330662884408857%2F&psig=AOvVaw2NsYKWMGu6eoZQ2GrwRNoI&ust=1676104621326000&source=images&cd=vfe&ved=0CA8QjRxqFwoTCOiY9LXGiv0CFQAAAAAdAAAAABAE",
//         bigImg:"https://youtu.be/phIuP8XU9KQ",
//         subTitle:"Videos",
//     }
// ]

// export const gujaratiFolder=[
//     {
//         id:201,
//         img:"",
//         subTitle:"Certificate",
//     },{
//         id:202,
//         img:outdoorG,
//         bigImg:outdoorGBig,
//         subTitle:"Outdoor Banners",
//     },
//     {
//         id:203,
//         img:outdoorG,
//         bigImg:outdoorGBig,
//         subTitle:"Social Media"
//     },
// ]

// export const marathiFolder=[
//     {
//         id:301,
//         img:"",
//         subTitle:"Certificate",
//     },{
//         id:302,
//         img:outdoorH,
//         bigImg:outdoorHBig,
//         subTitle:"Outdoor Banners",
//     },
//     {
//         id:303,
//         img:"",
//         subTitle:"Social Media"
//     },
// ]

// export const hindiFolder=[
//     {
//         id:401,
//         img:"",
//         bigImg:"",
//         subTitle:"Certificate",
//     },{
//         id:402,
//         img:outdoorH,
//         bigImg:outdoorHBig,
//         subTitle:"Outdoor Banners",
//     },
//     {
//         id:403,
//         img:outdoorH,
//         bigImg:outdoorHBig,
//         subTitle:"Social Media"
//     },
// ]

import { ImageList, ImageListItem, Typography } from "@mui/material";
import React from "react";
import folder from "../../../asserts/images/sharing/Folder.png";

const ItemData = ({ setFolderName }) => {
  const itemDataImages = [
    {
      id: 1,
      title: "Videos",
      img: folder,
    },
  ];

  return (
    <>
      <ImageList sx={{ width: 250, height: 450 }} cols={2} rowHeight={164}>
        {itemDataImages &&
          itemDataImages?.map((item) => (
            <ImageListItem key={item.id}>
              <img
                key={item.id}
                src={`${item.img}?w=164&h=164&fit=crop&auto=format`}
                srcSet={`${item.img}?w=164&h=164&fit=crop&auto=format&dpr=2 2x`}
                alt={item.title}
                onClick={() => {
                  setFolderName(item);
                }}
              />
              <Typography variant="subtitle1">{item.title}</Typography>
            </ImageListItem>
          ))}
      </ImageList>
    </>
  );
};

export default ItemData;
