import {
  Breadcrumbs,
  Button,
  Dialog,
  Divider,
  Grid,
  IconButton,
  ImageList,
  ImageListItem,
  Typography,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import groupIcon from "../../../asserts/images/sharing/Illustration.svg";
import {
  englishFolder,
  gujaratiFolder,
  hindiFolder,
  itemDataImages,
  langFolder,
  marathiFolder,
} from "./itemData";
const VideosModal = ({ open, setOpenVideo }) => {
  const [itemData, setItemData] = useState(itemDataImages);
  const [itemValue, setitemValue] = useState("");
  const [viewImage, setViewImage] = useState(false);
  // const [secondBreadCrumb, setSecondBreadCrumb] = useState("");

  const titles = ["Videos", "Outdoor Banners", "Social Media"];
  // setItemData(itemDataImages)
  const handleClose = () => {
    setItemData(itemDataImages);
    setOpenVideo(false);
  };

  // console.log("viewImage", viewImage)
  const handleFolderClick = (item) => {
    // console.log("item", item)
    // setSecondBreadCrumb(item?.title);
    setViewImage(false);
    setItemData([]);
    if (titles.includes(item.title)) {
      // console.log("item is here")
      setitemValue(item.title);
    }
    // console.log("item", item, itemValue, itemData[0]?.id / 10)
    let param = item?.id;

    let value;
    switch (param) {
      case 1:
      case 2:
      case 3:
        value = langFolder;
        break;
      case 4:
        value = englishFolder.filter((val) => val.subTitle === itemValue);
        break;
      case 5:
        value = gujaratiFolder.filter((val) => val.subTitle === itemValue);
        break;
      case 6:
        value = marathiFolder.filter((val) => val.subTitle === itemValue);
        break;
      case 7:
        value = hindiFolder.filter((val) => val.subTitle === itemValue);
        break;
      default:
        value = itemDataImages;
    }
    // console.log("value", value, itemValue, typeof (value))

    setItemData(value);
  };
  console.log("itemdata videos", itemData);

  // useEffect(() => {
  //   setState(secondBreadCrumb);
  // }, [handleFolderClick]);
  {
    console.log("videos---->", viewImage);
  }

  return (
    <Dialog
      disableEscapeKeyDown
      open={open}
      onClose={handleClose}
      sx={{ maxHeight: "700px!important" }}
    >
      <div style={{ padding: "25px", overflow: "hidden" }}>
        <Typography
          sx={{
            fontFamily: "HK Grotesk",
            color: "#2e739c",
            fontWeight: "700",
            fontSize: "20px",
          }}
        >
          Videos
        </Typography>
        <Typography
          sx={{
            fontFamily: "HK Grotesk",
            color: "#2C2C2C",
            fontWeight: "700",
            fontSize: "16px",
          }}
        >
          Select and download the Videos from the below directory.
        </Typography>
        <hr style={{ border: "2px solid #356F92", width: "97%" }}></hr>

        <Breadcrumbs
          aria-label="breadcrumb"
          sx={{
            fontFamily: "HK Grotesk",
            color: "#2C2C2C",
            fontWeight: "700",
            fontSize: "16px",
            mt: 1,
          }}
        >
          <Link
            underline="hover"
            className="custom-link"
            href="/"
            onClick={onVideosLink}
          >
            Videos
          </Link>
          {folderName && (
            <Link onClick={onFolderClick} href="/">
              {folderName && folderName?.title}
            </Link>
          )}
          {languageName && <Link>{languageName && languageName?.title}</Link>}
        </Breadcrumbs>
        {/* <Breadcrumbs aria-label="breadcrumb" sx={{ fontFamily:'HK Grotesk',color: "#2C2C2C",fontWeight:"700",fontSize:"16px",mt:1 }}>
        <Link underline="hover"className="custom-link" href="/" >
          Videos
        </Link>
  */}
        {/* <Link underline="hover" color="inherit" >
          {secondBreadCrumb && secondBreadCrumb}
        </Link> */}
        {/* <Link underline="hover" color="inherit" href="/" >
          {itemData[0].title}
        </Link> */}

        {/* <Typography color="text.primary">Breadcrumbs</Typography> */}
        {/* </Breadcrumbs> */}
        <div style={{ marginTop: "10px", marginLeft: "10px" }}>
          <Grid container spacing={2}>
            <Grid
              item
              xs={3}
              md={5}
              margin="12px"
              sx={{ backgroundColor: "#f5f6fa", borderRadius: "20px" }}
            >
              <ImageList
                sx={{ width: 250, height: 450 }}
                cols={2}
                rowHeight={164}
              >
                {itemData[0]?.id / 10 < 10
                  ? itemData?.map((item) => (
                      <ImageListItem key={item.id}>
                        <img
                          key={item.id}
                          src={`${item.img}?w=164&h=164&fit=crop&auto=format`}
                          srcSet={`${item.img}?w=164&h=164&fit=crop&auto=format&dpr=2 2x`}
                          alt={item.title}
                          onClick={() => {
                            handleFolderClick(item);
                          }}
                        />
                        <Typography variant="subtitle1">
                          {item.title}
                        </Typography>
                      </ImageListItem>
                    ))
                  : itemData
                      .filter((val) => val.subTitle === itemValue)
                      .map((item) => (
                        // <ImageListItem key={item.id}>
                        <div onClick={() => setViewImage(true)}>
                          <iframe
                            width="180"
                            height="120"
                            src="https://www.youtube.com/embed/phIuP8XU9KQ"
                            title="Swachh Bharat Abhiyan- Swachh Bharat ka Irada Kar Liya Hum Ne"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen
                          ></iframe>
                        </div>

                        //   <img
                        //     src={`${item.img}?w=164&h=164&fit=crop&auto=format`}
                        //     srcSet={`${item.img}?w=164&h=164&fit=crop&auto=format&dpr=2 2x`}
                        //     alt={item.subTitle}
                        //     loading="lazy"
                        //     onClick={() => setViewImage(item)}
                        //   />
                        //   <Typography variant='subtitle1'>{item.title}</Typography>
                        // </ImageListItem>
                      ))}
              </ImageList>
            </Grid>
            <Grid
              item
              xs={9}
              md={6}
              margin="15px"
              sx={{
                backgroundColor: "#fff",
                border: "1px solid #DDDDDD",
                borderRadius: "20px",
              }}
            >
              {viewImage ? (
                <>
                  (
                  <iframe
                    width="380"
                    height="300"
                    src="https://www.youtube.com/embed/phIuP8XU9KQ"
                    title="Swachh Bharat Abhiyan- Swachh Bharat ka Irada Kar Liya Hum Ne"
                    frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowfullscreen
                  ></iframe>
                  )
                  <Button>
                    {" "}
                    <a
                      href="https://www.youtube.com/embed/phIuP8XU9KQ"
                      download
                    ></a>
                    Download
                  </Button>
                  <Button>Download All</Button>
                </>
              ) : (
                <>
                  <div className="imagemodalfilemana">
                    <img src={groupIcon} />
                    <Typography
                      sx={{
                        fontFamily: "HK Grotesk",
                        color: "#2e739c",
                        fontWeight: "700",
                        fontSize: "20px",
                        mt: 1,
                      }}
                    >
                      Select an Item to download
                    </Typography>
                    <Typography
                      sx={{
                        fontFamily: "HK Grotesk",
                        color: "#2C2C2C",
                        fontWeight: "700",
                        fontSize: "16px",
                      }}
                    >
                      Nothing is selected
                    </Typography>
                  </div>
                </>
              )}
            </Grid>
          </Grid>
        </div>
      </div>
    </Dialog>
  );
};

export default VideosModal;
