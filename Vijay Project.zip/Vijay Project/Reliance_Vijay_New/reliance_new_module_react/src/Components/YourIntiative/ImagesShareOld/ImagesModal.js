import { Breadcrumbs, Button, Dialog, Divider, Grid, IconButton, ImageList, ImageListItem, Typography } from '@mui/material'
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import groupIcon from '../../../asserts/images/sharing/Illustration.svg';
import { englishFolder, gujaratiFolder, hindiFolder, itemDataImages, langFolder, marathiFolder } from './itemData';
const ImagesModal = ({ open, setOpen }) => {

  const [itemData, setItemData] = useState(itemDataImages);
  const [itemValue, setitemValue] = useState('')
  const [viewImage, setViewImage] = useState('')
  // const [secondBreadCrumb, setSecondBreadCrumb] = useState("");

  const titles = ["Certificate", "Outdoor Banners", "Social Media"]
  // setItemData(itemDataImages)
  const handleClose = () => {
    setItemData(itemDataImages)
    setOpen(false);
  };

  // console.log("viewImage", viewImage)
  const handleFolderClick = (item) => {
    // console.log("item", item)
    // setSecondBreadCrumb(item?.title);
    setViewImage("");
    setItemData([])
    if (titles.includes(item.title)) {
      // console.log("item is here")
      setitemValue(item.title)
    }
    // console.log("item", item, itemValue, itemData[0]?.id / 10)
    let param = item?.id

    let value
    switch (param) {
      case 1:
      case 2:
      case 3:
        value = langFolder
        break;
      case 4:
        value = englishFolder.filter((val) => val.subTitle === itemValue)
        break;
      case 5:
        value = gujaratiFolder.filter((val) => val.subTitle === itemValue)
        break;
      case 6:
        value = marathiFolder.filter((val) => val.subTitle === itemValue)
        break;
      case 7:
        value = hindiFolder.filter((val) => val.subTitle === itemValue)
        break;
      default:
        value = itemDataImages;
    }
    // console.log("value", value, itemValue, typeof (value))

    setItemData(value)
  }
  // console.log("itemdata", itemData)

  // useEffect(() => {
  //   setState(secondBreadCrumb);
  // }, [handleFolderClick]);

  return (
    <div><Dialog disableEscapeKeyDown open={open} onClose={handleClose}>

      <Typography variant='h5'>Images</Typography>
      <Typography>Select and download the Images for social media & outdoor banners from the below directory.</Typography>
      <Divider />
      <Breadcrumbs aria-label="breadcrumb">
        <Link underline="hover" color="inherit" href="/" >
          Images
        </Link>
        {/* <Link underline="hover" color="inherit" >
          {secondBreadCrumb && secondBreadCrumb}
        </Link> */}
        {/* <Link underline="hover" color="inherit" href="/" >
          {itemData[0].title}
        </Link> */}

        {/* <Typography color="text.primary">Breadcrumbs</Typography> */}
      </Breadcrumbs>
      <Grid container spacing={2}>
        <Grid item xs={3} md={5} height="75vh" margin="15px" border="1px solid gray" sx={{ backgroundColor: "#F5F6FA" }}>

          <ImageList sx={{ width: 250, height: 450 }} cols={2} rowHeight={164} >
            {itemData[0]?.id / 10 < 10 ?
              itemData?.map((item) => (
                <ImageListItem key={item.id}>
                  <img
                    key={item.id}
                    src={`${item.img}?w=164&h=164&fit=crop&auto=format`}
                    srcSet={`${item.img}?w=164&h=164&fit=crop&auto=format&dpr=2 2x`}
                    alt={item.title}
                    onClick={() => {
                      handleFolderClick(item)
                    }}
                  />
                  <Typography variant='subtitle1'>{item.title}</Typography>
                </ImageListItem>
              )) :
              itemData.filter((val) => val.subTitle === itemValue).map((item) => (
                <ImageListItem key={item.id}>
                  <img
                    src={`${item.img}?w=164&h=164&fit=crop&auto=format`}
                    srcSet={`${item.img}?w=164&h=164&fit=crop&auto=format&dpr=2 2x`}
                    alt={item.subTitle}
                    loading="lazy"
                    onClick={() => setViewImage(item)}
                  />
                  <Typography variant='subtitle1'>{item.title}</Typography>
                </ImageListItem>
              ))


            }
          </ImageList>
        </Grid>
        <Grid item xs={9} md={6} height="75vh" margin="15px" border="1px solid gray" sx={{ backgroundColor: "#F5F6FA" }}>
          {viewImage ? <>
            <img
              src={`${viewImage?.img}?w=164&h=164&fit=crop&auto=format`}
              srcSet={`${viewImage.img}?w=164&h=164&fit=crop&auto=format&dpr=2 2x`}
              alt={viewImage.subTitle}
              loading="lazy"
            />
            <Button>Download</Button>
            <Button>Download All</Button>
          </> :
            <>
              <img src={groupIcon} />
              <Typography variant='h5'>Select an Item to download</Typography>
              <Typography>Nothing is selected</Typography>
            </>}
        </Grid>
      </Grid>
    </Dialog></div>
  )
}

export default ImagesModal