import React from "react";
import { useState } from "react";
import "./sharingTextBox.css";
import ShareIcon from "@mui/icons-material/Share";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import ShareModal from "./ShareModal";
import { Box, width } from "@mui/system";

function FolderContainer() {
  
  //   const [openShare, setOpenShare] = React.useState(false);

  //   const handleClickingOpen = () => {
  //     setOpenShare(true);
  //   };

  //   const handleShareModalClose = (value) => {
  //     setOpenShare(false);
  //   };

  return (
    <>
      <Box maxWidth style={{display:'flex',gap:'30px',background:'#F5F6FA',padding:'50px'}}>
        <Box
          style={{
            border: "1px solid blue",
            width: "200px",
            height: "200px",
            background: "yellow",
          }}
        ></Box>
        <Box
          style={{
            border: "1px solid blue",
            width: "200px",
            height: "200px",
            background: "yellow",
          }}
        ></Box>
        <Box
          style={{
            border: "1px solid blue",
            width: "70px",
            height: "70px",
            background: "yellow",
          }}
        ></Box>
      </Box>
      <Box
        style={{ border: "1px solid #DDDDDD", height: "400px" }}
        
      >
        <img
          src="https://images.unsplash.com/photo-1570993492881-25240ce854f4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NHx8Y29tcHV0ZXIlMjBkZXNrfGVufDB8fDB8fA%3D%3D&w=1000&q=80"
          style={{ width: "150px", height: "250px", margin: "10px" }}
        />
        <p style={{ color: "#356F92", textAlign: "center" }}>
          Select an item to download
        </p>
        <p style={{ color: "black", textAlign: "center" }}>
          Nothing is Selected
        </p>
      </Box>
    </>
  );
}

export default FolderContainer;
