import { Breadcrumbs, Button, Dialog, Divider, Grid, Hidden, IconButton, ImageList, ImageListItem, Typography } from '@mui/material'
import React, { useState } from 'react'
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router';
import ItemData from './itemData';
import LanguageData from './LanguageData';
import ImagesFolder from './ImagesFolder';
import close from "../../../asserts/images/sharing/Close.svg";
import groupIcon from '../../../asserts/images/sharing/Illustration.svg';
import "./Share.css"
const ImagesModal = ({ open, setOpen }) => {
    const [folderName, setFolderName] = useState();
    const [languageName, setLanguageName] = useState();
    const [viewImage, setViewImage] = useState('')

    const handleClose = () => {
        setOpen(false);
    };
    const navigate = useNavigate();

    const onFolderClick = () => {
        setLanguageName("");
        setViewImage("");
        navigate(<ItemData />)
    }

    const onImagesLink = () => {
        setFolderName("");
        setViewImage("");
        setLanguageName("");
    }
    return (
       <Dialog disableEscapeKeyDown open={open} onClose={handleClose} sx={{ maxHeight:"700px!important" }} >
          <img src={close} className="cancel-icon" onClick={handleClose}/>
        <div style={{padding:"25px",overflow:'hidden'}}>
        
            <Typography sx={{ fontFamily:'HK Grotesk',color: "#2e739c",fontWeight:"700",fontSize:"20px",mt:1,  }}>{folderName?.title =="Certificate" ? "Certificate" :"Images"}</Typography>
            <Typography sx={{ fontFamily:'HK Grotesk',color: "#2C2C2C",fontWeight:"700",fontSize:"16px", }}>{folderName?.title =="Certificate" ? "Select and download the certificate.":"Select and download the Images for social media & outdoor banners from the below directory."}</Typography>
            <hr style={{border:"2px solid #356F92",width:"97%"}}></hr>
            <Breadcrumbs aria-label="breadcrumb" sx={{ fontFamily:'HK Grotesk',color: "#2C2C2C",fontWeight:"700",fontSize:"16px",mt:1 }}>
                <Link underline="hover"className="custom-link" href="/" onClick={onImagesLink} >
                    Images
                </Link>
                {folderName && <Link onClick={onFolderClick} href="/">
                    {folderName && folderName?.title}
                </Link>}
                {languageName && <Link>
                    {languageName && languageName?.title}
                </Link>}
            </Breadcrumbs>
            <div style={{marginTop:"10px",marginLeft:"10px"}}>
            <Grid container spacing={2}>
                <Grid item xs={3} md={5} margin="12px"  sx={{ backgroundColor: "#f5f6fa",borderRadius:"20px" }}>
                    {!folderName ? <ItemData setFolderName={setFolderName} /> :
                        (folderName && languageName ? <ImagesFolder languageData={languageName} setViewImage={setViewImage} folderName={folderName} />
                            : <LanguageData setLanguageName={setLanguageName} />)
                    }
                </Grid>
                <Grid item xs={9} md={6}  margin="15px" sx={{ backgroundColor: "#fff",border:"1px solid #DDDDDD",borderRadius:"20px" }}>
                    {viewImage ? <>
                        <img
                            src={`${viewImage?.img}?w=164&h=164&fit=crop&auto=format`}
                            srcSet={`${viewImage.img}?w=164&h=164&fit=crop&auto=format&dpr=2 2x`}
                            alt={viewImage.subTitle}
                            loading="lazy"
                        />
                        <Button>Download</Button>
                        <Button>Download All</Button>
                    </> :
                        <>
                        <div className='imagemodalfilemana'>
                            <img src={groupIcon} />
                            <Typography sx={{ fontFamily:'HK Grotesk',color: "#2e739c",fontWeight:"700",fontSize:"20px",mt:1  }}>Select an Item to download</Typography>
                            <Typography sx={{ fontFamily:'HK Grotesk',color: "#2C2C2C",fontWeight:"700",fontSize:"16px"}}>Nothing is selected</Typography>
                        </div>
                        </>
                    }
                </Grid>
            </Grid>
            </div>
            </div>
        </Dialog>
    )
}

export default ImagesModal