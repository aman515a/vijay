import { ImageList, ImageListItem, Typography } from '@mui/material';
import React from 'react';
import folder from '../../../asserts/images/sharing/Folder.png';

const LanguageData = ({ setLanguageName }) => {
    const langFolder = [
        {
            id: 1,
            title: "English",
            img: folder
        },
        {
            id: 2,
            title: "Gujarati",
            img: folder
        },
        {
            id: 3,
            title: "Marathi",
            img: folder
        },
        {
            id: 4,
            title: "Hindi",
            img: folder
        }
    ]
    return (
        <>
            <ImageList sx={{ width: 250, height: 450 }} cols={2} rowHeight={164} >
                {langFolder && langFolder?.map((item) => (
                    <ImageListItem key={item.id}>
                        <img
                            key={item.id}
                            src={`${item.img}?w=164&h=164&fit=crop&auto=format`}
                            srcSet={`${item.img}?w=164&h=164&fit=crop&auto=format&dpr=2 2x`}
                            alt={item.title}
                            onClick={() => {
                                setLanguageName(item)
                            }}
                        />
                        <Typography variant='subtitle1'>{item.title}</Typography>
                    </ImageListItem>
                ))}

            </ImageList>
        </>
    )
}

export default LanguageData;