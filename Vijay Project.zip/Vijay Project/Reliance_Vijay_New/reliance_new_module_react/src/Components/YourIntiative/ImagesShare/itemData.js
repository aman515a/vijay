import { ImageList, ImageListItem, Typography } from '@mui/material';
import React from 'react';
import folder from '../../../asserts/images/sharing/Folder.png';

const ItemData = ({ setFolderName }) => {
    const itemDataImages = [
        {
            id: 1,
            title: "Certificate",
            img: folder
        },
        {
            id: 2,
            title: "Outdoor Banners",
            img: folder
        },
        {
            id: 3,
            title: "Social Media",
            img: folder
        }
    ]

    return (
        <>
            <ImageList sx={{ width: 250, height: 450 }} cols={2} rowHeight={164} >
                {itemDataImages && itemDataImages?.map((item) => (
                    <ImageListItem key={item.id}>
                        <img
                            key={item.id}
                            src={`${item.img}?w=164&h=164&fit=crop&auto=format`}
                            srcSet={`${item.img}?w=164&h=164&fit=crop&auto=format&dpr=2 2x`}
                            alt={item.title}
                            onClick={() => {
                                setFolderName(item)
                            }}
                        />
                        <Typography variant='subtitle1'>{item.title}</Typography>
                    </ImageListItem>
                ))}
            </ImageList>
        </>
    )
}

export default ItemData;