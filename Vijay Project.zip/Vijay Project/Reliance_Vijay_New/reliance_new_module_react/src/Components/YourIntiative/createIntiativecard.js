import React, { useState, useRef } from "react";
import Slider from "react-slick";
import "./createintiativecard.css";
import dayjs from "dayjs";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import Grid from "@mui/material/Grid";
import HighlightOffOutlinedIcon from "@mui/icons-material/HighlightOffOutlined";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import Tabs, { tabsClasses } from "@mui/material/Tabs";
import {
  Card,
  CardContent,
  DialogActions,
  Paper,
  IconButton,
} from "@mui/material";
import RowImage from "../SavaUpdate/RowImage/RowImage";
import first from "../../asserts/images/1st.png";
import one from "../../asserts/images/1.jpg";
import second from "../../asserts/images/2nd.png";
import two from "../../asserts/images/4.jpg";
import third from "../../asserts/images/3rd.png";
import three from "../../asserts/images/2.jpg";
import { useFormik } from "formik";
import * as yup from "yup";
import UploadIcon from "@mui/icons-material/Upload";

const validationSchema = yup.object({
  participants: yup
    .string("Please enter participants")
    .required("Participants is required"),
  InitiativeDescription: yup
    .string("Please set a Initiative Description")
    .required("Enter Initiative Description"),
});

const CreateInitiativeCard = (props) => {
  console.log("SAURABH=>", props);
  const { onClose, data } = props;
  const [dateValue, setDateValue] = React.useState(
    dayjs("2014-08-18T21:11:54")
  );
  const [open, setOpen] = useState(false);

  const [value, setValue] = useState(0);
  const [imgPreview, setimgPreview] = useState([]);
  const handleClose = () => {
    setOpen(false);
  };

  const formik = useFormik({
    initialValues: {
      participants: "",
      InitiativeDescription: "",
    },
    validationSchema: validationSchema,
    onSubmit: (values) => {
      values.id = data.id;
      values.status = "Completed";
      props.handleCardData(values);
      onClose();
    },
  });

  const cardsData = [
    "https://images.pexels.com/photos/60597/dahlia-red-blossom-bloom-60597.jpeg?auto=compress&cs=tinysrgb&w=1600",
    "https://images.pexels.com/photos/33109/fall-autumn-red-season.jpg?auto=compress&cs=tinysrgb&w=1600",
    "https://images.pexels.com/photos/1198802/pexels-photo-1198802.jpeg?auto=compress&cs=tinysrgb&w=1600",
    "https://images.pexels.com/photos/443446/pexels-photo-443446.jpeg?auto=compress&cs=tinysrgb&w=1600",
    "https://images.pexels.com/photos/60597/dahlia-red-blossom-bloom-60597.jpeg?auto=compress&cs=tinysrgb&w=1600",
    "https://images.pexels.com/photos/33109/fall-autumn-red-season.jpg?auto=compress&cs=tinysrgb&w=1600",
    "https://images.pexels.com/photos/1198802/pexels-photo-1198802.jpeg?auto=compress&cs=tinysrgb&w=1600",
  ];

  const settings = {
    dots: true,
    infinite: false,
    speed: 500,
    slidesToShow: 6,
    slidesToScroll: 4,
    arrows: true,
  };

  const handleChange = (event, newValue) => {
    setDateValue(newValue);
  };
  const sevaData = [
    {
      id: 1,
      image: one,
      heading: "",
    },
    {
      id: 2,
      image: two,
      heading: "",
    },
    {
      id: 3,
      image: three,
      heading: "",
    },
  ];
  const [updateRowData, setUpdateRowData] = useState(sevaData);
  const updateRow = (value) => {
    setUpdateRowData(updateRowData.filter((val) => val.id !== value));
  };
  //upload image
  const handleClick = (event) => {
    hiddenFileInput.current.click();
  };
  const hiddenFileInput = useRef(null);
  const [images, setImages] = useState([]);

  // const handleImageChange = (e) => {
  //   const uploadedFiles = e.target.files;
  //   let newImages = [];
  //   for (let i = 0; i < uploadedFiles.length; i++) {
  //     const reader = new FileReader();
  //     reader.readAsDataURL(uploadedFiles[i]);
  //     reader.onload = () => {
  //       newImages.push({ url: reader.result });
  //       if (i === uploadedFiles.length - 1) {
  //         setImages([...images, ...newImages]);
  //       }
  //     };
  //   }
  // };
  const handleDelete = (id) => {
    // setfilteredImgs(filteredImgs.filter((x) => x !== id));
    const updatedimgs = imgPreview.filter((x) => x !== id);
    setimgPreview(updatedimgs);

    console.log("img----", imgPreview);
  };
  const handleImageChange = (e) => {
    const uploadedFiles = e.target.files[0];
    formik.setFieldValue("url", URL.createObjectURL(uploadedFiles));
    setimgPreview([...imgPreview, URL.createObjectURL(uploadedFiles)]);
  };
  return (
    <Dialog
      className="dialog-custom"
      maxWidth="sm"
      open={true}
      onClose={() => onClose(false)}
    >
      <DialogContent className="main_content">
        <Box sx={{ width: "100%" }}>
          <Grid rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
            <Grid item>
              <Grid direction="row" container>
                <Grid item xs={11}>
                  <Typography
                    style={{
                      fontFamily: "HK Grotesk",
                      fontSize: "22px",
                      fontWeight: "Bold",
                    }}
                    align="center"
                  >
                    Create Initiative Report for
                  </Typography>
                  <div>
                    <Typography
                      style={{
                        fontFamily: "HK Grotesk",
                        fontSize: "26px",
                        fontWeight: "Bold",
                      }}
                      align="center"
                      className="subcontent"
                    >
                      {" "}
                      {`seva -${data.id} ${data.name}`}
                    </Typography>
                  </div>
                </Grid>
                <Grid item xs={1}>
                  <HighlightOffOutlinedIcon
                    onClick={() => onClose(false)}
                    className="close_icon"
                  />
                </Grid>
              </Grid>
              <Grid
                container
                rowSpacing={1}
                columnSpacing={{ xs: 1, sm: 2, md: 3 }}
              >
                <Grid item xs={6}>
                  <label className="label-text">Participants</label>
                  <TextField
                    fullWidth
                    margin="dense"
                    variant="outlined"
                    label="Participants"
                    id="participants"
                    value={formik.values.participants}
                    onChange={formik.handleChange}
                    error={
                      formik.touched.participants &&
                      Boolean(formik.errors.participants)
                    }
                    helperText={
                      formik.touched.participants && formik.errors.participants
                    }
                  ></TextField>
                </Grid>
                <Grid item xs={12}>
                  <label className="label-text">Initiative Description</label>

                  <TextField
                    fullWidth
                    margin="dense"
                    className="description-input"
                    variant="outlined"
                    multiline
                    rows={2}
                    maxRows={4}
                    label="Initiative Description"
                    id="InitiativeDescription"
                    value={formik.values.InitiativeDescription}
                    onChange={formik.handleChange}
                    error={
                      formik.touched.InitiativeDescription &&
                      Boolean(formik.errors.InitiativeDescription)
                    }
                    helperText={
                      formik.touched.InitiativeDescription &&
                      formik.errors.InitiativeDescription
                    }
                  ></TextField>
                </Grid>

                <Grid item xs={12}>
                  <label className="label-text">Upload Event images</label>

                  {/* <RowImage
              title=""
              data={updateRowData}
              updateData={updateRow}
            // user={user?user:newUser}
            /> */}
                  <Grid item xs={24} sx={{ pr: 1, pl: 1 }}>
                    <input
                      type="file"
                      ref={hiddenFileInput}
                      style={{ display: "none" }}
                      multiple
                      onChange={handleImageChange}
                    />
                    <Box
                      sx={{
                        display: "flex",
                        "& > :not(style)": {
                          m: 1,
                          width: 488,
                          height: 128,
                        },
                      }}
                    >
                      <Tabs
                        className="cards_coniner"
                        // value={value}
                        // onChange={handleChange}
                        variant="scrollable"
                        scrollButtons
                        aria-label="visible arrows tabs example"
                        sx={{
                          [`& .${tabsClasses.scrollButtons}`]: {
                            "&.Mui-disabled": { opacity: 0.3 },
                          },
                        }}
                      >
                        {imgPreview.length > 0 &&
                          imgPreview.map((item) => (
                            <div className="imageConatiner">
                              <HighlightOffOutlinedIcon
                                className="closeImagePreview"
                                onClick={() => handleDelete(item)}
                                style={{
                                  cursor: "pointer",
                                }}
                              />
                              <img className="imagePreview" src={item} />
                            </div>
                          ))}
                        <Paper
                          variant="outlined"
                          square
                          sx={{
                            border: "1px solid blue",
                            borderStyle: "dashed",
                          }}
                        >
                          <IconButton
                            color="primary"
                            aria-label="Upload"
                            onClick={handleClick}
                            sx={{ display: "flex", flexDirection: "column" }}
                          >
                            <UploadIcon />
                            <br />

                            {imgPreview.length > 0
                              ? "Add More Images"
                              : "Add Images"}
                          </IconButton>
                        </Paper>
                      </Tabs>
                    </Box>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
            <Grid item xs={12} mt-2>
              <Grid container className="mx-auto">
                <Grid item xs={12} className="mx-auto">
                  <DialogActions className="submit_save">
                    <Button
                      variant="contained"
                      className="submit_button"
                      autoFocus
                      onClick={handleClose && formik.handleSubmit}
                      sx={{ backgroundColor: "#ef7335" }}
                    >
                      Submit
                    </Button>
                  </DialogActions>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default CreateInitiativeCard;
