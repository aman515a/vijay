import React, { useEffect, useRef, useState } from 'react';
// import 'bootstrap/dist/css/bootstrap.min.css';

import SideMenu from '../SideMenu/SideMenu';
import TableHighlights from '../Highlights/TableHighlights';
import ThreeCards from '../MpHome/ThreeCards';
import { Grid, Tabs } from '@mui/material';
import Search from '../MpHome/Search';
import DateFilter from '../ReusableComponents.js/DateFilter';
import { useDispatch, useSelector } from 'react-redux';
import { getMpList } from '../../store/action/mpList';
import StickyHeadTable from '../MpHome/MpTable';
const AdminHome = ({readonly}) => {
    const [cardClick, setCardClick] = useState("sevaScore")
    const [tabactive, settabactive] = useState(1)
    
    const [flag,setFlag]=useState(101)
    const mpList = useSelector((state)=>state?.mpList?.data)
    
    console.log("mpList",mpList)
    const dispatch = useDispatch();
    
    useEffect(()=>{
      console.log("ressssssss")
      //call api to update store
      dispatch(getMpList(flag));

    },[flag])
    
    const containerRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);

  const handleMouseDown = (event) => {
    setIsDragging(true);
    setStartX(event.pageX - containerRef.current.offsetLeft);
    setScrollLeft(containerRef.current.scrollLeft);
  };

  const handleMouseMove = (event) => {
    if (!isDragging) return;
    event.preventDefault();
    const x = event.pageX - containerRef.current.offsetLeft;
    const distance = (x - startX) * 2;
    containerRef.current.scrollLeft = scrollLeft - distance;
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };
    return (
        <div className="page-wrapper d-flex">
            <SideMenu active="Leader" user={readonly?"Leader":"Admin"} />
            <div className="main-wrapper" style={{width:"calc(100% - 230px)"}}>
            <Grid container >
                    <Grid md={12} lg={8} xl={8}>
                        <div className="d-flex justify-content-between align-items-center">
                            <h1 className="page-title mb-0">MP Leaderboard</h1>
                            <Search user="Admin" />
                        </div>
                        <DateFilter />
                        <div className="filter-btns row no-gutters pt-3">
                        {/* {props.user!=="Admin" && */}
                   <Tabs
                    // value={value}
                    // onChange={handleChange}
                    variant="scrollable"
                    scrollButtons={false}
                    aria-label="scrollable auto tabs example"
                  >
                    <div
                    aria-label="scrollable auto tabs example"
                    ref={containerRef}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      overflowX: "hidden"
                    }}
                    onMouseDown={handleMouseDown}
                    onMouseMove={handleMouseMove}
                    onMouseUp={handleMouseUp}
                    onMouseLeave={handleMouseUp}
                  >
                    <button
                      type="button"
                      className={
                        tabactive === 1
                          ? "btn btn-primary primary-btn mr-3 mt-1 mb-3"
                          : "btn btn-primary normal-btn mr-3 mt-1 mb-3"
                      }
                      onClick={() => {
                        settabactive(1);
                        setCardClick("sevaScore");
                        setFlag(101)
                      }}
                    >
                      MP Seva Score
                    </button>
                    <button
                      type="button"
                      className={
                        tabactive === 2
                          ? "btn btn-primary primary-btn mr-3 mt-1 mb-3"
                          : "btn btn-primary normal-btn mr-3 mt-1 mb-3"
                      }
                      onClick={() => {
                        settabactive(2);
                        setCardClick("initiatives");
                        setFlag(102)
                      }}
                    >
                      Initiatives
                    </button>
                    <button
                      type="button"
                      className={
                        tabactive === 3
                          ? "btn btn-primary primary-btn mr-3 mt-1 mb-3"
                          : "btn btn-primary normal-btn mr-3 mt-1 mb-3"
                      }
                      onClick={() => {
                        settabactive(3);
                        setCardClick("memberAdded");
                        setFlag(103)
                      }}
                    >
                      Members Added
                    </button>
                    <button
                      type="button"
                      className={
                        tabactive === 4
                          ? "btn btn-primary primary-btn mr-3 mt-1 mb-3"
                          : "btn btn-primary normal-btn mr-3 mt-1 mb-3"
                      }
                      onClick={() => {
                        settabactive(4);
                        setCardClick("followers");
                        setFlag(104)
                      }}
                    >
                      Followers
                    </button>
                    <button
                      type="button"
                      className={
                        tabactive === 5
                          ? "btn btn-primary primary-btn mr-3 mt-1 mb-3"
                          : "btn btn-primary normal-btn mr-3 mt-1 mb-3"
                      }
                      onClick={() => {
                        settabactive(5);
                        setCardClick("twitterPerformance");
                        setFlag(105)
                      }}
                    >
                      Twitter Performance
                    </button>
                    <button
                      type="button"
                      className={
                        tabactive === 6
                          ? "btn btn-primary primary-btn mr-3 mt-1 mb-3"
                          : "btn btn-primary normal-btn mr-3 mt-1 mb-3"
                      }
                      onClick={() => {
                        settabactive(6);
                        setCardClick("mediaCoverage");
                        setFlag(106)
                      }}
                    >
                      Op-Eds & Media Coverage
                    </button>
                    <button
                      type="button"
                      className={
                        tabactive === 7
                          ? "btn btn-primary primary-btn mr-3 mt-1 mb-3"
                          : "btn btn-primary normal-btn mr-3 mt-1 mb-3"
                      }
                      onClick={() => {
                        settabactive(7);
                        setCardClick("donation");
                        setFlag(107)
                      }}
                    >
                      Donations
                    </button>
                    </div>
                    </Tabs></div>

                        <hr className="mt-2 mb-4" />
                        <ThreeCards cardClick={cardClick} user={readonly?"Leader":"Admin"}/>
                        <div className="mt-5 learders-list">
                            <StickyHeadTable cardClick={cardClick} flag={flag} count={1} />
                        </div>
                    </Grid>
                    <Grid md={12} lg={4} xl={4}>
                        <div className="right-card mb-3">
                            <div className="highlights-title">
                            <h1 >Highlights</h1>
                            <p className="mb-0" >All India Seva Initiatives</p>

                            </div>

                            <TableHighlights/>
                        </div>
                    
                    </Grid>
            </Grid>
                </div>
            </div>
    )
}

export default AdminHome;




