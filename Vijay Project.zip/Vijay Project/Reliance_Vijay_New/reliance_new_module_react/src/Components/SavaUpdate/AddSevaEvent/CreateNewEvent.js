import React, { useState, useRef, useEffect } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import AddIcon from "@mui/icons-material/Add";
import {
    Select,
    MenuItem,
    Button,
    TextField,
    Grid,
    Box,
    FormControl,
    InputLabel,
    Card,
    CardContent,
    Paper,
    IconButton,
    FormHelperText
} from "@mui/material";
import { useForm } from "react-hook-form";
import Tabs, { tabsClasses } from '@mui/material/Tabs';
import UploadIcon from '@mui/icons-material/Upload';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { useDispatch, useSelector } from 'react-redux';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { TimePicker } from '@mui/x-date-pickers/TimePicker';
import CloseIcon from '@mui/icons-material/Close';
import { postCreateEvent } from "../../../store/action/createNewEvent";
import Moment from 'moment';
import { useLoading } from "../../../utils/LoadingContext";
import { useNotificationContext } from "../../../utils/NotificationContext";
import { getEventsList } from "../../../store/action/eventsList";
const CreateNewEvent = ({ handleCloseCreateEvent, openCreateEventDialog, isSevaEventEdit, details, handleCloseInitiativeDetails }) => {
    const { setLoading } = useLoading();
    const { showNotification } = useNotificationContext();
    const [images, setImages] = useState([]);
    const [files, setFiles] = useState([]);
    const [value, setValue] = useState(0);
    const [startDate, setStartDate] = useState(null);
    const [endDate, setEndDate] = useState(null);
    const [startTime, setStartTime] = useState(null);
    const [endTime, setEndTime] = useState(null);
    const { register, handleSubmit, formState: { errors }, resetField } = useForm();
    const hiddenFileInput = useRef(null);
    const dispatch = useDispatch();

    // const handleChange = (event, newValue) => {
    //     setValue(newValue);
    // };

    useEffect(() => {
        if (details) {
            setImages(details?.media && JSON.parse(details?.media))
        }
    }, [details])

    useEffect(() => {
        if (details) {
            setStartDate(details?.startDate);
            setEndDate(details?.endDate);
            setStartTime(details?.startTime);
            setEndTime(details?.endTime);
            // console.log("edd", details?.endTime.slice(0, 5) + " " + "PM")
            // console.log("edd", details?.statTime)
        }
    }, [])

    const onAddMediaCoverage = async (data) => {
        const sTime = startTime;
        const st = new Date(sTime);
        const eTime = startTime;
        const et = new Date(eTime);
        const formData = new FormData();
        formData.append("eventTitle", data?.eventTitle);
        formData.append("location", data?.location);
        formData.append("startDate", Moment(startDate).format('YYYY-MM-DD'));
        formData.append("endDate", Moment(endDate).format('YYYY-MM-DD'));
        formData.append("startTime", st.toISOString());
        formData.append("endTime", et.toISOString());
        formData.append("mpmodelId", 10);
        formData.append("desc", data?.desc);
        Array.from(files).forEach(file => formData.append(`media`, file, file.name));
        const config = {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        }
        try {
            setLoading(true);
            if (files.length === 0) {
                showNotification("Error", "Please add image");
                return;
            }
            const response = await dispatch(postCreateEvent(formData, config));
            if (response.status === 200 || response.status === 201) {
                showNotification("Success", response.data.message, 'success');
                handleCloseCreateEvent();
                if (details) {
                    handleCloseInitiativeDetails();
                }
                dispatch(getEventsList());
                Object.keys(data).map(val => resetField(val));
                setImages([]);
                setFiles([]);
            }
        } catch (error) {
            console.log("err", error);
            showNotification("Error", "Failed to fetch");
        }
        finally {
            setLoading(false);
        }
        // dispatch(postCreateEvent(formData, config));
    }

    const handleDelete = (index) => {
        const tempImages = [...images];
        tempImages.splice(index, 1)
        setImages(tempImages);
    }

    const handleImageChange = (e) => {
        const uploadedFiles = e.target.files;
        setFiles([...files, ...uploadedFiles]);

        let newImages = [];
        for (let i = 0; i < uploadedFiles.length; i++) {
            const reader = new FileReader();
            reader.readAsDataURL(uploadedFiles[i]);
            reader.onload = () => {
                newImages.push({ url: reader.result, file: uploadedFiles[i] });
                if (i === uploadedFiles.length - 1) {
                    setImages([...images, ...newImages]);
                }
            };
        }
    };
    const handleClick = event => {
        hiddenFileInput.current.click();
    };

    return (
        <>
            <Dialog open={openCreateEventDialog} onClose={handleCloseCreateEvent} className="card-modal-height" sx={{ mt: 2 }}>
                <DialogTitle
                >
                    <Box sx={{ display: "flex", justifyContent: 'flex-start', color: "#357092" }}>
                        <div style={{ fontFamily: 'HK Grotesk', color: "#2C2C2C", fontSize: "26px", fontWeight: 'bold' }}>
                            <b>Create an Event</b>
                        </div>
                        <CloseIcon
                            className="pageHeader"
                            onClick={handleCloseCreateEvent}
                            sx={{
                                position: 'absolute',
                                right: 8,
                                top: 8,
                                color: (theme) => theme.palette.grey[500],
                                border: "1px solid #9e9e9e",
                                borderRadius: "50%",
                                padding: "2px",
                                cursor: "pointer",
                            }}
                        />
                    </Box>
                </DialogTitle>
                <Grid container className="bg-white">
                    <Grid item xs={12} md={12}>
                        <Grid item xs={12} md={12} sx={{ p: 4 }}>
                            <Box>
                                <form>
                                    <Grid
                                        container
                                        spacing={1}
                                        justifyContent="left"
                                        alignItems="center"
                                    >
                                        <Grid container sx={{ mb: 2 }}>
                                            <Grid item xs={12} sx={{ pr: 1 }}>
                                                <div style={{ fontFamily: 'HK Grotesk', color: "#2C2C2C", fontSize: "16px", fontWeight: 'bold' }}>
                                                    <b>Event Title</b>
                                                </div>
                                                <FormControl fullWidth>
                                                    <TextField
                                                        className="stepperFormInput"
                                                        label="Event Title"
                                                        name="eventTitle"
                                                        fullWidth
                                                        placeholder="Enter title"
                                                        size="small"
                                                        required
                                                        defaultValue={details && details?.eventTitle}
                                                        autoComplete="off"
                                                        {...register("eventTitle", { required: "Please enter event title" })}
                                                    //   error={Boolean(errors?.employeeId?.message)}
                                                    //   helperText={errors?.employeeId?.message}
                                                    //   onChange={() => setIsUpdateButton(false)}
                                                    />
                                                </FormControl>
                                                <FormHelperText sx={{ color: "#d32f2f" }}>
                                                    {errors && errors?.eventTitle?.message}
                                                </FormHelperText>
                                            </Grid>

                                        </Grid>
                                        <Grid container sx={{ mb: 2 }}>
                                            <Grid item xs={12} sx={{ pr: 1 }}>
                                                <div style={{ fontFamily: 'HK Grotesk', color: "#2C2C2C", fontSize: "16px", fontWeight: 'bold' }}>
                                                    <b>Location</b>
                                                </div>
                                                <FormControl fullWidth>
                                                    <TextField
                                                        className="stepperFormInput"
                                                        label="Location"
                                                        name="location"
                                                        fullWidth
                                                        placeholder="Enter location"
                                                        size="small"
                                                        required
                                                        defaultValue={details && details?.location}
                                                        autoComplete="off"
                                                        {...register("location", { required: "Please enter location" })}
                                                    //   error={Boolean(errors?.employeeId?.message)}
                                                    //   helperText={errors?.employeeId?.message}
                                                    //   onChange={() => setIsUpdateButton(false)}
                                                    />
                                                </FormControl>
                                                <FormHelperText sx={{ color: "#d32f2f" }}>
                                                    {errors && errors?.location?.message}
                                                </FormHelperText>
                                            </Grid>

                                        </Grid>
                                        {/* <Grid container sx={{ mb: 2 }}>
                                            <Grid item xs={12} sx={{ pr: 1 }}> */}
                                        {/* <FormControl fullWidth>
                                                    <InputLabel
                                                        id="demo-simple-select-label"
                                                        sx={{ marginTop: "-6px" }}
                                                    >
                                                        Location
                                                    </InputLabel> */}
                                        {/* <Select
                                                        className="stepperFormInput"
                                                        label="Location"
                                                        name="location"
                                                        fullWidth
                                                        placeholder="Enter location"
                                                        defaultValue={details?.location}
                                                        required
                                                        size="small"
                                                        autoComplete="off"
                                                        {...register("location", { required: true })} */}
                                        {/* // error={errors?.roleId}
                                                    // helperText={errors?.roleId?.message}
                                                    // onChange={() => setIsUpdateButton(false)}
                                                    // > */}
                                        {/* {types &&
                                                            types.map((s) => {
                                                                return (
                                                                    <MenuItem
                                                                        native
                                                                        key={s.id}
                                                                        sx={{ width: "100%" }}
                                                                        value={s.id}
                                                                        size="small"
                                                                    >
                                                                        {s.value}
                                                                    </MenuItem>
                                                                );
                                                            })}
                                                    </Select> */}
                                        {/* <FormHelperText sx={{ color: "#d32f2f" }}>
                                                        {errors && errors?.roleId?.message}
                                                    </FormHelperText> */}
                                        {/* </FormControl>
                                            </Grid>
                                        </Grid> */}
                                        <Grid container sx={{ mb: 2 }}>
                                            <Grid item xs={6} sx={{ pr: 1 }}>
                                                <div style={{ fontFamily: 'HK Grotesk', color: "#2C2C2C", fontSize: "16px", fontWeight: 'bold' }}>
                                                    <b>Start Date</b>
                                                </div>
                                                <LocalizationProvider dateAdapter={AdapterDayjs}>
                                                    <DatePicker
                                                        // label="Start Date"
                                                        value={startDate}
                                                        onChange={(newValue) => {
                                                            setStartDate(newValue);
                                                        }}
                                                        defaultValue={startDate}
                                                        renderInput={(params) => <TextField {...params}
                                                            {...register("startDate", { required: "Start date is required" })}
                                                            error={Boolean(errors?.startDate?.message)}
                                                            helperText={errors?.startDate?.message} />}
                                                    />
                                                </LocalizationProvider>
                                            </Grid>
                                            <Grid item xs={6} >
                                                <div style={{ fontFamily: 'HK Grotesk', color: "#2C2C2C", fontSize: "16px", fontWeight: 'bold' }}>
                                                    <b>End Date</b>
                                                </div>
                                                <LocalizationProvider dateAdapter={AdapterDayjs}>
                                                    <DatePicker
                                                        // label="End Date"
                                                        value={endDate}
                                                        onChange={(newValue) => {
                                                            setEndDate(newValue);
                                                        }}
                                                        defaultValue={endDate}
                                                        renderInput={(params) => <TextField {...params}
                                                            {...register("endDate", { required: "End date is required" })}
                                                            error={Boolean(errors?.endDate?.message)}
                                                            helperText={errors?.endDate?.message} />}
                                                    />
                                                </LocalizationProvider>
                                            </Grid>
                                        </Grid>
                                        <Grid container sx={{ mb: 2 }}>
                                            <Grid item xs={6} sx={{ pr: 1 }}>
                                                <div style={{ fontFamily: 'HK Grotesk', color: "#2C2C2C", fontSize: "16px", fontWeight: 'bold' }}>
                                                    <b>Start Time</b>
                                                </div>
                                                <LocalizationProvider dateAdapter={AdapterDayjs}>
                                                    <TimePicker
                                                        // label="Start Time"
                                                        value={startTime}
                                                        onChange={(newValue) => {
                                                            setStartTime(newValue);
                                                        }}
                                                        // defaultValue={startTime}
                                                        renderInput={(params) => <TextField {...params}
                                                            {...register("startTime", { required: "Start Time is required" })}
                                                            error={Boolean(errors?.startTime?.message)}
                                                            helperText={errors?.startTime?.message} />}
                                                    />
                                                </LocalizationProvider>
                                            </Grid>
                                            <Grid item xs={6} >
                                                <div style={{ fontFamily: 'HK Grotesk', color: "#2C2C2C", fontSize: "16px", fontWeight: 'bold' }}>
                                                    <b>End Date</b>
                                                </div>

                                                <LocalizationProvider dateAdapter={AdapterDayjs}>
                                                    <TimePicker

                                                        // label="End Time"
                                                        value={endTime}
                                                        onChange={(newValue) => {
                                                            setEndTime(newValue);
                                                        }}
                                                        // defaultValue={endTime}
                                                        renderInput={(params) => <TextField {...params}
                                                            {...register("endTime", { required: "End time is required" })}
                                                            error={Boolean(errors?.endTime?.message)}
                                                            helperText={errors?.endTime?.message} />}
                                                    />
                                                </LocalizationProvider>
                                            </Grid>
                                        </Grid>
                                        <Grid container sx={{ mb: 2, mt: 1 }}>
                                            <Grid item xs={12} sx={{ pr: 1 }}>
                                                <div style={{ fontFamily: 'HK Grotesk', color: "#2C2C2C", fontSize: "16px", fontWeight: 'bold' }}>
                                                    <b>Event Description</b>
                                                </div>
                                                <FormControl>
                                                    <TextField
                                                        className="stepperFormInput"
                                                        label="Event Description"
                                                        name="desc"
                                                        placeholder="Event Description"
                                                        fullWidth
                                                        required
                                                        multiline
                                                        defaultValue={details?.desc}
                                                        size="small"
                                                        autoComplete="off"
                                                        {...register("desc", { required: "Please enter description" })}
                                                    //   error={Boolean(errors?.mobileNumber)}
                                                    //   helperText={errors?.mobileNumber?.message}
                                                    //   onChange={() => setIsUpdateButton(false)}
                                                    />
                                                </FormControl>
                                                <FormHelperText sx={{ color: "#d32f2f" }}>
                                                    {errors && errors?.desc?.message}
                                                </FormHelperText>
                                            </Grid>
                                        </Grid>
                                        <Grid container>
                                            <div>
                                                <div style={{ fontFamily: 'HK Grotesk', color: "#356F92", fontSize: "16px", fontWeight: 'bold' }}>
                                                    <b>Upload Promotional Images</b>

                                                </div>
                                                <div style={{ fontFamily: 'HK Grotesk', color: "#2C2C2C", fontSize: "14px", fontWeight: 'bold' }}>

                                                    <b>Note: Select one of the image as a cover photo​*</b>
                                                </div>


                                                {images?.length > 0 ? <Grid item xs={6} sx={{ pr: 1 }}>

                                                    <Box
                                                        sx={{
                                                            flexGrow: 1,
                                                            minWidth: { xs: 300, sm: 300 },
                                                        }}
                                                    >
                                                        {images?.length > 1 ? <Tabs
                                                            // value={value}
                                                            // onChange={handleChange}
                                                            variant="scrollable"
                                                            scrollButtons
                                                            aria-label="visible arrows tabs example"
                                                            sx={{
                                                                [`& .${tabsClasses.scrollButtons}`]: {
                                                                    '&.Mui-disabled': { opacity: 0.3 },
                                                                },
                                                            }}
                                                        >
                                                            {images?.map((image, index) =>
                                                                <Card sx={{ minWidth: 100, mr: 2 }} className="photo-size">
                                                                    <CardContent>
                                                                        {/* <img width="38.49" src={first} className="position-absolute" alt="" /> */}
                                                                        <img key={index} src={typeof image === 'string' ? image : image.url} alt="" className="form-img__img-preview" />
                                                                        <Button onClick={() => handleDelete(index)}>delete</Button>
                                                                    </CardContent>
                                                                </Card>
                                                            )}
                                                        </Tabs> : (
                                                            images?.map((image, index) =>
                                                                <Card sx={{ minWidth: 100, mr: 2 }} className="photo-size">
                                                                    <CardContent>
                                                                        {/* <img width="38.49" src={first} className="position-absolute" alt="" /> */}
                                                                        <img key={index} src={typeof image === 'string' ? image : image.url} alt="" className="form-img__img-preview" />
                                                                        <Button onClick={() => handleDelete(index)}>delete</Button>
                                                                    </CardContent>
                                                                </Card>
                                                            )
                                                        )
                                                        }
                                                    </Box>
                                                    {/* <h6>Event Images</h6>
                                                <input type="file" ref={hiddenFileInput} style={{ display: 'none' }} multiple onChange={handleImageChange} />
                                                <div>
                                                    {images.map((image, index) => (
                                                        <img key={index} src={image.url} alt="" className="form-img__img-preview" />
                                                    ))}
                                                </div> */}
                                                </Grid> : null}
                                                <Grid item xs={6} sx={{ pr: 1, pl: 1 }}>
                                                    <input type="file" ref={hiddenFileInput} style={{ display: 'none', margin: "0 auto" }} multiple onChange={handleImageChange} accept="image/*" />
                                                    <Box
                                                        sx={{
                                                            display: 'flex',
                                                            '& > :not(style)': {
                                                                m: 1,
                                                                width: 160,
                                                                height: 140,

                                                            },
                                                        }}
                                                    >
                                                        <Paper variant="outlined" square sx={{}}>
                                                            <IconButton color="primary" aria-label="Upload" onClick={handleClick} sx={{ display: "flex", justifyContent: "center", position: "relative", top: "25%", margin: "0 auto" }}>
                                                                <UploadIcon />
                                                            </IconButton>
                                                            <b style={{ display: "flex", justifyContent: "center", position: "relative", top: "25%", whiteSpace: "nowrap", padding: "10px" }}> Add More Images</b>
                                                        </Paper>
                                                    </Box>
                                                </Grid>
                                            </div></Grid>
                                    </Grid>
                                </form>
                            </Box>
                        </Grid>

                    </Grid>

                </Grid>
                <React.Fragment>
                    <div className="button-center-card">
                        <Box >
                            <Button
                                variant="contained"
                                sx={{ p: 1, mr: 1, backgroundColor: "#ef7335" }}
                                className="button-tr-2 "
                                onClick={handleSubmit(onAddMediaCoverage)}
                            >
                                {isSevaEventEdit ? "Update" : "Submit"}
                            </Button>

                        </Box>
                    </div>
                </React.Fragment>
            </Dialog>
        </>
    );
};

export default CreateNewEvent;