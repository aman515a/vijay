import React, { useEffect, useState } from "react";
import PropTypes from 'prop-types';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import { IconButton, Box, Card, CardContent } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import Tabs, { tabsClasses } from '@mui/material/Tabs';
import one from "../../../asserts/images/1.jpg"
import two from "../../../asserts/images/4.jpg";
import three from "../../../asserts/images/2.jpg";
import NoImageFound from "../../../asserts/images/noImageFound.jpg";
import ShareIcon from '@mui/icons-material/Share';
import CancelSharpIcon from '@mui/icons-material/CancelSharp';
import BorderColorIcon from '@mui/icons-material/BorderColor';
import "./AddSevaEvent.css";
import CreateNewEvent from "./CreateNewEvent";
import { useDispatch, useSelector } from "react-redux";
import getInitiativeList from "../../../store/action/initiativeList";

const AddSevaEvent = ({ handleCloseSevaEvent, openSevaEvent, details }) => {
    const cardsData = [
        {
            name: "Shri Ramesh Bidhuri",
            designation: "President,BJP,Gujarat Pradesh",
            consitituency: "Navasari GUjarati",
            imageSrc: one,
        },
        {
            name: "Shri Bhupesh Baghel",
            designation: "Lok Sabha MP",
            consitituency: "Durg (Chhattisgarh)",
            imageSrc: two,
        }, {
            name: "Smt. Rama Bidhuri",
            designation: "Lok Sabha MP",
            consitituency: "Navasari (Gujarat)",
            imageSrc: three
        },
        {
            name: "Shri Ramesh Bidhuri",
            designation: "President,BJP,Gujarat Pradesh",
            consitituency: "Navasari GUjarati",
            imageSrc: one,
        },
        {
            name: "Shri Ramesh Bidhuri",
            designation: "President,BJP,Gujarat Pradesh",
            consitituency: "Navasari GUjarati",
            imageSrc: two,
        },
        {
            name: "Shri Ramesh Bidhuri",
            designation: "President,BJP,Gujarat Pradesh",
            consitituency: "Navasari GUjarati",
            imageSrc: one,
        },
        {
            name: "Shri Bhupesh Baghel",
            designation: "Lok Sabha MP",
            consitituency: "Durg (Chhattisgarh)",
            imageSrc: two,
        }, {
            name: "Smt. Rama Bidhuri",
            designation: "Lok Sabha MP",
            consitituency: "Navasari (Gujarat)",
            imageSrc: three
        }
    ]

    const [value, setValue] = useState(0);
    const initiativeList=useSelector((state)=>state?.initiativeList?.data)
    const [openCreateEventDialog, setOpenCreateEventDialog] = useState(false);
    const dispatch=useDispatch()
    useEffect(()=>{
        dispatch(getInitiativeList())
    },[])
    const handleOpenCreateEvent = () => {
        setOpenCreateEventDialog(true);
        handleCloseSevaEvent();
    }
    const handleCloseCreateEvent = () => {
        setOpenCreateEventDialog(false);
    }

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    const BootstrapDialog = styled(Dialog)(({ theme }) => ({
        '& .MuiDialogContent-root': {
            padding: theme.spacing(2),
        },
        '& .MuiDialogActions-root': {
            padding: theme.spacing(1),
        },
    }));

    function BootstrapDialogTitle(props) {
        const { children, onClose, ...other } = props;

        return (
            <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
                {children}
                {onClose ? (
                    <IconButton
                        aria-label="close"
                        onClick={onClose}
                        sx={{
                            position: 'absolute',
                            right: 8,
                            top: 8,
                            color: (theme) => theme.palette.grey[500],
                            border: "1px solid #9e9e9e",
                            borderRadius: "50%"
                        }}
                    >
                        <CloseIcon />
                    </IconButton>
                ) : null}
            </DialogTitle>
        );
    }

    BootstrapDialogTitle.propTypes = {
        children: PropTypes.node,
        onClose: PropTypes.func.isRequired,
    };

    return (
        <div style={{
            minWidth: "70vh",
            margin: "0 50% 0 50%",

            minHeight: "95vh"
        }}>
            <BootstrapDialog
                onClose={handleCloseSevaEvent}
                aria-labelledby="customized-dialog-title"
                open={openSevaEvent}

            >
                <BootstrapDialogTitle id="customized-dialog-title" onClose={handleCloseSevaEvent}>
                    <h5 style={{ fontFamily:"HK Grotesk",fontSize:"26px",color:"#356F92",fontWeight:'bold',marginRight: 2 }}>Choose an initiative for which you would<br /> like to create an event for</h5>
                </BootstrapDialogTitle>
                <DialogContent>
                    <div className="d-flex justify-content-between leaders-cards">
                        <Box
                            sx={{
                                flexGrow: 1,
                                minWidth: { xs: 500, sm: 500 },
                                // bgcolor: 'background.paper',
                            }}
                        >
                            <Tabs
                                value={value}
                                onChange={handleChange}
                                variant="scrollable"
                                scrollButtons
                                aria-label="visible arrows tabs example"
                                sx={{
                                    [`& .${tabsClasses.scrollButtons}`]: {
                                        '&.Mui-disabled': { opacity: 0.3 },
                                    },
                                }}
                            >
                                {initiativeList.map(item =>
                                    // <Card sx={{ minWidth: 200, mr: 2 }} className="image-size">
                                    //     <CardContent>
                                    //         {/* <img width="38.49" src={first} className="position-absolute" alt="" /> */}
                                    //         <div className="text-center pt-3"><img src={item['imageSrc']} className="img-circle leader-circle-img mr-1" width="70" /></div>
                                    //         <div className="card-content">
                                    //             <h2>{item.name}</h2>
                                    //             <span className="initial">{item.designation}</span><br />
                                    //             <span className="constituency">Constituency:{item.consitituency}</span>
                                    //         </div>
                                    //     </CardContent>
                                    // </Card>
                                    <div className="popupCard-size" >
                                        <div className="card popupCard-image" >
                                        <img src={NoImageFound} className="card__image" alt="" />
                                            {/* <img src={item['coverimage']} className="card__image" alt="" /> */}
                                            {/* <IconButton
                                                className="card__icon" sx={{ position: "absolute", right: "5vh" }}
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    // handleShare(data.heading)
                                                }}
                                            >
                                                <ShareIcon role="button"></ShareIcon>
                                            </IconButton> */}
                                            {/* <IconButton
                                                className="card__icon" sx={{ position: "absolute" }}
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    // handleClear(data.id)
                                                }}
                                            >
                                                <CancelSharpIcon role="button"></CancelSharpIcon>

                                            </IconButton> */}

                                            {/* <div className='card__heading'>{data.heading}</div> */}
                                        </div>
                                    </div>
                                )}
                            </Tabs>
                        </Box>
                    </div>
                </DialogContent>
                <div style={{display:"flex",justifyContent:"flex-start",marginLeft:"16px"}}>
                <DialogActions>
                    <div style={{fontFamily:"HK Grotesk",fontSize:"26px",color:"#356F92",fontWeight:'bold'}}> OR</div>
                    <Button  className="button-tr-01" endIcon={<BorderColorIcon />} sx={{ mt: 1, ml: 2 }} onClick={handleOpenCreateEvent}>
                        Create Individual Event
                    </Button>
                </DialogActions>
                </div>
            </BootstrapDialog>
            <CreateNewEvent
                openCreateEventDialog={openCreateEventDialog}
                handleCloseCreateEvent={handleCloseCreateEvent}
            />
        </div>
    );
}

export default AddSevaEvent;