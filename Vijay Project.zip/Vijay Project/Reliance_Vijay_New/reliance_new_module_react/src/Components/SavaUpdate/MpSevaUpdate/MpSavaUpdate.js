import React from 'react'
import { useLocation } from "react-router-dom";
import SevaUpdates from '../SevaUpdates';


function MpSavaUpdate() {
  const location = useLocation();

  // get userId
  let MpName = location?.state?.MpName;
  let user = location?.state?.user;
  let MPId = location?.state?.mpId;

  return (
    <div>
      <SevaUpdates mpName={MpName} user={user} mpId={MPId} />
    </div>
  )
}

export default MpSavaUpdate