import React, { useEffect } from 'react'
import { useLocation } from "react-router-dom";
import SevaUpdates from '../SevaUpdates';


const MySevaUpdate = () => {
    const location = useLocation();
    console.log("loc", location);
    // get userId
    let MpName = location?.state?.MpName;
    let user = location?.state?.user;

    return (
        <div>
            <SevaUpdates mpName={MpName} user={user} mySeva={true}/>
        </div>
    )
}

export default MySevaUpdate;