import React, { useEffect } from 'react';
import { Grid, Breadcrumbs, Card, CardMedia, CardContent, Typography, Button, Divider } from '@mui/material'
import SideMenu from '../SideMenu/SideMenu';
import { Link } from 'react-router-dom';
import { useLocation, useNavigate } from "react-router-dom";
import SevaUpdates from './SevaUpdates';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import { useDispatch, useSelector } from 'react-redux';
import { getEventsList } from '../../store/action/eventsList';
import NoImageFound from "../../asserts/images/noImageFound.jpg";

const ViewAllScreen = ({ user, newUser }) => {
    const location = useLocation();
    const navigate = useNavigate();
    const viewAllValue = location?.state?.viewAllValue;
    const cardsData = location?.state?.data;
    // const dispatch = useDispatch();
    // const eventsList = useSelector((state) => state?.eventsList?.data);

    // console.log("eventsList", eventsList)
    const onFolderClick = () => {
        console.log("inn")
        navigate('/SevaUpdates');
    }

    return (
        <div className="page-wrapper d-flex">
            {/* component 1 */}

            {newUser ? <SideMenu active="Seva" user={newUser} /> :
                <SideMenu active="Seva" user={user} />}

            <div className="main-wrapper" style={{ width: "100%" }}>

                <Grid container>

                    {/* <div className="row"> */}
                    <h1 className="page-title mb-0" style={{ fontSize: "28px", fontWeight: "bold", fontFamily: 'HK Grotesk', color: "#356F92" }}>{viewAllValue}</h1>
                    <Grid container sx={{ mb: 1 }}>
                        <Breadcrumbs aria-label="breadcrumb" separator={<NavigateNextIcon fontSize="small" />}>
                            <Button underline="hover" style={{ color: "#505050", fontWeight: "500", fontSize: "16px" }} onClick={onFolderClick}>
                                Nationwide Seva Updates
                            </Button>
                            <Button underline="hover" style={{ color: "#505050", fontWeight: "500", fontSize: "16px" }}>
                                {viewAllValue}
                            </Button>
                            <Button underline="hover" style={{ color: "#EC6E29", fontWeight: "600", fontSize: "16px" }}>
                                View All
                            </Button>
                        </Breadcrumbs>
                    </Grid>
                    <div className='itemfixed4'>

                        {/* <Grid item xs={8}> */}
                        {cardsData?.map((item, index) =>
                            <Card sx={{ minWidth: 200, mr: 3, mb: 3 }}>
                                <CardMedia
                                    component="img"
                                    height="150"
                                    width="190"
                                    image={(item?.media && JSON.parse(item?.media)[0])}
                                    // image={NoImageFound}
                                    alt="new Image"
                                />
                                <CardContent >
                                    <Typography sx={{ fontSize: "16px", fontWeight: "bold", fontFamily: 'HK Grotesk', color: "#505050" }}>
                                        <b>{item.eventTitle}</b>
                                    </Typography>
                                    <Typography sx={{ fontSize: "14px", fontWeight: "500", fontFamily: 'HK Grotesk', color: "#505050" }}>
                                        {item.name}
                                    </Typography>
                                    <Typography sx={{ fontSize: "12px", fontWeight: "500", fontFamily: 'HK Grotesk', color: "#505050" }}>
                                        Date- {item.endDate}
                                    </Typography>
                                    <Divider sx={{ padding: "5px" }} />
                                    <div style={{ display: "flex", marginTop: "10px" }}>
                                        <div>
                                            <img
                                                key={index}
                                                src={item?.user?.user_avatar}
                                                className="img-circle leader-circle-img mr-1"
                                                width="25"
                                            // style={{ position: 'absol}}
                                            />
                                        </div>
                                        <div style={{ paddingLeft: "10px" }}>
                                            <Typography sx={{ fontSize: "14px", fontWeight: "bold", fontFamily: 'HK Grotesk', color: "#356F92" }}>

                                                {item.user?.user_name}
                                            </Typography>
                                            <Typography sx={{ fontSize: "12px", fontWeight: "500", fontFamily: 'HK Grotesk', color: "#797979" }}>
                                                {item.user?.designation}
                                            </Typography>
                                            <Typography sx={{ fontSize: "12px", fontWeight: "500", fontFamily: 'HK Grotesk', color: "#797979" }}>
                                                {item.user?.constituency_name} - {item.user?.state_name}
                                            </Typography>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        )}
                        {/* {eventsList?.map((item, index) =>
                            <Card sx={{ minWidth: 200, mr: 3, mb: 3 }}>
                                <CardMedia
                                    component="img"
                                    height="150"
                                    width="190"
                                    image={item.media}
                                    alt="new Image"
                                />
                                <CardContent >
                                    <Typography variant="body2" color="text.secondary">
                                        <b>{item.eventTitle}</b>
                                    </Typography>
                                    <Typography color="text.secondary">
                                        {item.name}
                                    </Typography>
                                    <Typography color="text.secondary">
                                        {item.startDate}
                                    </Typography>
                                    <Divider />
                                    <Typography color="text.secondary">
                                        <img
                                            key={index}
                                            src={item.image}
                                            className="img-circle leader-circle-img mr-1"
                                            width="25"
                                        // style={{ position: 'absol}}
                                        />
                                        {item.personName}
                                    </Typography>
                                    <Typography color="text.secondary">
                                        {item.designation}
                                    </Typography>
                                    <Typography color="text.secondary">
                                        {item.location}
                                    </Typography>
                                </CardContent>
                            </Card>
                        )} */}
                        {/* </Grid> */}

                    </div>
                </Grid >
            </div >
        </div >
    )
}

export default ViewAllScreen;