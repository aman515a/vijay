import React, { useState, useEffect } from "react";
import PropTypes from 'prop-types';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import one from "../../../asserts/images/1.jpg"
import two from "../../../asserts/images/4.jpg";
import AddMediaCoverage from "../AddMediaCoverage/AddMediaCoverage";
import Moment from 'moment';
import AddDevelopmentProjects from "../AddDevelopmentProjects/AddDevelopmentProjects";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import AddSevaEvent from "../AddSevaEvent/AddSevaEvent";
import CreateNewEvent from "../AddSevaEvent/CreateNewEvent";
import { Box, Card, CardContent, Grid } from "@mui/material";
import Tabs, { tabsClasses } from '@mui/material/Tabs';
import PreviewImagesDialog from "./PreviewImagesDialog";

const InitiativeDetails = ({ handleCloseInitiativeDetails, openInitiativeDetailsDialog, details, onViewClickTitle, mpName }) => {
    const [openMediaCoverage, setOpenMediaCoverage] = useState(false);
    const [isMediaCoverageEdit, setIsMediaCoverageEdit] = useState(false);
    const [isDevelopmentProjectsEdit, setIsDevelopmentProjectsEdit] = useState(false);
    const [isSevaEventEdit, setIsSevaEventEdit] = useState(false);
    const [openDevelopmentProjects, setOpenDevelopmentProjects] = useState(false);
    const [openCreateEventDialog, setOpenCreateEventDialog] = useState(false);
    const [openPreviewImages, setOpenPreviewImages] = useState(false);

    const [files, setFiles] = useState([]);
    const dummyImage = "[\"https://rnm-api.mobileprogramming.net/uploads/event/media-1677051340990-bjp-logo-hd-wallpaper-download-52650-18645.jpg\"]"
    // const img = JSON.parse(dummyImage);
    const img = [one, two, one];

    useEffect(() => {
        if (details) {
            setFiles(details?.media && JSON.parse(details?.media));
        }
    }, [details])

    const BootstrapDialog = styled(Dialog)(({ theme }) => ({
        '& .MuiDialogContent-root': {
            padding: theme.spacing(2),
        },
        '& .MuiDialogActions-root': {
            padding: theme.spacing(1),
        },
    }));
    function BootstrapDialogTitle(props) {
        const { children, onClose, ...other } = props;

        return (
            <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
                {children}
                {onClose ? (
                    <IconButton
                        aria-label="close"
                        onClick={onClose}
                        sx={{
                            position: 'absolute',
                            right: 8,
                            top: 8,
                            color: (theme) => theme.palette.grey[500],
                            border: "1px solid #9e9e9e",
                            borderRadius: "50%",
                            padding: "2px",
                            cursor: "pointer"
                        }}
                    >
                        <CloseIcon />
                    </IconButton>
                ) : null}
            </DialogTitle>
        );
    }

    BootstrapDialogTitle.propTypes = {
        children: PropTypes.node,
        onClose: PropTypes.func.isRequired,
    };

    const handleOpenMediaCoverage = () => {
        setOpenMediaCoverage(true);
    }
    const handleCloseMediaCoverage = () => {
        setOpenMediaCoverage(false);
    }

    const handleOpenDevelopmentProjects = () => {
        setOpenDevelopmentProjects(true);
    }
    const handleCloseDevelopmentProjects = () => {
        setOpenDevelopmentProjects(false);
    }

    const handleOpenCreateEvent = () => {
        setOpenCreateEventDialog(true);
    }
    const handleCloseCreateEvent = () => {
        setOpenCreateEventDialog(false);
    }

    const handleOpenPreviewImages = () => {
        console.log("inn")
        setOpenPreviewImages(true);
    }
    const handleClosePreviewImages = () => {
        setOpenPreviewImages(false);
    }

    const titleName = () => {
        if (onViewClickTitle === "Seva aur Samarpan Campaign") {
            return `Event Conducted by ${details?.user?.user_name}`
        }
        else if (onViewClickTitle === "OP-Ed's, Books & Media Coverage of") {
            return `${details.title}`
        }
        else if (onViewClickTitle === "Development Projects") {
            return `${details.projecttitle}`
        }
        else if (onViewClickTitle === "Ongoing Seva Initiatives") {
            return `${details?.heading}`
        }
    }

    const onEditClick = () => {
        if (onViewClickTitle === "Seva aur Samarpan Campaign") {
            setIsSevaEventEdit(true);
            handleOpenCreateEvent();
            // return `Event Conducted by ${details.personName}`
        }
        else if (onViewClickTitle === "OP-Ed's, Books & Media Coverage of") {
            setIsMediaCoverageEdit(true);
            handleOpenMediaCoverage();
            // handleCloseInitiativeDetails();
        }
        else if (onViewClickTitle === "Development Projects") {
            setIsDevelopmentProjectsEdit(true);
            handleOpenDevelopmentProjects();
            // return `${details.projecttitle}`
        }
    }

    const handlePreview = (file) => {
        if (file.type === "image" || details) {
            return <img src={one} alt="Preview" className="form-img__img-preview" />;
        } else if (file.type === "video" || details) {
            return (
                <video controls className="form-img__img-preview">
                    <source src={typeof file === 'string' ? file : file.url} type="video/mp4" />
                    Your browser does not support the video tag.
                </video>
            );
        }
    };

    return (
        <div style={{
            minWidth: "70vh",
            margin: "0 50% 0 50%",

            minHeight: "95vh"
        }}>
            <BootstrapDialog
                onClose={handleCloseInitiativeDetails}
                aria-labelledby="customized-dialog-title"
                open={openInitiativeDetailsDialog}

            >
                <BootstrapDialogTitle id="customized-dialog-title" onClose={handleCloseInitiativeDetails}>
                    <div style={{ display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center" }}>
                        <h6 style={{ fontFamily: 'HK Grotesk', color: "#2C2C2C", fontSize: "16px", fontWeight: 'bold' }}>{onViewClickTitle ? (onViewClickTitle === "OP-Ed's, Books & Media Coverage of" ? "Media Coverage of" : onViewClickTitle) : `Initiative Report by ${details?.personName}`}</h6>
                        <h5 style={{ fontFamily: 'HK Grotesk', color: "#356F92", fontSize: "18px", fontWeight: 'bold' }}>{titleName()}</h5>
                    </div>
                </BootstrapDialogTitle>
                <DialogContent>
                    <div className="text-center pt-1">{details?.user?.user_avatar ?
                        <img src={details?.user?.user_avatar} className="img-circle leader-circle-img mr-1" width="70" /> :
                        <AccountCircleIcon
                            sx={{ fontSize: "xx-large", width: "70px", height: "auto" }} />}</div>
                    <div className="card-content">
                        {onViewClickTitle === "Ongoing Seva Initiatives" &&
                            <div>
                                <span>{details?.designation}</span><br />
                                <span className="constituency">{"Constituency" + " : " + details?.place}</span><br />
                                Participants : 50000
                            </div>}
                        <h2>{details?.user?.user_name}</h2>
                        {(onViewClickTitle === "OP-Ed's, Books & Media Coverage of" || onViewClickTitle === "Development Projects") &&
                            <div>
                                <span>{details?.user?.designation}</span><br />
                                <span>{details?.user?.state_name}</span><br />
                            </div>

                        }
                        {onViewClickTitle === "Seva aur Samarpan Campaign" && <span className="initial">{details?.user?.designation + ", " + details?.user?.state_name}</span>}<br />
                        {onViewClickTitle === "Seva aur Samarpan Campaign" && <span className="constituency">{"Constituency" + " : " + details?.user?.constituency_name}</span>}<br />
                        {onViewClickTitle === "Development Projects" && <span>Target Date : {Moment(details?.target).format('MMM YYYY')}</span>}
                        {onViewClickTitle === "Seva aur Samarpan Campaign" && <span >{details?.eventTitle}</span>}
                    </div>
                    {onViewClickTitle === "OP-Ed's, Books & Media Coverage of" ? "About" : (onViewClickTitle === "Development Projects" ? "About" : (onViewClickTitle === "Seva aur Samarpan Campaign" ? "Event Description" : "Initiative Description"))} <br />
                    {details && details.desc}<br />

                    {(onViewClickTitle === "OP-Ed's, Books & Media Coverage of" || onViewClickTitle === "Development Projects") &&
                        <div>
                            <span >Images/Videos</span>
                            <Box
                                sx={{
                                    flexGrow: 1,
                                    minWidth: { xs: 300, sm: 300 },
                                }}
                            >
                                {files.length > 1 ? <Tabs
                                    variant="scrollable"
                                    scrollButtons
                                    aria-label="visible arrows tabs example"
                                    sx={{
                                        [`& .${tabsClasses.scrollButtons}`]: {
                                            '&.Mui-disabled': { opacity: 0.3 },
                                        },
                                    }}
                                >
                                    {files.map((file, index) =>
                                        <Card sx={{ minWidth: 100, mr: 2 }} className="photo-size">
                                            <CardContent>
                                                <div key={index}>{handlePreview(file)}</div>
                                            </CardContent>
                                        </Card>
                                    )}
                                </Tabs> : (
                                    files.map((file, index) =>
                                        <Card sx={{ minWidth: 100, mr: 2 }} className="photo-size">
                                            <CardContent>
                                                <div key={index}>{handlePreview(file)}</div>
                                            </CardContent>
                                        </Card>
                                    )
                                )
                                }
                            </Box>
                        </div>
                    }
                    {onViewClickTitle === "Ongoing Seva Initiatives" &&
                        <div>
                            <div>
                                <span >Images/Videos</span>
                                <Box
                                    sx={{
                                        flexGrow: 1,
                                        minWidth: { xs: 300, sm: 300 },
                                    }}
                                >
                                    {img.length > 1 ? <Tabs
                                        variant="scrollable"
                                        scrollButtons
                                        aria-label="visible arrows tabs example"
                                        sx={{
                                            [`& .${tabsClasses.scrollButtons}`]: {
                                                '&.Mui-disabled': { opacity: 0.3 },
                                            },
                                        }}
                                    >
                                        {img.map((file, index) =>
                                            <Card sx={{ minWidth: 100, mr: 2 }} className="photo-size" onClick={() => handleOpenPreviewImages(file)}>
                                                <CardContent onClick={handleOpenPreviewImages}>
                                                    <img src={file} alt="Preview" className="form-img__img-preview" />
                                                </CardContent>
                                            </Card>
                                        )}
                                    </Tabs> : (
                                        img.map((file, index) =>
                                            <Card sx={{ minWidth: 100, mr: 2 }} className="photo-size">
                                                <CardContent onClick={handleOpenPreviewImages}>
                                                    <img src={file} alt="Preview" className="form-img__img-preview" />
                                                </CardContent>
                                            </Card>
                                        )
                                    )
                                    }
                                </Box>
                            </div>
                            <div>
                                Event Conducted :3
                                <Box
                                    sx={{
                                        flexGrow: 1,
                                        minWidth: { xs: 300, sm: 300 },
                                    }}
                                >
                                    {img.length > 1 ? <Tabs
                                        variant="scrollable"
                                        scrollButtons
                                        aria-label="visible arrows tabs example"
                                        sx={{
                                            [`& .${tabsClasses.scrollButtons}`]: {
                                                '&.Mui-disabled': { opacity: 0.3 },
                                            },
                                        }}
                                    >
                                        {img.map((file, index) =>
                                            <Card sx={{ minWidth: 100, mr: 2 }} className="photo-size" >
                                                <CardContent onClick={handleOpenPreviewImages}>
                                                    <img src={file} alt="Preview" className="form-img__img-preview" />
                                                </CardContent>
                                            </Card>
                                        )}
                                    </Tabs> : (
                                        img.map((file, index) =>
                                            <Card sx={{ minWidth: 100, mr: 2 }} className="photo-size">
                                                <CardContent onClick={handleOpenPreviewImages}>
                                                    <img src={file} alt="Preview" className="form-img__img-preview" />
                                                </CardContent>
                                            </Card>
                                        )
                                    )
                                    }
                                </Box>
                            </div>
                        </div>
                    }
                    {onViewClickTitle === "Development Projects" && <span>Completion Status : {details?.status}</span>}
                    {onViewClickTitle === "Seva aur Samarpan Campaign" &&
                        <div>
                            <span >Event Images</span>
                            <Box
                                sx={{
                                    flexGrow: 1,
                                    minWidth: { xs: 300, sm: 300 },
                                }}
                            >
                                {files?.length > 1 ? <Tabs
                                    variant="scrollable"
                                    scrollButtons
                                    aria-label="visible arrows tabs example"
                                    sx={{
                                        [`& .${tabsClasses.scrollButtons}`]: {
                                            '&.Mui-disabled': { opacity: 0.3 },
                                        },
                                    }}
                                >
                                    {files?.map((file, index) =>
                                        <Card sx={{ minWidth: 100, mr: 2 }} className="photo-size">
                                            <CardContent>
                                                <div key={index}>{handlePreview(file)}</div>
                                            </CardContent>
                                        </Card>
                                    )}
                                </Tabs> : (
                                    files?.map((file, index) =>
                                        <Card sx={{ minWidth: 100, mr: 2 }} className="photo-size">
                                            <CardContent>
                                                <div key={index}>{handlePreview(file)}</div>
                                            </CardContent>
                                        </Card>
                                    )
                                )
                                }
                            </Box>
                            <Grid container>
                                <Grid item xs={6}>
                                    Start Date :  {Moment(details?.startDate).format('DD/MM/YYYY')}
                                </Grid>
                                <Grid item xs={6}>
                                    End Date :  {Moment(details?.endDate).format('DD/MM/YYYY')}
                                </Grid>
                            </Grid>
                            Location
                            <Grid container>
                                <Grid item xs={12}>
                                    {details?.location}
                                </Grid>
                            </Grid>
                        </div>
                    }
                </DialogContent>
                {onViewClickTitle === "Ongoing Seva Initiatives" ? null : <DialogActions>
                    {mpName && <Button variant='contained' autoFocus onClick={onEditClick} sx={{ backgroundColor: "#ef7335" }} >
                        Edit
                    </Button>}
                    <Button variant='outlined' autoFocus onClick={handleCloseInitiativeDetails} sx={{ mr: 8 }}>
                        Cancel
                    </Button>
                </DialogActions>}
                <AddMediaCoverage
                    openMediaCoverage={openMediaCoverage}
                    handleCloseMediaCoverage={handleCloseMediaCoverage}
                    isMediaCoverageEdit={isMediaCoverageEdit}
                    details={details}
                    handleCloseInitiativeDetails={handleCloseInitiativeDetails}
                />
                <AddDevelopmentProjects
                    openDevelopmentProjects={openDevelopmentProjects}
                    handleCloseDevelopmentProjects={handleCloseDevelopmentProjects}
                    isDevelopmentProjectsEdit={isDevelopmentProjectsEdit}
                    details={details}
                    handleCloseInitiativeDetails={handleCloseInitiativeDetails}
                />
                <CreateNewEvent
                    handleCloseCreateEvent={handleCloseCreateEvent}
                    openCreateEventDialog={openCreateEventDialog}
                    isSevaEventEdit={isSevaEventEdit}
                    details={details}
                    handleCloseInitiativeDetails={handleCloseInitiativeDetails}
                />
                <PreviewImagesDialog
                    openPreviewImages={openPreviewImages}
                    handleClosePreviewImages={handleClosePreviewImages}
                    images={img}
                />
            </BootstrapDialog>
        </div >
    );
}

export default InitiativeDetails;