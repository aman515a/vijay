import React, { useState, useRef } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import {
    Select,
    MenuItem,
    Button,
    TextField,
    Grid,
    Box,
    FormControl,
    InputLabel,
    Card,
    CardContent,
    Paper,
    IconButton
} from "@mui/material";
import { useForm } from "react-hook-form";
import Tabs, { tabsClasses } from '@mui/material/Tabs';
import UploadIcon from '@mui/icons-material/Upload';
import CloseIcon from "@mui/icons-material/Close";

const CreateInitiativeReportDialog = ({ handleClose, open }) => {
    const [images, setImages] = useState([]);
    const [value, setValue] = useState(0);

    const { register, handleSubmit, formState: { errors } } = useForm();

    const hiddenFileInput = useRef(null);

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    const onAddMediaCoverage = (data) => {
        console.log("data", data)
    }

    const handleImageChange = (e) => {
        const uploadedFiles = e.target.files;
        let newImages = [];
        for (let i = 0; i < uploadedFiles.length; i++) {
            const reader = new FileReader();
            reader.readAsDataURL(uploadedFiles[i]);
            reader.onload = () => {
                newImages.push({ url: reader.result });
                if (i === uploadedFiles.length - 1) {
                    setImages([...images, ...newImages]);
                }
            };
        }
    };
    const handleClick = event => {
        hiddenFileInput.current.click();
    };

    const types = [
        { id: 1, value: "One" },
        { id: 2, value: "two" },
        { id: 3, value: "three" },
        { id: 4, value: "four" }
    ]
    return (
        <>
            <Dialog open={open} onClose={handleClose}>
                <DialogTitle
                >
                    <Box sx={{ display: "flex", justifyContent: 'center', color: "#357092" }}>
                        <div>
                            <b>Create Intitiative Report For </b>
                            <b>Seva 01 - Seva aur Samarpan Campaign</b>
                        </div>
                        <CloseIcon
                            className="pageHeader"
                            onClick={handleClose}
                            style={{ cursor: "pointer", color: "#357092", justifyContent: "right" }}
                        />
                    </Box>
                </DialogTitle>
                <Grid container className="bg-white">
                    <Grid item xs={12} md={12}>
                        <Grid item xs={12} md={12} sx={{ p: 4 }}>
                            <Box>
                                <form>
                                    <Grid
                                        container
                                        spacing={1}
                                        justifyContent="left"
                                        alignItems="center"
                                    >
                                        <Grid container sx={{ mb: 2 }}>
                                            <Grid item xs={12} sx={{ pr: 1 }}>
                                                <TextField
                                                    className="stepperFormInput"
                                                    label="Participants"
                                                    name="participants"
                                                    fullWidth
                                                    placeholder="Participants"
                                                    size="small"
                                                    required
                                                    autoComplete="off"
                                                    {...register("participants", { required: true })}
                                                />
                                            </Grid>

                                        </Grid>
                                        <Grid container sx={{ mb: 2, mt: 1 }}>
                                            <Grid item xs={12} sx={{ pr: 1 }}>
                                                <TextField
                                                    className="stepperFormInput"
                                                    label="Initiative Description"
                                                    name="desc"
                                                    placeholder="Initiative Description"
                                                    fullWidth
                                                    required
                                                    multiline
                                                    rows={3}
                                                    size="small"
                                                    autoComplete="off"
                                                    {...register("desc", { required: true })}
                                                />
                                            </Grid>
                                        </Grid>
                                        <Grid container>
                                            {images.length > 0 ? <Grid item xs={6} sx={{ pr: 1 }}>
                                                <Box
                                                    sx={{
                                                        flexGrow: 1,
                                                        minWidth: { xs: 300, sm: 300 },
                                                    }}
                                                >
                                                    {images.length > 1 ? <Tabs
                                                        // value={value}
                                                        // onChange={handleChange}
                                                        variant="scrollable"
                                                        scrollButtons
                                                        aria-label="visible arrows tabs example"
                                                        sx={{
                                                            [`& .${tabsClasses.scrollButtons}`]: {
                                                                '&.Mui-disabled': { opacity: 0.3 },
                                                            },
                                                        }}
                                                    >
                                                        {images.map((image, index) =>
                                                            <Card sx={{ minWidth: 100, mr: 2 }} className="photo-size">
                                                                <CardContent>
                                                                    <img key={index} src={image.url} alt="" className="form-img__img-preview" />
                                                                </CardContent>
                                                            </Card>
                                                        )}
                                                    </Tabs> : (
                                                        images.map((image, index) =>
                                                            <Card sx={{ minWidth: 100, mr: 2 }} className="photo-size">
                                                                <CardContent>
                                                                    <img key={index} src={image.url} alt="" className="form-img__img-preview" />
                                                                </CardContent>
                                                            </Card>
                                                        )
                                                    )
                                                    }
                                                </Box>
                                                {/* <h6>Event Images</h6>
                                                <input type="file" ref={hiddenFileInput} style={{ display: 'none' }} multiple onChange={handleImageChange} />
                                                <div>
                                                    {images.map((image, index) => (
                                                        <img key={index} src={image.url} alt="" className="form-img__img-preview" />
                                                    ))}
                                                </div> */}
                                            </Grid> : null}
                                            <Grid item xs={6} sx={{ pr: 1, pl: 1 }}>
                                                <input type="file" ref={hiddenFileInput} style={{ display: 'none' }} multiple onChange={handleImageChange} />
                                                <Box
                                                    sx={{
                                                        display: 'flex',
                                                        '& > :not(style)': {
                                                            m: 1,
                                                            width: 128,
                                                            height: 128,
                                                        },
                                                    }}
                                                >
                                                    <Paper variant="outlined" square sx={{ mt: 3 }}>
                                                        <IconButton color="primary" aria-label="Upload" onClick={handleClick} sx={{ ml: 5, mt: 3 }}>
                                                            <UploadIcon />
                                                        </IconButton><br />
                                                        {images.length > 0 ? "Add More Images" : "Add Images"}
                                                    </Paper>
                                                </Box>
                                            </Grid>
                                        </Grid>
                                    </Grid>
                                </form>
                            </Box>
                        </Grid>
                        <React.Fragment>
                            <Box sx={{ display: "flex", flexDirection: "row", p: 2, pl: 30 }}>
                                <Button
                                    variant="contained"
                                    sx={{ p: 1, mr: 1, backgroundColor: "#ef7335" }}
                                    className="button-primary-alt-contained"
                                    onClick={handleSubmit(onAddMediaCoverage)}
                                >
                                    Submit
                                </Button>
                                <Button
                                    variant="outlined"
                                    onClick={handleClose}
                                    sx={{ p: 1, mr: 1 }}
                                    className="button-primary-alt-contained"
                                >
                                    Cancel
                                </Button>
                                <Box sx={{ flex: "1 1 auto" }} />
                            </Box>
                        </React.Fragment>
                    </Grid>
                </Grid>
            </Dialog>
        </>
    );
};

export default CreateInitiativeReportDialog;