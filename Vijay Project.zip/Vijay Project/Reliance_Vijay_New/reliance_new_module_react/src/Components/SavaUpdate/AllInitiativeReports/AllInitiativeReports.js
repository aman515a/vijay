import React, { useState } from 'react';
import Box from '@mui/material/Box';
import Tabs, { tabsClasses } from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import SideMenu from '../../SideMenu/SideMenu';
import first from "../../../asserts/images/1st.png";
import one from "../../../asserts/images/1.jpg"
import two from "../../../asserts/images/4.jpg";
import three from "../../../asserts/images/2.jpg";
import { Card, CardContent, TextField, Typography, Button } from '@mui/material';
import BorderColorIcon from '@mui/icons-material/BorderColor';
import CreateInitiativeReportDialog from './createInitiativeReportDialog.js';
import InitiativeDetails from './initiativeDetails';
import { useLocation } from 'react-router';

const AllInitiativeReports = (props) => {
    const location=useLocation();
    const [value, setValue] = useState(0);
    const [open, setOpen] = useState(false);
    const [openInitiativeDetailsDialog, setOpenInitiativeDetailsDialog] = useState(false);
    const [personDetails, setPersonDetails] = useState();
    let user = location?.state?.user;
    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    const handleClickOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };

    const handleOpenInitiativeDetails = (item) => {
        setPersonDetails(item);
        setOpenInitiativeDetailsDialog(true);
    }
    const handleCloseInitiativeDetails = () => {
        setOpenInitiativeDetailsDialog(false);
    }


    const cardsData = [
        {
            name: "Shri Ramesh Bidhuri",
            designation: "President,BJP,Gujarat Pradesh",
            consitituency: "Navasari GUjarati",
            imageSrc: one,
        },
        {
            name: "Shri Bhupesh Baghel",
            designation: "Lok Sabha MP",
            consitituency: "Durg (Chhattisgarh)",
            imageSrc: two,
        }, {
            name: "Smt. Rama Bidhuri",
            designation: "Lok Sabha MP",
            consitituency: "Navasari (Gujarat)",
            imageSrc: three
        },
        {
            name: "Shri Ramesh Bidhuri",
            designation: "President,BJP,Gujarat Pradesh",
            consitituency: "Navasari GUjarati",
            imageSrc: one,
        },
        {
            name: "Shri Ramesh Bidhuri",
            designation: "President,BJP,Gujarat Pradesh",
            consitituency: "Navasari GUjarati",
            imageSrc: two,
        },
        {
            name: "Shri Ramesh Bidhuri",
            designation: "President,BJP,Gujarat Pradesh",
            consitituency: "Navasari GUjarati",
            imageSrc: one,
        },
        {
            name: "Shri Bhupesh Baghel",
            designation: "Lok Sabha MP",
            consitituency: "Durg (Chhattisgarh)",
            imageSrc: two,
        }, {
            name: "Smt. Rama Bidhuri",
            designation: "Lok Sabha MP",
            consitituency: "Navasari (Gujarat)",
            imageSrc: three
        }
    ]
    return (
        <div className="page-wrapper d-flex">
            <SideMenu active="Seva" user={user}/>

            <div className="main-wrapper center-width">

                <div >
                    <div className="middle-wrapper">
                        <div className="d-flex justify-content-between align-items-center mb-4">
                            <h1 className="page-title mb-0">Seva aur Samarpan Campaign</h1>
                            <div className="search-filter-icon d-flex">
                                {/* <TextField id="outlined-basic" label="Outlined" variant="outlined" sx={{ borderRadius: 50 }}>
                                </TextField> */}
                                <a className="d-block mr-1" href="">
                                    <svg className="searchIcon position-absolute" width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.58317 18.6253C4.87484 18.6253 1.0415 14.792 1.0415 10.0837C1.0415 5.37533 4.87484 1.54199 9.58317 1.54199C14.2915 1.54199 18.1248 5.37533 18.1248 10.0837C18.1248 14.792 14.2915 18.6253 9.58317 18.6253ZM9.58317 2.79199C5.55817 2.79199 2.2915 6.06699 2.2915 10.0837C2.2915 14.1003 5.55817 17.3753 9.58317 17.3753C13.6082 17.3753 16.8748 14.1003 16.8748 10.0837C16.8748 6.06699 13.6082 2.79199 9.58317 2.79199Z" fill="#5c819e" />
                                        <path d="M18.3335 19.4585C18.1752 19.4585 18.0169 19.4002 17.8919 19.2752L16.2252 17.6085C15.9835 17.3669 15.9835 16.9669 16.2252 16.7252C16.4669 16.4835 16.8669 16.4835 17.1085 16.7252L18.7752 18.3919C19.0169 18.6335 19.0169 19.0335 18.7752 19.2752C18.6502 19.4002 18.4919 19.4585 18.3335 19.4585Z" fill="#5c819e" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                        <div>
                            <h3 ><b>Initiative Reports By</b></h3>
                        </div>
                        {/* <hr className="mt-2 mb-4" /> */}
                        <div className="d-flex justify-content-between leaders-cards">
                            <Box
                                sx={{
                                    flexGrow: 1,
                                    minWidth: { xs: 920, sm: 1080 },
                                    // bgcolor: 'background.paper',
                                }}
                            >
                                <Tabs
                                    value={value}
                                    onChange={handleChange}
                                    variant="scrollable"
                                    scrollButtons
                                    aria-label="visible arrows tabs example"
                                    sx={{
                                        [`& .${tabsClasses.scrollButtons}`]: {
                                            '&.Mui-disabled': { opacity: 0.3 },
                                        },
                                    }}
                                >
                                    {cardsData.map(item =>
                                        <Card sx={{ minWidth: 200, mr: 2 }} className="card-size" onClick={() => handleOpenInitiativeDetails(item)}>
                                            <CardContent>
                                                {/* <img width="38.49" src={first} className="position-absolute" alt="" /> */}
                                                <div className="text-center pt-3"><img src={item['imageSrc']} className="img-circle leader-circle-img mr-1" width="70" /></div>
                                                <div className="card-content">
                                                    <h2>{item.name}</h2>
                                                    <span className="initial">{item.designation}</span><br />
                                                    <span className="constituency">Constituency:{item.consitituency}</span>
                                                </div>
                                            </CardContent>
                                        </Card>
                                    )}
                                </Tabs>
                            </Box>
                        </div>
                        <div className='mt-4'>
                            <h3 ><b>Events under this Initiative</b></h3>
                        </div>
                        <div className="d-flex justify-content-between leaders-cards">
                            <Box
                                sx={{
                                    flexGrow: 1,
                                    minWidth: { xs: 920, sm: 1080 },
                                    // bgcolor: 'background.paper',
                                }}
                            >
                                <Tabs
                                    value={value}
                                    onChange={handleChange}
                                    variant="scrollable"
                                    scrollButtons
                                    aria-label="visible arrows tabs example"
                                    sx={{
                                        [`& .${tabsClasses.scrollButtons}`]: {
                                            '&.Mui-disabled': { opacity: 0.3 },
                                        },
                                    }}
                                >
                                    {cardsData.map(item =>
                                        // <Tab label={item.name}>
                                        <Card sx={{ minWidth: 200, mr: 2 }} className="card-size">
                                            <CardContent>
                                                {/* <img width="38.49" src={first} className="position-absolute" alt="" /> */}
                                                <div className="text-center pt-3"><img src={one} className="img-circle leader-circle-img mr-1" width="70" /></div>
                                                <div className="card-content">
                                                    <h2>Shri Ramesh Bidhuri</h2>
                                                    <span className="initial">Lok Sabha MP</span><br />
                                                    <span className="constituency">Constituency : Navasari (Gujarat)</span>
                                                </div>
                                            </CardContent>
                                        </Card>
                                        // </Tab>
                                    )}
                                </Tabs>
                            </Box>
                        </div>
                        <Card sx={{ display: 'flex', ml: 5, mt: 3 }}>
                            <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                                <CardContent sx={{ flex: '1 0 auto' }}>
                                    <Typography component="div" variant="h5">
                                        Create a initiative report
                                    </Typography>
                                    <Typography variant="subtitle1" color="text.secondary" component="div">
                                        Have you taken part in this initiative? Add the details here
                                    </Typography>
                                    <Button variant="contained" endIcon={<BorderColorIcon />} sx={{ mt: 1 }} onClick={handleClickOpen}>
                                        Create New
                                    </Button>
                                </CardContent>
                            </Box>
                        </Card>
                    </div>
                    <CreateInitiativeReportDialog
                        open={open}
                        handleClose={handleClose}
                    />
                    <InitiativeDetails
                        handleCloseInitiativeDetails={handleCloseInitiativeDetails}
                        openInitiativeDetailsDialog={openInitiativeDetailsDialog}
                        details={personDetails}
                    />
                </div>
            </div>
        </div>
    );
}
export default AllInitiativeReports;