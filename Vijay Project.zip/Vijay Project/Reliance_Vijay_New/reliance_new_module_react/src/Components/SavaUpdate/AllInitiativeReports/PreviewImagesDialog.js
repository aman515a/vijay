import React, { useState, useRef, useEffect } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import CloseIcon from "@mui/icons-material/Close";
import {
    Select,
    MenuItem,
    Button,
    TextField,
    Grid,
    Box,
    FormControl,
    InputLabel,
    FormHelperText,
    Card,
    CardContent,
    IconButton,
    Paper,
    CardMedia
} from "@mui/material";
import { useForm } from "react-hook-form";
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import Tabs, { tabsClasses } from '@mui/material/Tabs';
import UploadIcon from '@mui/icons-material/Upload';
import CancelIcon from '@mui/icons-material/Cancel';
import { useDispatch, useSelector } from 'react-redux';
import { getDevelopmentCompletionStatusList } from "../../../store/action/developmentProjectList";
import { postCreateDevelopmentProject } from "../../../store/action/createDevelopmentProject";
import Moment from 'moment';
import { getDevelopmentProjectsList } from "../../../store/action/developmentProjectList";
import { useLoading } from "../../../utils/LoadingContext";
import { useNotificationContext } from "../../../utils/NotificationContext";

const PreviewImagesDialog = ({ openPreviewImages, handleClosePreviewImages, images }) => {
    const [selectedImageIndex, setSelectedImageIndex] = useState(0);
    const [onShowImage, setOnShowImage] = useState(false);

    const handleImageClick = (index) => {
        setSelectedImageIndex(index);
        setOnShowImage(true);
    };

    return (
        <>
            <Dialog open={openPreviewImages} onClose={handleClosePreviewImages}>

                <Tabs
                    // value={value}
                    // onChange={handleChange}
                    variant="scrollable"
                    scrollButtons
                    aria-label="visible arrows tabs example"
                    sx={{
                        [`& .${tabsClasses.scrollButtons}`]: {
                            '&.Mui-disabled': { opacity: 0.3 },
                        },
                        mt: 2,
                        maxWidth: 400,
                        ml: 20
                    }}
                    onClick={() => setOnShowImage(false)}
                >
                    {images?.map((img, index) =>
                        <Card sx={{ minWidth: 320, mr: 1, mb: 3 }} >
                            <div style={{ position: "relative" }}>
                                <CardMedia
                                    sx={{
                                        filter: "brightness(50%)"
                                    }}
                                    component="img"
                                    height="300"
                                    // width="700"
                                    minWidth="500"
                                    // image={onShowImage && selectedImageIndex === index ? images[selectedImageIndex] : img}
                                    image={onShowImage ? images[selectedImageIndex] : img}
                                    // image={data.image} 
                                    alt="new Image"
                                    className='blackoverlay'
                                />
                            </div>
                        </Card>
                    )}
                </Tabs>
                <Tabs
                    // value={value}
                    // onChange={handleChange}
                    variant="scrollable"
                    scrollButtons
                    aria-label="visible arrows tabs example"
                    sx={{
                        // [`& .${tabsClasses.scrollButtons}`]: {
                        //     '&.Mui-disabled': { opacity: 0.3 },
                        // },
                        mt: 4,
                    }}
                >
                    {images?.map((img, index) =>
                        <Card sx={{ minWidth: 150, mr: 3, mb: 3 }} >
                            <div style={{ position: "relative" }}>
                                <CardMedia
                                    sx={{
                                        filter: "brightness(50%)"
                                    }}
                                    component="img"
                                    height="100"
                                    // width=""
                                    image={img}
                                    onClick={() => handleImageClick(index)}
                                    // image={data.image}
                                    alt="new Image"
                                    className='blackoverlay'
                                />
                            </div>
                        </Card>
                    )}
                </Tabs>
            </Dialog>
        </>
    );
};

export default PreviewImagesDialog;