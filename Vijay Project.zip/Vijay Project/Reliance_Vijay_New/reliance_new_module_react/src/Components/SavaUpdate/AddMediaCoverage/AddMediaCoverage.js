import React, { useState, useRef, useEffect } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import {
    Select,
    MenuItem,
    Button,
    TextField,
    Grid,
    Box,
    FormControl,
    InputLabel,
    Card,
    CardContent,
    Paper,
    IconButton,
    FormHelperText
} from "@mui/material";
import { useForm } from "react-hook-form";
import Tabs, { tabsClasses } from '@mui/material/Tabs';
import "./AddMediaCoverage.css";
import UploadIcon from '@mui/icons-material/Upload';
import { useDispatch, useSelector } from 'react-redux';
import { getMediaCoverageTypesList } from "../../../store/action/mediaCoverageList";
import { postCreateOpeds } from "../../../store/action/createNewOpeds";
import { useLoading } from "../../../utils/LoadingContext";
import { useNotificationContext } from "../../../utils/NotificationContext";
import { getMediaCoverageList } from "../../../store/action/mediaCoverageList";

const AddMediaCoverage = ({ handleCloseMediaCoverage, openMediaCoverage, isMediaCoverageEdit, details, handleCloseInitiativeDetails }) => {
    const [images, setImages] = useState([]);
    const [value, setValue] = useState(0);
    const [files, setFiles] = useState([]);
    const dispatch = useDispatch();
    const { setLoading } = useLoading();
    const { showNotification } = useNotificationContext();
    const mediaCoverageTypesList = useSelector((state) => state?.mediaCoverageTypesList?.data);
    const { register, handleSubmit, formState: { errors }, resetField } = useForm();
    const hiddenFileInput = useRef(null);
    console.log("error", errors)
    // const handleChange = (event, newValue) => {
    //     setValue(newValue);
    // };
    console.log("details", details)

    useEffect(() => {
        if (details) {
            setImages(details?.media && JSON.parse(details?.media))
        }
    }, [details])

    const onAddMediaCoverage = async (data) => {
        const formData = new FormData();
        formData.append("title", data?.projectTitle);
        formData.append("url", data?.url);
        formData.append("type", data?.type);
        formData.append("mpmodelId", 1)
        formData.append("desc", data?.desc)
        console.log("files", files)
        Array.from(files).forEach(file => formData.append(`media`, file, file.name));
        const config = {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        }
        const id = details?.userId ? details?.userId : 0;
        try {
            setLoading(true);
            if (files.length === 0) {
                showNotification("Error", "Please add image");
                return;
            }
            const response = await dispatch(postCreateOpeds(id, formData, config));
            if (response.status === 200 || response.status === 201) {
                showNotification("Success", response.data.message, 'success');
                handleCloseMediaCoverage();
                dispatch(getMediaCoverageList());
                if (details) {
                    handleCloseInitiativeDetails();
                }
                Object.keys(data).map(val => resetField(val));
                setImages([]);
                setFiles([]);
            }
        } catch (error) {
            console.log("err", error);
            showNotification("Error", "Failed to fetch");
        }
        finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        //call api to update store
        dispatch(getMediaCoverageTypesList());
    }, [])

    const handleDelete = (index) => {
        const tempImages = [...images]
        tempImages.splice(index, 1)
        setImages(tempImages)
    }

    const handleImageChange = (e) => {
        const uploadedFiles = e.target.files;
        setFiles([...files, ...uploadedFiles]);
        let newFiles = [];
        for (let i = 0; i < uploadedFiles.length; i++) {
            const reader = new FileReader();
            reader.readAsDataURL(uploadedFiles[i]);
            reader.onload = () => {
                if (uploadedFiles[i].type.startsWith("image")) {
                    newFiles.push({ type: "image", url: reader.result, file: uploadedFiles[i] });
                } else if (uploadedFiles[i].type.startsWith("video")) {
                    newFiles.push({ type: "video", url: reader.result, file: uploadedFiles[i] });
                }
                if (i === uploadedFiles.length - 1) {
                    setImages([...images, ...newFiles]);
                }
            };
        }
    };

    // const handleImageChange = (e) => {
    //     const uploadedFiles = e.target.files;
    //     setFiles([...files, ...uploadedFiles]);
    //     let newImages = [];
    //     for (let i = 0; i < uploadedFiles.length; i++) {
    //         const reader = new FileReader();
    //         reader.readAsDataURL(uploadedFiles[i]);
    //         reader.onload = () => {
    //             newImages.push({ url: reader.result, file: uploadedFiles[i] });
    //             if (i === uploadedFiles.length - 1) {
    //                 setImages([...images, ...newImages]);
    //             }
    //         };
    //     }
    // };

    const handlePreview = (file) => {
        if (file.type === "image" || details) {
            return <img src={typeof file === 'string' ? file : file.url} alt="Preview" className="form-img__img-preview" />;
        } else if (file.type === "video" || details) {
            return (
                <video controls className="form-img__img-preview">
                    <source src={typeof file === 'string' ? file : file.url} />
                    Your browser does not support the video tag.
                </video>
            );
        }
    };

    const handleClick = event => {
        hiddenFileInput.current.click();
    };

    return (
        <>
            <Dialog open={openMediaCoverage} onClose={handleCloseMediaCoverage}>
                <DialogTitle
                >
                    <Box sx={{ display: "flex", justifyContent: 'center', color: "#357092", fontFamily: 'HK Grotesk', fontSize: "26px", fontWeight: 'bold' }}>
                        <div>
                            <b>Op-Ed's, Books & Media Coverage</b>
                        </div>
                        {/* <CloseIcon
                            className="pageHeader"
                            onClick={handleCloseMediaCoverage}
                            style={{ cursor: "pointer", color: "#357092",justifyContent:"righ" }}
                        /> */}
                    </Box>
                </DialogTitle>
                <Grid container className="bg-white">
                    <Grid item xs={12} md={12}>
                        <Grid item xs={12} md={12} sx={{ p: 4 }}>
                            <Box>
                                <form>
                                    <Grid
                                        container
                                        spacing={1}
                                        justifyContent="left"
                                        alignItems="center"
                                    >
                                        <Grid container sx={{ mb: 2 }}>
                                            <Grid item xs={12} sx={{ pr: 1 }}>
                                                <FormControl fullWidth>                                            <div style={{ fontFamily: 'HK Grotesk', color: "#357092", fontSize: "16px", fontWeight: 'bold' }}>
                                                    <b> Title</b>
                                                </div>
                                                    <TextField
                                                        className="stepperFormInput"
                                                        // label="Title"
                                                        name="title"
                                                        fullWidth
                                                        placeholder="Enter title"
                                                        size="small"
                                                        required
                                                        defaultValue={details && details?.title}
                                                        autoComplete="off"
                                                        {...register("projectTitle", { required: "Please enter title" })}
                                                    //   error={Boolean(errors?.employeeId?.message)}
                                                    //   helperText={errors?.employeeId?.message}
                                                    //   onChange={() => setIsUpdateButton(false)}
                                                    />
                                                </FormControl>
                                                <FormHelperText sx={{ color: "#d32f2f" }}>
                                                    {errors && errors?.projectTitle?.message}
                                                </FormHelperText>
                                            </Grid>

                                        </Grid>
                                        <Grid container sx={{ mb: 2 }}>
                                            <Grid item xs={12} >
                                                <div style={{ fontFamily: 'HK Grotesk', color: "#357092", fontSize: "16px", fontWeight: 'bold' }}>
                                                    <b> Type</b>
                                                </div>

                                                <FormControl fullWidth>
                                                    <InputLabel
                                                        id="demo-simple-select-label"
                                                        sx={{ marginTop: "-6px" }}
                                                    >
                                                        Type
                                                    </InputLabel>
                                                    <Select
                                                        className="stepperFormInput"
                                                        // label="Type"
                                                        name="type"
                                                        fullWidth
                                                        defaultValue={details?.type}
                                                        required
                                                        size="small"
                                                        autoComplete="off"
                                                        {...register("type", { required: "Please select type" })}
                                                    // error={errors?.roleId}
                                                    // helperText={errors?.roleId?.message}
                                                    // onChange={() => setIsUpdateButton(false)}
                                                    >
                                                        {mediaCoverageTypesList &&
                                                            mediaCoverageTypesList.map((s) => {
                                                                return (
                                                                    <MenuItem
                                                                        native
                                                                        key={s.type}
                                                                        sx={{ width: "100%" }}
                                                                        value={s.type}
                                                                        size="small"
                                                                    >
                                                                        {s.type}
                                                                    </MenuItem>
                                                                );
                                                            })}
                                                    </Select>
                                                    <FormHelperText sx={{ color: "#d32f2f" }}>
                                                        {errors && errors?.type?.message}
                                                    </FormHelperText>
                                                </FormControl>
                                            </Grid>
                                        </Grid>
                                        <Grid container>
                                            <div style={{ fontFamily: 'HK Grotesk', color: "#357092", fontSize: "16px", fontWeight: 'bold' }}>
                                                <b> Attach Media</b>
                                            </div>

                                            {images?.length > 0 ? <Grid item xs={6} sx={{ pr: 1 }}>
                                                <Box
                                                    sx={{
                                                        flexGrow: 1,
                                                        minWidth: { xs: 300, sm: 300 },
                                                    }}
                                                >
                                                    {images?.length > 1 ? <Tabs
                                                        // value={value}
                                                        // onChange={handleChange}
                                                        variant="scrollable"
                                                        scrollButtons
                                                        aria-label="visible arrows tabs example"
                                                        sx={{
                                                            [`& .${tabsClasses.scrollButtons}`]: {
                                                                '&.Mui-disabled': { opacity: 0.3 },
                                                            },
                                                        }}
                                                    >
                                                        {images?.map((file, index) =>
                                                            <Card sx={{ minWidth: 100, mr: 2 }} className="photo-size">
                                                                <CardContent>
                                                                    {/* <img width="38.49" src={first} className="position-absolute" alt="" /> */}
                                                                    <div key={index}>{handlePreview(file)}</div>
                                                                    {/* <img key={index} src={typeof image === 'string' ? image : image.url} alt="" className="form-img__img-preview" /> */}
                                                                    <Button onClick={() => handleDelete(index)}>delete</Button>
                                                                </CardContent>
                                                            </Card>
                                                        )}
                                                    </Tabs> : (
                                                        images?.map((file, index) =>
                                                            <Card sx={{ minWidth: 100, mr: 2 }} className="photo-size">
                                                                <CardContent>
                                                                    {/* <img width="38.49" src={first} className="position-absolute" alt="" /> */}
                                                                    <div key={index}>{handlePreview(file)}</div>
                                                                    {/* <img key={index} src={typeof image === 'string' ? image : image.url} alt="" className="form-img__img-preview" /> */}
                                                                    <Button onClick={() => handleDelete(index)}>delete</Button>
                                                                </CardContent>
                                                            </Card>
                                                        )
                                                    )
                                                    }
                                                </Box>
                                                {/* <h6>Event Images</h6>
                                                <input type="file" ref={hiddenFileInput} style={{ display: 'none' }} multiple onChange={handleImageChange} />
                                                <div>
                                                    {images.map((image, index) => (
                                                        <img key={index} src={image.url} alt="" className="form-img__img-preview" />
                                                    ))}
                                                </div> */}
                                            </Grid> : null}


                                        </Grid>
                                        <Grid item xs={6} sx={{}}>
                                            <input type="file" ref={hiddenFileInput} style={{ display: 'none' }} multiple onChange={handleImageChange} accept="image/*,video/*" />
                                            {/* <input type="file" ref={hiddenFileInput} style={{ display: 'none' }} multiple onChange={handleImageChange} /> */}
                                            <Box
                                                sx={{
                                                    display: 'flex',
                                                    // position: 'relative',
                                                    '& > :not(style)': {
                                                        ml: "-8px",
                                                        width: 150,
                                                        height: 140,
                                                        // position: "relative",
                                                        //  left: "-31%",
                                                        // top: "8%",
                                                        // marginTop: "32px",
                                                    },
                                                }}
                                            >
                                                <Paper variant="outlined" square sx={{}}>
                                                    <IconButton color="primary" aria-label="Upload" onClick={handleClick} sx={{ display: "flex", justifyContent: "center", position: "relative", top: "25%", margin: "0 auto" }}>
                                                        <UploadIcon />
                                                    </IconButton>

                                                    <b style={{ display: "flex", justifyContent: "center", position: "relative", top: "25%" }}> Add More Images</b>
                                                </Paper>

                                            </Box>
                                        </Grid>
                                        <Grid container sx={{ mb: 2, mt: 1 }}>
                                            <Grid item xs={12} sx={{ pr: 1 }}>
                                                <FormControl fullWidth>
                                                    <div style={{ fontFamily: 'HK Grotesk', color: "#357092", fontSize: "16px", fontWeight: 'bold' }}>
                                                        <b> Description</b>
                                                    </div>
                                                    <TextField
                                                        className="stepperFormInput"
                                                        // label="Description"
                                                        name="desc"
                                                        placeholder="Enter Description"
                                                        fullWidth
                                                        required
                                                        multiline
                                                        rows={4}
                                                        defaultValue={details && details.desc}
                                                        size="small"
                                                        autoComplete="off"
                                                        {...register("desc", { required: "Please enter description" })}
                                                    />
                                                </FormControl>
                                                <FormHelperText sx={{ color: "#d32f2f" }}>
                                                    {errors && errors?.desc?.message}
                                                </FormHelperText>
                                            </Grid>
                                        </Grid>
                                        <Grid container>
                                            <Grid item xs={12} sx={{ pr: 1 }}>
                                                <FormControl fullWidth>
                                                    <div style={{ fontFamily: 'HK Grotesk', color: "#357092", fontSize: "16px", fontWeight: 'bold' }}>
                                                        <b> Link</b>
                                                    </div>

                                                    <TextField
                                                        className="stepperFormInput"
                                                        // label="Link"
                                                        name="url"
                                                        // placeholder="Link"
                                                        fullWidth
                                                        required
                                                        defaultValue={details && details.url}
                                                        size="small"
                                                        autoComplete="off"
                                                        {...register("url", { required: "Please enter url" })}
                                                    />
                                                </FormControl>
                                                <FormHelperText sx={{ color: "#d32f2f" }}>
                                                    {errors && errors?.desc?.message}
                                                </FormHelperText>
                                            </Grid>
                                        </Grid>
                                    </Grid>
                                </form>
                            </Box>
                        </Grid>
                        <React.Fragment>
                            <Box sx={{ display: "flex", flexDirection: "row", p: 2, pl: 30 }}>
                                <Button
                                    variant="contained"
                                    sx={{ p: 1, mr: 1, backgroundColor: "#ef7335" }}
                                    className="button-tr-2"
                                    onClick={handleSubmit(onAddMediaCoverage)}
                                >
                                    {isMediaCoverageEdit ? "Update" : "Submit"}
                                </Button>
                                <Button
                                    variant="outlined"
                                    onClick={handleCloseMediaCoverage}
                                    sx={{ p: 1, mr: 1 }}
                                    className="button-tr-2-1 "
                                >
                                    Cancel
                                </Button>
                                <Box sx={{ flex: "1 1 auto" }} />
                            </Box>
                        </React.Fragment>
                    </Grid>
                </Grid>
            </Dialog>
        </>
    );
};

export default AddMediaCoverage;