import React, { useState, useRef, useEffect } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import CloseIcon from "@mui/icons-material/Close";
import {
    Select,
    MenuItem,
    Button,
    TextField,
    Grid,
    Box,
    FormControl,
    InputLabel,
    FormHelperText,
    Card,
    CardContent,
    IconButton,
    Paper
} from "@mui/material";
import { useForm } from "react-hook-form";
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import Tabs, { tabsClasses } from '@mui/material/Tabs';
import UploadIcon from '@mui/icons-material/Upload';
import CancelIcon from '@mui/icons-material/Cancel';
import { useDispatch, useSelector } from 'react-redux';
import { getDevelopmentCompletionStatusList } from "../../../store/action/developmentProjectList";
import { postCreateDevelopmentProject } from "../../../store/action/createDevelopmentProject";
import Moment from 'moment';
import { getDevelopmentProjectsList } from "../../../store/action/developmentProjectList";
import { useLoading } from "../../../utils/LoadingContext";
import { useNotificationContext } from "../../../utils/NotificationContext";

const AddDevelopmentProjects = ({ openDevelopmentProjects, handleCloseDevelopmentProjects, details, isDevelopmentProjectsEdit, handleCloseInitiativeDetails }) => {
    const { setLoading } = useLoading();
    const { showNotification } = useNotificationContext();
    const [targetDate, setTargetDate] = useState(null);
    const [files, setFiles] = useState([]);
    const [uploadFiles, setUploadFiles] = useState([]);
    const dispatch = useDispatch();
    const developmentStatusList = useSelector((state) => state?.developmentCompletionStatusList?.data);
    const hiddenFileInput = useRef(null);
    const { register, handleSubmit, formState: { errors }, resetField } = useForm();

    useEffect(() => {
        //call api to update store
        dispatch(getDevelopmentCompletionStatusList());
    }, [])

    useEffect(() => {
        if (details) {
            setFiles(details?.media && JSON.parse(details?.media));
            setTargetDate(details?.target);
        }
    }, [details])

    const handleImageChange = (e) => {
        console.log(uploadFiles)
        const uploadedFiles = e.target.files;
        setUploadFiles([...uploadFiles, ...uploadedFiles]);
        let newFiles = [];
        for (let i = 0; i < uploadedFiles.length; i++) {
            const reader = new FileReader();
            reader.readAsDataURL(uploadedFiles[i]);
            reader.onload = () => {
                if (uploadedFiles[i].type.startsWith("image")) {
                    newFiles.push({ type: "image", url: reader.result, file: uploadedFiles[i] });
                } else if (uploadedFiles[i].type.startsWith("video")) {
                    newFiles.push({ type: "video", url: reader.result, file: uploadedFiles[i] });
                }
                if (i === uploadedFiles.length - 1) {
                    setFiles([...files, ...newFiles]);
                }
            };
        }
    };

    const handleDelete = (index) => {
        const tempImages = [...files];
        tempImages.splice(index, 1);
        setFiles(tempImages);
    }

    const handlePreview = (file) => {
        if (file.type === "image" || details) {
            return <img src={typeof file === 'string' ? file : file.url} alt="Preview" className="form-img__img-preview" />;
        } else if (file.type === "video" || details) {
            return (
                <video controls className="form-img__img-preview">
                    <source src={typeof file === 'string' ? file : file.url} type="video/mp4" />
                    Your browser does not support the video tag.
                </video>
            );
        }
    };


    const handleClick = event => {
        hiddenFileInput.current.click();
    };

    const onAddDevelopmentProject = async (data) => {
        const formData = new FormData();
        formData.append("projecttitle", data?.projectTitle);
        formData.append("status", data?.status);
        formData.append("target", Moment(targetDate).format('YYYY-MM-DD'));
        formData.append("mpmodelId", 1);
        formData.append("desc", data?.desc);
        Array.from(uploadFiles).forEach((file, i) => formData.append(`media[${[i]}]`, file, file.name));
        const config = {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        }
        const id = details?.userId ? details?.userId : 0;
        try {
            setLoading(true);
            if (uploadFiles.length === 0) {
                showNotification("Error", "Please add image");
                return;
            }
            else {
                const response = await dispatch(postCreateDevelopmentProject(id, formData, config));
                if (response.status === 200 || response.status === 201) {
                    console.log("dsdsds")
                    showNotification("Success", response.data.message, 'success');
                    handleCloseDevelopmentProjects();
                    if (details) {
                        handleCloseInitiativeDetails();
                    }
                    dispatch(getDevelopmentProjectsList());
                    Object.keys(data).map(val => resetField(val));
                    setFiles([]);
                    setUploadFiles([]);
                }
            }
        } catch (error) {
            console.log("err", error);
            showNotification("Error", "Failed to fetch");
        }
        finally {
            setLoading(false);
        }
        // dispatch(postCreateDevelopmentProject(0, formData, config));
    }

    return (
        <>
            <Dialog open={openDevelopmentProjects} onClose={handleCloseDevelopmentProjects}>
                <DialogTitle
                // sx={{
                //     backgroundColor: "#003f93",
                //     color: "#ffffff",
                //     fontSize: "16px",
                // }}
                >
                    <Box sx={{ display: "flex", justifyContent: 'center', color: "#357092", fontFamily: 'HK Grotesk', fontSize: "26px", fontWeight: 'bold' }}>
                        <div>
                            <b>Development Project</b>
                        </div>
                        {/* <CloseIcon
                            className="pageHeader"
                            onClick={handleCloseDevelopmentProjects}
                            style={{ cursor: "pointer", color: "#357092",justifyContent:"righ" }}
                        /> */}
                    </Box>
                </DialogTitle>
                <Grid container className="bg-white">
                    <Grid item xs={12} md={12}>
                        <Grid item xs={12} md={12} sx={{ p: 4 }}>
                            <Box>
                                <form>
                                    <Grid
                                        container
                                        spacing={1}
                                        justifyContent="left"
                                        alignItems="center"
                                    >
                                        <Grid container sx={{ mb: 2 }}>
                                            <Grid item xs={12} sx={{ pr: 1 }}>
                                                <FormControl fullWidth>                                            <div style={{ fontFamily: 'HK Grotesk', color: "#357092", fontSize: "16px", fontWeight: 'bold' }}>
                                                    <b> Title</b>
                                                </div>

                                                    <TextField
                                                        className="stepperFormInput"
                                                        // label="Title"
                                                        name="title"
                                                        fullWidth
                                                        placeholder="Enter title"
                                                        size="small"
                                                        required
                                                        defaultValue={details && details?.projecttitle}
                                                        autoComplete="off"
                                                        {...register("projectTitle", { required: "Title is required" })}
                                                    //   error={Boolean(errors?.employeeId?.message)}
                                                    //   helperText={errors?.employeeId?.message}
                                                    //   onChange={() => setIsUpdateButton(false)}
                                                    />
                                                </FormControl>
                                                <FormHelperText sx={{ color: "#d32f2f" }}>
                                                    {errors && errors?.projectTitle?.message}
                                                </FormHelperText>
                                            </Grid>

                                        </Grid>
                                        <Grid container sx={{ mb: 2 }}>
                                            <Grid item xs={6} sx={{ pr: 1 }}>
                                                <div style={{ fontFamily: 'HK Grotesk', color: "#357092", fontSize: "16px", fontWeight: 'bold' }}>
                                                    <b> Target Date</b>
                                                </div>
                                                <LocalizationProvider dateAdapter={AdapterDayjs}>
                                                    <DatePicker
                                                        // label="Target Date"
                                                        value={targetDate}
                                                        onChange={(newValue) => {
                                                            setTargetDate(newValue);
                                                        }}
                                                        // defaultValue={details && details?.target}
                                                        renderInput={(params) => <TextField {...params} defaultValue={details && details?.target}
                                                            {...register("targetDate", { required: "Target date is required" })}
                                                            error={Boolean(errors?.targetDate?.message)}
                                                            helperText={errors?.targetDate?.message} />}
                                                    />
                                                </LocalizationProvider>
                                            </Grid>
                                            <Grid item xs={6} sm={6}>
                                                <div style={{ fontFamily: 'HK Grotesk', color: "#357092", fontSize: "16px", fontWeight: 'bold' }}>
                                                    <b> Completion Status</b>
                                                </div>

                                                <FormControl fullWidth>
                                                    <InputLabel
                                                        id="demo-simple-select-label"
                                                        sx={{ marginTop: "-6px" }}
                                                    >
                                                        Completion Status
                                                    </InputLabel>
                                                    <Select
                                                        className="stepperFormInput"
                                                        // label="Completion Status"
                                                        name="status"
                                                        fullWidth
                                                        required
                                                        defaultValue={details?.status}
                                                        size="small"
                                                        autoComplete="off"
                                                        {...register("status", { required: "Please select status" })}
                                                    // error={errors?.roleId}
                                                    // helperText={errors?.roleId?.message}
                                                    // onChange={() => setIsUpdateButton(false)}
                                                    >
                                                        {developmentStatusList &&
                                                            developmentStatusList.map((s) => {
                                                                return (
                                                                    <MenuItem
                                                                        native
                                                                        key={s.status}
                                                                        sx={{ width: "100%" }}
                                                                        value={s.status}
                                                                        size="small"
                                                                    >
                                                                        {s.status}
                                                                    </MenuItem>
                                                                );
                                                            })}
                                                    </Select>
                                                    <FormHelperText sx={{ color: "#d32f2f" }}>
                                                        {errors && errors?.status?.message}
                                                    </FormHelperText>
                                                </FormControl>
                                            </Grid>
                                        </Grid>
                                        <Grid container>
                                            <Grid item xs={12} sx={{ pr: 1 }}>
                                                <FormControl fullWidth>
                                                    <div style={{ fontFamily: 'HK Grotesk', color: "#357092", fontSize: "16px", fontWeight: 'bold' }}>
                                                        <b> About Project</b>
                                                    </div>
                                                    <TextField
                                                        className="stepperFormInput"
                                                        // label="About Project"
                                                        name="about"
                                                        placeholder="About Project"
                                                        fullWidth
                                                        required
                                                        multiline
                                                        rows={3}
                                                        size="small"
                                                        defaultValue={details && details?.desc}
                                                        autoComplete="off"
                                                        {...register("desc", { required: "Please enter description" })}
                                                    //   error={Boolean(errors?.mobileNumber)}
                                                    //   helperText={errors?.mobileNumber?.message}
                                                    //   onChange={() => setIsUpdateButton(false)}
                                                    />
                                                </FormControl>
                                                <FormHelperText sx={{ color: "#d32f2f" }}>
                                                    {errors && errors?.desc?.message}
                                                </FormHelperText>
                                            </Grid>
                                        </Grid>
                                        <Grid container sx={{ mt: 2 }}>
                                            <div style={{ fontFamily: 'HK Grotesk', color: "#357092", fontSize: "16px", fontWeight: 'bold' }}>
                                                <b> Attach Media</b>
                                            </div>

                                            {files?.length > 0 ? <Grid item xs={6} sx={{ pr: 1 }}>
                                                <Box
                                                    sx={{
                                                        flexGrow: 1,
                                                        minWidth: { xs: 300, sm: 300 },
                                                    }}
                                                >
                                                    {files?.length > 1 ? <Tabs
                                                        // value={value}
                                                        // onChange={handleChange}
                                                        variant="scrollable"
                                                        scrollButtons
                                                        aria-label="visible arrows tabs example"
                                                        sx={{
                                                            [`& .${tabsClasses.scrollButtons}`]: {
                                                                '&.Mui-disabled': { opacity: 0.3 },
                                                            },
                                                        }}
                                                    >
                                                        {files?.map((file, index) =>
                                                            <Card sx={{ minWidth: 100, mr: 2 }} className="photo-size">
                                                                <CardContent>
                                                                    {/* <img width="38.49" src={first} className="position-absolute" alt="" /> */}
                                                                    {/* <img key={index} src={image.url} alt="" className="form-img__img-preview" /> */}
                                                                    <div key={index}>{handlePreview(file)}</div>
                                                                    <Button onClick={() => handleDelete(index)}>delete</Button>
                                                                    {/* <IconButton
                                                                        className="card__icon" sx={{ position: "absolute", right: "5vh" }}
                                                                        onClick={() => handleRemove(file.id)}
                                                                    >
                                                                        <CancelIcon role="button"></CancelIcon>
                                                                    </IconButton> */}
                                                                </CardContent>
                                                            </Card>
                                                        )}
                                                    </Tabs> : (
                                                        files?.map((file, index) =>
                                                            <Card sx={{ minWidth: 100, mr: 2 }} className="photo-size">
                                                                <CardContent>
                                                                    {/* <img width="38.49" src={first} className="position-absolute" alt="" /> */}
                                                                    {/* <img key={index} src={image.url} alt="" className="form-img__img-preview" /> */}
                                                                    <div key={index}>{handlePreview(file)}</div>
                                                                    <Button onClick={() => handleDelete(index)}>delete</Button>
                                                                </CardContent>
                                                            </Card>
                                                        )
                                                    )
                                                    }
                                                </Box>
                                                {/* <h6>Event Images</h6>
                                                <input type="file" ref={hiddenFileInput} style={{ display: 'none' }} multiple onChange={handleImageChange} />
                                                <div>
                                                    {files.map((image, index) => (
                                                        <img key={index} src={image.url} alt="" className="form-img__img-preview" />
                                                    ))}
                                                </div> */}
                                            </Grid> : null}

                                        </Grid>
                                        <Grid item xs={6} sx={{ pr: 1, pl: 1 }}>
                                            <input type="file" ref={hiddenFileInput} style={{ display: 'none' }} multiple onChange={handleImageChange} accept="image/*,video/*" />
                                            <Box
                                                sx={{
                                                    display: 'flex',
                                                    '& > :not(style)': {
                                                        ml: "-8px",
                                                        width: 150,
                                                        height: 140,
                                                    },
                                                }}
                                            >
                                                <Paper variant="outlined" square >
                                                    <IconButton color="primary" aria-label="Upload" onClick={handleClick} sx={{ display: "flex", justifyContent: "center", position: "relative", top: "25%", margin: "0 auto" }}>
                                                        <UploadIcon />
                                                    </IconButton><br />
                                                    <b style={{ display: "flex", justifyContent: "center", position: "relative", top: "25%" }}> Add More Images</b>
                                                </Paper>
                                            </Box>
                                        </Grid>
                                        {/* <input type="file" ref={hiddenFileInput} onChange={handleVideoChange} multiple accept="video/*" />
                                        // <button onClick={handleClick}>Upload Videos</button> */}
                                        {/* {videos.map((video, index) => */}
                                        {/* <Card sx={{ minWidth: 100, mr: 2 }} className="photo-size"> */}
                                        {/* <CardContent> */}
                                        {/* <img width="38.49" src={first} className="position-absolute" alt="" /> */}
                                        {/* <video key={index} src={video.url} alt="" className="form-img__img-preview" /> */}
                                        {/* </CardContent> */}
                                        {/* </Card> */}
                                        {/* // )} */}
                                    </Grid>
                                </form>
                            </Box>
                        </Grid>
                        <React.Fragment>
                            <Box sx={{ display: "flex", flexDirection: "row", p: 2, pl: 30 }}>
                                <Button
                                    variant="contained"
                                    //   onClick={handleSubmit(onAddEditUserSubmit)}
                                    sx={{ p: 1, mr: 1, backgroundColor: "#ef7335" }}
                                    className="button-tr-2"
                                    onClick={handleSubmit(onAddDevelopmentProject)}
                                >
                                    {isDevelopmentProjectsEdit ? "Edit" : "Submit"}
                                </Button>
                                <Button
                                    variant="outlined"
                                    onClick={handleCloseDevelopmentProjects}
                                    sx={{ p: 1, mr: 1 }}
                                    className="button-tr-2-1 "
                                >
                                    Cancel
                                </Button>
                                <Box sx={{ flex: "1 1 auto" }} />
                            </Box>
                        </React.Fragment>
                    </Grid>
                </Grid>
            </Dialog>
        </>
    );
};

export default AddDevelopmentProjects;