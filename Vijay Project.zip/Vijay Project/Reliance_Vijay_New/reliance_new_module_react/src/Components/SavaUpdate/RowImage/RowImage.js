import { Card, CardContent, CardMedia, IconButton, Typography, Box } from '@mui/material';
import React, { useEffect, useState } from 'react';
import "./RowImage.css";
import CancelSharpIcon from '@mui/icons-material/CancelSharp';
import ShareIcon from '@mui/icons-material/Share';
import { useNavigate } from 'react-router';
import Tabs, { tabsClasses } from '@mui/material/Tabs';
import NoImageFound from "../../../asserts/images/noImageFound.jpg";

function RowImage({ title, data, updateData, user, isOngoingSevaClick, handleOpenInitiativeDetails, mpName, noImage, onSevaEvent, onMediaCoverage }) {

  const [personalDetails, setPersonalDetails] = useState()
  console.log("daaata", data);
  const navigate = useNavigate();
  // const handleClear=(e)=>{        
  //     updateData(e)
  //   }

  const handleShare = (e) => {
    alert("Details are shared from ", e)
  }
  const handleCardClick = (data) => {
    setPersonalDetails(data);
    !user ?
      navigate("/SevaUpdates/allInitiativeReports") :
      navigate("/SevaUpdates/allInitiativeReports", {
        state: {
          user: user
        }
      })
  }

  return (

    <div>

      {/* <h2 className='row__title'>{title}</h2> */}
      <div className="itemfixed3" >
        {/* {data.map((data) => (<> */}
        {/* <CardComponent class="row__poster" data={data} updateValue={updateDatas} /> */}
        {/* <div className="card-size" >
              <div className="card row-card-image" onClick={() => { handleCardClick(data) }}>

                <img src={data.image} className="card__image" alt="" />
                <IconButton
                  className="card__icon" sx={{ position: "absolute" }}
                  onClick={(e) => {
                    e.stopPropagation();
                    handleShare(data.heading)
                  }}
                >
                  <ShareIcon role="button" className='cinitiativeshare'></ShareIcon>
                </IconButton> */}

        {/* <IconButton
                  className="card__icon" sx={{ position: "absolute" }}
                  onClick={(e) => {
                    e.stopPropagation();
                    handleClear(data.id)
                  }}
                >
                  <CancelSharpIcon role="button"></CancelSharpIcon>

                </IconButton> */}

        {/* <div className='card__heading'>{data.heading}</div>
              </div>
            </div> */}
        {/* <img
        key={data.id}            
        className="row__poster row__posterLarge"
        src={`${data.image}`}
        alt={data.id}
      /> */}
        {/* </> */}
        {/* ))} */}
        <div>
          <Tabs
            // value={value}
            // onChange={handleChange}
            variant="scrollable"
            scrollButtons
            aria-label="visible arrows tabs example"
            sx={{
              [`& .${tabsClasses.scrollButtons}`]: {
                '&.Mui-disabled': { opacity: 0.3 },
              },
            }}
          >
            {data?.map((data, index) =>
              <Card sx={{ minWidth: 235, mr: 3, mb: 3 }} onClick={() => { isOngoingSevaClick ? (mpName ? handleOpenInitiativeDetails(data, title) : handleCardClick(data)) : handleOpenInitiativeDetails(data, title) }}>
                <div style={{ position: "relative" }}>
                  <CardMedia
                    sx={{
                      filter: "brightness(50%)"
                    }}
                    id={index}
                    component="img"
                    height="150"
                    width="190"
                    src={noImage ? data.image : (data?.media && JSON.parse(data?.media)[0])}
                    // image={data.image}
                    onError={e => 
                      e.target.src = NoImageFound}
                    alt="new Image"
                    className='blackoverlay'
                  />

                  <div style={{ position: "absolute", color: "white", top: 120, left: "50%", transform: "translateX(-50%)", }}> {noImage ? data.heading : (onSevaEvent ? data?.eventTitle : (onMediaCoverage ? data?.title : data?.projecttitle))}</div>
                </div>
              </Card>
            )}
          </Tabs>
        </div>
      </div>
    </div>


  )
}

export default RowImage