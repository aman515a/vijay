import React, { useEffect, useState } from "react";
import "./SevaUpdate.css";
import first from "../../asserts/images/1st.png";
import one from "../../asserts/images/1.jpg";
import second from "../../asserts/images/2nd.png";
import two from "../../asserts/images/4.jpg";
import third from "../../asserts/images/3rd.png";
import three from "../../asserts/images/2.jpg";
import SideMenu from "../SideMenu/SideMenu";
import TableHighlights from "../Highlights/TableHighlights";
import AddIcon from '@mui/icons-material/Add';
import RowImage from "./RowImage/RowImage";
import Tabs, { tabsClasses } from '@mui/material/Tabs';
import { Button, Card, CardContent, Grid, Box, Typography } from "@mui/material";
import { useLocation } from "react-router";
import AddMediaCoverage from "./AddMediaCoverage/AddMediaCoverage";
import AddDevelopmentProjects from "./AddDevelopmentProjects/AddDevelopmentProjects";
import AddSevaEvent from "./AddSevaEvent/AddSevaEvent";
import ProfileCard from "../ReusableComponents.js/ProfileCard";
import { mpListOld } from "../../Constants/mpListOld";
import { useNavigate } from 'react-router';
import ViewAllScreen from "./ViewAllScreen";
import { useDispatch, useSelector } from 'react-redux';
import { getEventsList } from '../../store/action/eventsList';
import { getMediaCoverageList } from '../../store/action/mediaCoverageList';
import { getDevelopmentProjectsList } from "../../store/action/developmentProjectList";
import InitiativeDetails from "./AllInitiativeReports/initiativeDetails";
// control image


const SevaUpdates = ({ mpName, user, readonly, mySeva, mpId }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const [showViewAll, setShowViewAll] = useState(false);
  let newUser = location?.state?.user;
  const dispatch = useDispatch();
  const eventsList = useSelector((state) => state?.eventsList?.data);
  const mediaCoverageList = useSelector((state) => state?.mediaCoverageList?.data);
  const developmentProjectsList = useSelector((state) => state?.developmentProjectsList?.data);
  useEffect(() => {
    //call api to update store
    dispatch(getEventsList(mpId));
    dispatch(getMediaCoverageList(mpId));
    dispatch(getDevelopmentProjectsList(mpId));
  }, [])

  const sevaData = [
    {
      id: 1,
      image: one,
      heading: "Seva Aur Samarpan Campaign",
      heading1: "Indian Political System",
      name: "Book",
      date: "12/12/2022",
      personName: "Shri C.R. Patil",
      designation: "President, BJP,Gujarat Pradesh",
      place: "Navsari (Gujarat)",
      desc: "As part of prime minister Modi's birthday , I offered my seva to the nation , by conducting 6 events across my consituency"
    },
    {
      id: 2,
      image: two,
      heading: "Atal Innovation Mission",
      heading1: "Indian Political System",
      name: "Book",
      date: "12/12/2022",
      personName: "Shri C.R. Patil",
      designation: "President, BJP,Gujarat Pradesh",
      place: "Navsari (Gujarat)",
      desc: "As part of prime minister Modi's birthday , I offered my seva to the nation , by conducting 6 events across my consituency"
    },
    {
      id: 3,
      image: three,
      heading: "Fit India Movement",
      heading1: "Indian Political System",
      name: "Book",
      date: "12/12/2022",
      personName: "Shri C.R. Patil",
      designation: "President, BJP,Gujarat Pradesh",
      place: "Navsari (Gujarat)",
      desc: "As part of prime minister Modi's birthday , I offered my seva to the nation , by conducting 6 events across my consituency"
    },
    {
      id: 4,
      image: three,
      heading: "Seva Aur Samarpan Campaign",
      heading1: "Indian Political System",
      name: "Book",
      date: "12/12/2022",
      personName: "Shri C.R. Patil",
      designation: "President, BJP,Gujarat Pradesh",
      place: "Navsari (Gujarat)",
      desc: "As part of prime minister Modi's birthday , I offered my seva to the nation , by conducting 6 events across my consituency"
    },
    {
      id: 5,
      image: three,
      heading: "Atal Innovation Mission",
      heading1: "Indian Political System",
      name: "Book",
      date: "12/12/2022",
      personName: "Shri C.R. Patil",
      designation: "President, BJP,Gujarat Pradesh",
      place: "Navsari (Gujarat)",
      desc: "As part of prime minister Modi's birthday , I offered my seva to the nation , by conducting 6 events across my consituency"
    },
    {
      id: 6,
      image: three,
      heading: "Fit India Movement",
      heading1: "Indian Political System",
      name: "Book",
      date: "12/12/2022",
      personName: "Shri C.R. Patil",
      designation: "President, BJP,Gujarat Pradesh",
      place: "Navsari (Gujarat)",
      desc: "As part of prime minister Modi's birthday , I offered my seva to the nation , by conducting 6 events across my consituency"
    },
    {
      id: 7,
      image: three,
      heading: "Seva Aur Samarpan Campaign",
      heading1: "Indian Political System",
      name: "Book",
      date: "12/12/2022",
      personName: "Shri C.R. Patil",
      designation: "President, BJP,Gujarat Pradesh",
      place: "Navsari (Gujarat)",
      desc: "As part of prime minister Modi's birthday , I offered my seva to the nation , by conducting 6 events across my consituency"
    },
    {
      id: 8,
      image: three,
      heading: "Atal Innovation Mission",
      heading1: "Indian Political System",
      name: "Book",
      date: "12/12/2022",
      personName: "Shri C.R. Patil",
      designation: "President, BJP,Gujarat Pradesh",
      place: "Navsari (Gujarat)",
      desc: "As part of prime minister Modi's birthday , I offered my seva to the nation , by conducting 6 events across my consituency"
    },
    {
      id: 9,
      image: three,
      heading: "Fit India Movement",
      heading1: "Indian Political System",
      name: "Book",
      date: "12/12/2022",
      personName: "Shri C.R. Patil",
      designation: "President, BJP,Gujarat Pradesh",
      place: "Navsari (Gujarat)",
      desc: "As part of prime minister Modi's birthday , I offered my seva to the nation , by conducting 6 events across my consituency"
    },
    {
      id: 10,
      image: three,
      heading: "Atal Innovation Mission",
      heading1: "Indian Political System",
      name: "Book",
      date: "12/12/2022",
      personName: "Shri C.R. Patil",
      designation: "President, BJP,Gujarat Pradesh",
      place: "Navsari (Gujarat)",
      desc: "As part of prime minister Modi's birthday , I offered my seva to the nation , by conducting 6 events across my consituency"
    },
    {
      id: 11,
      image: one,
      heading: "Fit India Movement",
      heading1: "Indian Political System",
      name: "Book",
      date: "12/12/2022",
      personName: "Shri C.R. Patil",
      designation: "President, BJP,Gujarat Pradesh",
      place: "Navsari (Gujarat)",
      desc: "As part of prime minister Modi's birthday , I offered my seva to the nation , by conducting 6 events across my consituency"
    },
  ];

  const headerTabsData = [
    {
      id: 1, value: "MP Seva Score", imageSrc: first
    },
    { id: 2, value: "Initiatives", imageSrc: first },
    { id: 3, value: "Members Added", imageSrc: third },
    { id: 4, value: "Followers", imageSrc: first },
    { id: 5, value: "Twitter Performance", imageSrc: second },
    { id: 6, value: "Op-Eds & Media Coverage", imageSrc: third },
    { id: 7, value: "Donations", imageSrc: second },
  ]

  const [updateRowData, setUpdateRowData] = useState(sevaData);
  const [openMediaCoverage, setOpenMediaCoverage] = useState(false);
  const [openDevelopmentProjects, setOpenDevelopmentProjects] = useState(false);
  const [openSevaEvent, setOpenSevaEvent] = useState(false);
  const [onMySevaUpdateClick, setOnMySevaUpdateClick] = useState(false);
  const [openInitiativeDetailsDialog, setOpenInitiativeDetailsDialog] = useState(false);
  const [viewAllValue, setViewAllValue] = useState("");
  const [personDetails, setPersonDetails] = useState();
  const [onViewClick, setOnViewClick] = useState();
  const updateRow = (value) => {
    setUpdateRowData(updateRowData.filter((val) => val.id !== value));
  };
  const handleOpenMediaCoverage = () => {
    setOpenMediaCoverage(true);
  }
  const handleCloseMediaCoverage = () => {
    setOpenMediaCoverage(false);
  }

  const handleOpenDevelopmentProjects = () => {
    setOpenDevelopmentProjects(true);
  }
  const handleCloseDevelopmentProjects = () => {
    setOpenDevelopmentProjects(false);
  }

  const handleOpenSevaEvent = () => {
    setOpenSevaEvent(true);
  }
  const handleCloseSevaEvent = () => {
    setOpenSevaEvent(false);
  }

  const handleMySevaUpdateClick = (e) => {
    e.stopPropagation();
    // setOnMySevaUpdateClick(true);
    // if (onMySevaUpdateClick) {
    if (mySeva)
      navigate("/SevaUpdates");
    else {
      navigate("/MySevaUpdates", {
        state: {
          MpName: "My Seva Update",
          user: user,
        },
      });
    }
    // }
  }

  const viewAllhandleClick = (value, data) => {
    // console.log("onclickkk")
    // setViewAllValue(value);
    setShowViewAll(true);
    navigate('/SevaUpdates/viewAllSevaEvents', {
      state: {
        viewAllValue: value,
        data
      },
    })
  }

  const handleCloseInitiativeDetails = () => {
    setOpenInitiativeDetailsDialog(false);
  }

  const handleOpenInitiativeDetails = (item, title) => {
    // console.log("item", item)
    setPersonDetails(item);
    setOnViewClick(title);
    setOpenInitiativeDetailsDialog(true);
  }

  return (
    <div className="page-wrapper d-flex">
      {/* component 1 */}

      {newUser ? <SideMenu active="Seva" user={newUser} /> :
        <SideMenu active="Seva" user={user} />}

      <div className="main-wrapper" style={{ width: "100%" }}>

        <Grid container >

          {/* <div className="row"> */}
          {/* <Grid md={12} lg={8} xl={8}> */}
          <Grid xs={12} md={8} lg={8} xl={8} >
            <div className="d-flex justify-content-between align-items-center">
              {mpName ? (
                <div>
                  <h1 className="page-title mb-0" style={{ fontSize: "28px", fontWeight: "bold", fontFamily: 'HK Grotesk', color: "#356F92" }}> {onMySevaUpdateClick ? "My Seva Update" : mpName + "'s Seva Updates"}</h1>
                  <Card sx={{ marginTop: "20px", borderRadius: "20px" }}>
                    <div style={{ display: "flex", alignItems: "center" }} >

                      <div style={{ fontSize: "20px", fontWeight: "bold", fontFamily: 'HK Grotesk', color: "#356F92", flex: "0 0 140px", backgroundColor: "#F8FDFF", padding: "40px" }} >
                        {mpName}
                      </div>
                      <div style={{ flex: 1, backgroundColor: "#fff" }} >
                        <Tabs
                          // value={value}
                          // onChange={handleChange}
                          variant="scrollable"
                          scrollButtons
                          aria-label="visible arrows tabs example"
                          sx={{
                            [`& .${tabsClasses.scrollButtons}`]: {
                              '&.Mui-disabled': { opacity: 0.3 },
                            },
                          }}
                        >
                          {headerTabsData.map((item, index) =>
                            <Card sx={{ borderRadius: 0 }} >
                              <CardContent>
                                <div style={{ display: "flex", justifyContent: "center", alignItems: "center", flexDirection: "column" }}>
                                  <img
                                    key={index}
                                    src={item.imageSrc}
                                    // className="img-circle leader-circle-img mr-1"
                                    width="40"

                                  />
                                  {/* <img width="38.49" src={first} className="position-absolute" alt="" /> */}
                                  {/* <img key={index} src={image.url} alt="" className="form-img__img-preview" /> */}
                                  <div style={{ fontSize: "16px", fontWeight: "bold", fontFamily: 'HK Grotesk', color: "#2C2C2C", marginTop: "20px" }} key={index}>{item.value}</div>
                                </div>
                                {/* <IconButton
                                  className="card__icon" sx={{ position: "absolute", right: "5vh" }}
                                  onClick={() => handleRemove(file.id)}
                              >
                                  <CancelIcon role="button"></CancelIcon>
                              </IconButton> */}
                              </CardContent>
                            </Card>
                          )}
                        </Tabs>

                      </div>
                    </div>
                  </Card>
                </div>
              ) : (
                <h1 className="page-title mb-0" style={{ fontSize: "26px", fontWeight: "bold", fontFamily: 'HK Grotesk' }}>Nationwide Seva Updates</h1>
              )}
            </div>

            <hr className="mt-2 mb-4" />
            <Grid container>

              <Typography sx={{ fontSize: "20px", fontWeight: "bold", fontFamily: 'HK Grotesk', color: "#2C2C2C" }}>  Ongoing Seva Initiatives</Typography>
            </Grid>
            <div style={{ marginTop: "10px", marginBottom: "10px" }}>
              <RowImage
                title="Ongoing Seva Initiatives"
                data={updateRowData}
                updateData={updateRow}
                user={user ? user : newUser}
                isOngoingSevaClick={true}
                mpName={mpName}
                handleOpenInitiativeDetails={handleOpenInitiativeDetails}
                noImage={true}
              />


            </div>

            <Grid container>
              <Grid item xs={7}>
                <Typography sx={{ fontSize: "20px", fontWeight: "bold", fontFamily: 'HK Grotesk', color: "#2C2C2C" }}>Seva Events</Typography>

              </Grid>
              <div style={{ display: "flex", gap: "10px" }}>
                <Button className="button-tr-citizen" startIcon={<AddIcon sx={{ fontSize: "20", marginTop: "4px" }} />} onClick={() => handleOpenSevaEvent()} sx={{ mr: 1 }}>
                  Add New
                </Button>
                <Button className="button-tr-citizen" onClick={() => viewAllhandleClick("Seva Events", eventsList)}>
                  View All
                </Button>
              </div>
            </Grid>
            <div style={{ marginTop: "10px", marginBottom: "10px" }}>
              <RowImage title="Seva aur Samarpan Campaign" data={eventsList} user={user ? user : newUser} onSevaEvent={true}
                handleOpenInitiativeDetails={handleOpenInitiativeDetails}
              // noImage={true}
              />
            </div>
            <Grid container >
              <Grid item xs={7}>

                <Typography sx={{ fontSize: "20px", fontWeight: "bold", fontFamily: 'HK Grotesk', color: "#2C2C2C" }}>  OP-Ed's, Books & Media Coverage</Typography>
              </Grid>

              <div style={{ display: "flex", gap: "10px" }}>
                <Button className="button-tr-citizen" startIcon={<AddIcon sx={{ fontSize: "20", marginTop: "4px" }} />} onClick={() => handleOpenMediaCoverage()} sx={{ mr: 1 }}>
                  Add New
                </Button>
                <Button className="button-tr-citizen" onClick={() => viewAllhandleClick("OP-Ed's, Books & Media Coverage", mediaCoverageList)}>
                  View All
                </Button>
              </div>

            </Grid>
            <div style={{ marginTop: "10px", marginBottom: "10px" }}>
              <RowImage title="OP-Ed's, Books & Media Coverage of" data={mediaCoverageList} user={user ? user : newUser} onMediaCoverage={true}
                handleOpenInitiativeDetails={handleOpenInitiativeDetails}
              // noImage={true}
              />
            </div>
            <Grid container>
              <Grid item xs={7}>

                <Typography sx={{ fontSize: "20px", fontWeight: "bold", fontFamily: 'HK Grotesk', color: "#2C2C2C" }}>Development Projects</Typography>
              </Grid>

              <div style={{ display: "flex", gap: "10px" }}>
                <Button className="button-tr-citizen" startIcon={<AddIcon sx={{ fontSize: "20", marginTop: "4px" }} />} onClick={() => handleOpenDevelopmentProjects()} sx={{ mr: 1 }}>
                  Add New
                </Button>
                <Button className="button-tr-citizen" onClick={() => viewAllhandleClick("Development Projects", developmentProjectsList)}>
                  View All
                </Button>
              </div>

            </Grid>
            <div style={{ marginTop: "10px", marginBottom: "10px" }}>
              <RowImage title="Development Projects"
                data={developmentProjectsList}
                user={user ? user : newUser}
                isOngoingSevaClick={false}
                developmentProject={true}
                handleOpenInitiativeDetails={handleOpenInitiativeDetails}
              // noImage={true}
              />
            </div>
          </Grid>
          {/* <Grid md={12} lg={4} xl={4}> */}
          <Grid xs={12} md={4} lg={4} xl={4} sx={mpName && { mt: "20%" }}>
            <div className="right-card mb-3">

              {/* {mpName ? (
                  <div className="card-body position-relative">
                    <img
                      src={one}
                      className="img-circle leader-circle-img mr-1"
                      width="80"
                    />
                  </div>
                ) : (newUser !== "Admin" &&
                  <ProfileCard profile={mpListOld[0]} />
                )} */}
              {!mpName && (<ProfileCard profile={mpListOld[0]} />
              )}
              {mpName && (
                <>
                  <div className="highlights-title" style={{ height: "84px" }}>
                    <h1 style={{ marginTop: "10px", fontWeight: "800" }}>
                      Highlights
                    </h1>
                  </div>
                  <TableHighlights mpId={1} />{" "}
                </>
              )}
              {!newUser && <Button
                class="btn btn-primary primary-btn sevaUpdate-button"

                onClick={(e) => handleMySevaUpdateClick(e)}
              >
                {" "}
                {mySeva ? "NATIONAL SEVA UPDATE" : "MY SEVA UPDATE"}{" "}
              </Button>}
              {!mpName && (
                <h1>

                  <b>Twitter Highlights</b>
                </h1>
              )}
            </div>
            <AddMediaCoverage
              openMediaCoverage={openMediaCoverage}
              handleCloseMediaCoverage={handleCloseMediaCoverage}
            />
            <AddDevelopmentProjects
              openDevelopmentProjects={openDevelopmentProjects}
              handleCloseDevelopmentProjects={handleCloseDevelopmentProjects}
            />
            <AddSevaEvent
              openSevaEvent={openSevaEvent}
              handleCloseSevaEvent={handleCloseSevaEvent}
            />
            {showViewAll && <ViewAllScreen
              user={user}
              newUser={newUser}
            />}
            <InitiativeDetails
              handleCloseInitiativeDetails={handleCloseInitiativeDetails}
              openInitiativeDetailsDialog={openInitiativeDetailsDialog}
              details={personDetails}
              onViewClickTitle={onViewClick}
              mpName={mpName}
            />
          </Grid >
          {/* </div> */}
        </Grid >
      </div >
    </div >
  );
};

export default SevaUpdates;
