import React from 'react';
import SideMenu from '../SideMenu/SideMenu.js';

const TwitterHighlights = () => {

    return (
        <div>
            {/* Leadership */}
        </div>
    )
}

export default TwitterHighlights;