import { Button } from '@mui/material';
import React from 'react';
import cardImg from "../../asserts/images/leader-highlight.png";
import leaderboard from "../../asserts/images/leaderboard-icon.png";

const CardHighlights = (props) => {
    let data={
        Name: "Smt. Poonam Mahajan",
        Designation:"MP-Lok Shabha",
        Location:"Mumbai North-Central Maharastra",

    }

    return (
        <div className="right-card">
                        <div className=""><img width="100%" src={cardImg} alt=""/></div>

                        <div className="d-flex justify-content-between mt-3">
                            
                                <Button sx={{ textTransform: "unset", textAlign:"-webkit-left",   color: "white",    font: "inherit"}}>
                                 
                                    <div className="small-cards small-card1">
                                    <p className="mb-0"><img className="mr-3" src={leaderboard} width="21.77" height="16.79" alt=""/></p>
                                <div className="d-flex justify-content-between mt-3">
                                    <p className="mb-0" style={{height: "36px",width: "105px"}}>Add members to NaMo App</p>
                                    <svg className="align-bottom" width="20" height="20" style={{alignSelf:"end"}} viewBox="0 0 21 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12.9333 1.11796C12.4104 0.595037 11.5934 0.595037 11.0705 1.11796C10.5475 1.64089 10.5475 2.45789 11.0705 2.98082L16.2667 8.17683H2.05106C1.33211 8.17683 0.743988 8.76495 0.743988 9.4839C0.743988 10.2029 1.33211 10.791 2.05106 10.791H16.2994L11.0708 15.9872C10.5478 16.5101 10.5478 17.3271 11.0708 17.8501C11.3322 18.1115 11.6589 18.2422 11.9858 18.2422C12.3127 18.2422 12.6393 18.1115 12.9008 17.8501L20.3518 10.3991C20.8747 9.87618 20.8747 9.05918 20.3518 8.53625L12.9333 1.11796Z" fill="white"/>
                                    </svg>
                                </div>
                                </div>
                                </Button>
                                
                                <Button sx={{ textTransform: "unset", textAlign:"-webkit-left",   color: "white",    font: "inherit"}}>
                                 
                            <div className="small-cards small-card2">
                                <p className="mb-0"><img className="mr-3" src={leaderboard} width="15" alt=""/></p>
                                <div className="d-flex justify-content-between mt-3">
                                    <p className="mb-0" style={{height: "36px",width: "65px"}}>Invite Donations</p>
                                    <svg className="align-text-bottom" width="24" height="21.44" style={{alignSelf:"end"}} viewBox="0 0 21 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12.9333 1.11796C12.4104 0.595037 11.5934 0.595037 11.0705 1.11796C10.5475 1.64089 10.5475 2.45789 11.0705 2.98082L16.2667 8.17683H2.05106C1.33211 8.17683 0.743988 8.76495 0.743988 9.4839C0.743988 10.2029 1.33211 10.791 2.05106 10.791H16.2994L11.0708 15.9872C10.5478 16.5101 10.5478 17.3271 11.0708 17.8501C11.3322 18.1115 11.6589 18.2422 11.9858 18.2422C12.3127 18.2422 12.6393 18.1115 12.9008 17.8501L20.3518 10.3991C20.8747 9.87618 20.8747 9.05918 20.3518 8.53625L12.9333 1.11796Z" fill="white"/>
                                    </svg>
                                </div>
                            </div>
                            </Button>
                        </div>
                    </div>
    )
}

export default CardHighlights;