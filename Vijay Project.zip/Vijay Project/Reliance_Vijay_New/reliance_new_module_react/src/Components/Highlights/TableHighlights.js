import { CircularProgress } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getAllHighlights } from "../../store/action/globalHighlights.js";
import SideMenu from "../SideMenu/SideMenu.js";
import "./Highlights.css";
const TableHighlights = (props) => {
  const dispatch = useDispatch();
  const { data, loading } = useSelector((state) => state?.highlights);
  function createData(heading, value) {
    return { heading, value };
  }
  
  const keys={
    InitiativesUndertaken:"Initiatives Undertaken",
    EventsConducted:"Events Conducted",
    memberadded:"Members Added",
    twtterfollowers:"Twitter Followers",
    twittermention:"Twitter Mentions",
    twttertweet:"Twitter Retweets",
    DevelopmentProjects:"Development Projects",
    DonationReceived:"Donation Received",
    MediaCoverage:"Media Coverage",
    Op_Eds:"Op-Eds",
    BookPublished:"Book Published"}

  


  useEffect(() => {
    props.mpId>0 ? dispatch(getAllHighlights(props.mpId)):
    dispatch(getAllHighlights())
    console.log(data);
  }, []);
  const rows = Object.keys(data ? data : [])?.map((val) => {
    return createData(val, data[val]);
  });

  return (
    <div className="mt-3" style={{ textAlign: "center" }}>
      {loading ? (
        <CircularProgress />
      ) : (
        rows.map((row) => {
          return (
            <div className="d-flex justify-content-between border-bottom py-3">
              <span style={{ fontWeight: "600" }}>{keys[row.heading]}</span>
              <span className="seva-nos" style={{ fontWeight: "bold" }}>
                {row.value.toLocaleString("en-US")}
              </span>
            </div>
          );
        })
      )}
    </div>
  );
};

export default TableHighlights;