import React from "react";
import SideMenu from "../SideMenu/SideMenu.js";
import "./Highlights.css";
const MpTableHighlights = (props) => {
  function createData(heading, value) {
    return { heading, value };
  }
  const sampleInitiatives = {
    "Initiatives Undertaken": "4,365",
    "Events Conducted": "21,495",
    "Members Added": "4.8 M",
    "Development Projects": "1800",
    "Donation Received": "1.3 B",
    "Media Coverage": "78,780",
    "Op-Eds": "65,430",
    "Book Published": "12,138",
  };

  const rows = Object.keys(sampleInitiatives).map((val) => {
    return createData(val, sampleInitiatives[val]);
  });

  return (
    <div className="mt-3">
      {rows.map((row) => {
        return (
          <div className="d-flex justify-content-between border-bottom py-3">
            <span style={{ fontWeight: "600" }}>{row.heading}</span>
            <span className="seva-nos" style={{ fontWeight: "bold" }}>
              {row.value}
            </span>
          </div>
        );
      })}
    </div>
  );
};

export default MpTableHighlights;
