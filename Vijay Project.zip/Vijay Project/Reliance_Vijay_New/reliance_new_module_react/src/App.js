import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import MpHome from './Components/MpHome/MpHome';
import SevaUpdates from './Components/SavaUpdate/SevaUpdates';
import YourInitiative from './Components/YourIntiative/YourInitiative';
import AdminHome from './Components/AdminHome/AdminHome';
import Login from './Components/Login/Login.js';
import MpSavaUpdate from './Components/SavaUpdate/MpSevaUpdate/MpSavaUpdate';
import AllInitiativeReports from './Components/SavaUpdate/AllInitiativeReports/AllInitiativeReports';
import { useEffect, useState } from 'react';
import SevaInitiatives from './Components/SevaInitiatives/SevaInitiatives';
import CreateInitiatives from './Components/SevaInitiatives/CreateInitiatives/CreateInitiatives';
import MySevaUpdate from './Components/SavaUpdate/MySevaUpdates/MySevaUpdates';
import ViewAllScreen from './Components/SavaUpdate/ViewAllScreen';
function App() {
  const [userId, setUserId] = useState(localStorage.getItem("userId"))
  // let userid=localStorage.getItem("userId")
  console.log(userId, typeof (userId), "user id")
  // let userid = 1
  // 1- MP, 2- Admin, 3- Citizen


  if (!userId)
    return (<Router forceRefresh={true}>
      <Routes><Route exact path="*" element={<Login setId={setUserId} />}></Route></Routes></Router>
    )

  return (
    <>
      <div className="App">
        <Router>
          <Routes>
            <Route exact path='/Login' element={<Login />} />
            <Route exact path='/' element={userId == 1 ? <MpHome /> : <AdminHome />} />
            {userId == 1 &&
              <>
                <Route exact path='/MpHome' element={<MpHome />} />
                <Route exact path='/Initiatives' element={<YourInitiative />} />
                <Route exact path='/SevaUpdates' element={<SevaUpdates />} />
                <Route exact path='/SevaUpdates/viewAllSevaEvents' element={<ViewAllScreen />} />
                <Route exact path='/MySevaUpdates' element={<MySevaUpdate />} />
              </>}
            {userId == 2 &&
              <>
                <Route exact path='/AdminHome' element={<AdminHome />} />
                <Route exact path='/SevaInitiatives' element={<SevaInitiatives />} />
                <Route exact path='/SevaInitiatives/createInitiative' element={<CreateInitiatives />} />
                <Route exact path='/SevaUpdates' element={<SevaUpdates />} />
                <Route exact path='/SevaUpdates/viewAllSevaEvents' element={<ViewAllScreen />} />
                <Route exact path='/MySevaUpdates' element={<MySevaUpdate />} />
              </>}
            {userId == 3 &&
              <>
                <Route exact path='/SevaUpdates/viewAllSevaEvents' element={<ViewAllScreen />} />
                <Route exact path='/MySevaUpdates' element={<MySevaUpdate />} />
                <Route exact path='/AdminHome' element={<AdminHome readonly={true} />} />
                <Route exact path='/SevaUpdates' element={<SevaUpdates readonly={true} />} />
              </>}
            <Route exact path='/Mp_SevaUpdate' element={<MpSavaUpdate />} />
            <Route exact path='/SevaUpdates/allInitiativeReports' element={<AllInitiativeReports />} />
          </Routes>
        </Router>
      </div>
    </>
  );
}



export default App;
